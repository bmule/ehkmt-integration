import groovy.xml.StreamingMarkupBuilder
import grails.util.Environment
import org.codehaus.groovy.grails.commons.GrailsApplication
import grails.util.GrailsUtil

//scriptEnv = "production"
//after scriptEnv
//includeTargets << grailsScript("Init")

/* JNDI
if (Environment.current == Environment.PRODUCTION || Environment.current == Environment.TEST) {
    eventWebXmlEnd = {String tmpfile ->
        def root = new XmlSlurper().parse(webXmlFile)

        // add the data source
        root.appendNode {
            'resource-ref' {
                'description'('The JNDI Database resource')
                'res-ref-name'('java:comp/env/phrs_portal_storage')
                'res-type'('javax.sql.DataSource')
                'res-auth'('Application')
            }
        }

        webXmlFile.text = new StreamingMarkupBuilder().bind {
            mkp.declareNamespace("": "http://java.sun.com/xml/ns/j2ee")
            mkp.yield(root)
        }
    }


}*/

//internal, not used setDefaultTarget(main)

//target(main: "Internal script - Removes log4j config stuff from Log4jConfigListener for JBoss 5+") {

/**
 * Deploying to JBoss 5, deploying to JBoss 4.2 should not need this.
 * Note: currently, not log4j properties files are produced...
 * http://blog.saddey.net/2010/03/06/how-to-deploy-a-grails-application-to-jboss-5/
 * TODO JBOSS - Remove log4j configuration stuff (when running with JBoss or GlassFish a.s.o)
 *

if (Environment.current == Environment.PRODUCTION || Environment.current == Environment.TEST) {
    eventWebXmlEnd = {String tmpfile ->
        println('start fixlog log4j eventWebXmlEnd ')

        def root = new XmlSlurper().parse(webXmlFile)

        // When running with JBoss (or GlassFish a.s.o) remove log4j configuration stuff
        def log4j = root.listener.findAll {node ->
            node.'listener-class'.text() == 'org.codehaus.groovy.grails.web.util.Log4jConfigListener'
        }
        log4j.replaceNode {}

        def log4jFile = root.'context-param'.findAll {node ->
            node.'param-name'.text() == 'log4jConfigLocation'
        }
        log4jFile.replaceNode {}

        webXmlFile.text = new StreamingMarkupBuilder().bind {
            mkp.declareNamespace("": "http://java.sun.com/xml/ns/j2ee")
            mkp.yield(root)
        }
        println('end fixlog log4j eventWebXmlEnd ')
    }

}*/
