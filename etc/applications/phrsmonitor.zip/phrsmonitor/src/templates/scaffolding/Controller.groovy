<%=packageName ? "package ${packageName}\n\n" : ''%>
import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants

class ${className}Controller {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
    //matches form model, but we can use from elsewhere
    static final String CLASS_URI="${packageName}.${className}"

    //default unless changed
    User targetUser = authenticatedUser
    String targetUserUri =  targetUser?.healthProfileUid

    Map attrMap=[:]
    def PhrsCommonsService //injected service
    def controllerOptionProperties


    def failAuthorization = {
         redirect(action: "goHome", params: params)
    }
    def goHome = {
        redirect(controller:"mainMenu", action: "index", params: params)
    }

    def index = {
        redirect(action: "list", params: params)
    }

    def list = {

        //parms for phr_ownerUri by authenticated user
        //if no params, then redirect to listAll and check permission
        //'instanceName':${propertyName},'className':${className},

        boolean okPermission= PhrsCommonsService.processResourceAuthorization(
          [ 'viewInstanceName':"${propertyName}",'classInstance':${className},'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
        //hack

        if(! okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        /*    params.max = Math.min(params.max ? params.int('max') : 10, 100)

            [${propertyName}List: ${className}.list(params),
             ${propertyName}Total: ${className}.count(),
             'theAction':'list',
             'visualizationAttributes':PhrsCommonsService.visualizationAttributes(['classUri':CLASS_URI]),
             'controllerOptionProperties':controllerOptionProperties]
         */
        PhrsCommonsService.queryList(
           [ 'instanceName':"${propertyName}",'className':${className},'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
    }

    def listAll = {
        boolean okPermission= PhrsCommonsService.processResourceAuthorization(
           ['viewInstanceName':"${propertyName}",'classInstance':${className},'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])

        if(!okPermission ){
            redirect(action: "failAuthorization", params: params)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)
            [
                    ${propertyName}List: ${className}.list(params),
                    ${propertyName}Total: ${className}.count(),
                    'theAction':'list',
                    'visualizationAttributes':PhrsCommonsService.visualizationAttributes(['classUri':CLASS_URI]),
                    'controllerOptionProperties':controllerOptionProperties
            ]
    }

    def create = {
        def ${propertyName} = new ${className}()
        ${propertyName}.properties = params

        boolean okPermission= PhrsCommonsService.processResourceAuthorization(
          ['instanceName':${propertyName},'className':${className},'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_CREATE])
        if(! okPermission){
            //flash.message = "\${message(code: 'default.not.found.message', args: [message(code: '${domainClass.propertyName}.label', default: '${className}'), params.id])}"
            println("permission fail CREATE")
            redirect(action: "index")
        }

        //preform afterwards in case of malicious tampering of properties.
        PhrsCommonsService.processResourceInit(
             [ 'instanceName':${propertyName},'className':${className},'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'attrMap':attrMap])

        //edit view does both edit and create
        render(view: "edit", model: [${propertyName}: ${propertyName},'theAction':'create'])
    }

    def save = {
        def ${propertyName} = new ${className}(params)

        println("CLASS_URI"+CLASS_URI)
       //beanInput, classUri, paramsMap, theAuthenticatedUser, attrMap
        boolean okSave= PhrsCommonsService.processResourceToPersist(
                [ 'instanceName':${propertyName},'className':${className},'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'attrMap':attrMap])

        boolean okPermission= PhrsCommonsService.processResourceAuthorization(
                    [ 'instanceName':${propertyName},'className':${className},'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SAVE])
        if(! okPermission){
            //flash.message = "\${message(code: 'default.not.found.message', args: [message(code: '${domainClass.propertyName}.label', default: '${className}'), params.id])}"
            println("permission fail SAVE")
            redirect(action: "index")
        }
        //permission check.... that sends a message if no permission
        if( ! okSave){
          println("")
          redirect(action: "index")
        }
        else if (${propertyName}.save(flush: true)) {
            flash.message = "\${message(code: 'default.created.message', args: [message(code: '${domainClass.propertyName}.label', default: '${className}'), ${propertyName}.id])}"
            redirect(action: "show", id: ${propertyName}.id)
        }
        else if(${propertyName}.errors){
               ${propertyName}.errors.each{
                   log.error(it)
               }
            //edit view does both edit and create
            render(view: "edit", model: [${propertyName}: ${propertyName},'theAction':'create'])
        }
    }

    def show = {
        def ${propertyName} = ${className}.get(params.id)


        if (!${propertyName}) {

            flash.message = "\${message(code: 'default.not.found.message', args: [message(code: '${domainClass.propertyName}.label', default: '${className}'), params.id])}"
            redirect(action: "list")
        }
        else {
            //can pass only resource uri and owner uri, authenticated user id or uri
            boolean okPermission= PhrsCommonsService.processResourceAuthorization(
                    [ 'instanceName':${propertyName},'className':${className},'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
            if(! okPermission){
            //flash.message = "\${message(code: 'default.not.found.message', args: [message(code: '${domainClass.propertyName}.label', default: '${className}'), params.id])}"
            println("permission fail")
            redirect(action: "index")
            }
            else [${propertyName}: ${propertyName},'theAction':'show']
        }
    }

    def edit = {
        def ${propertyName} = ${className}.get(params.id)
        if (!${propertyName}) {
            flash.message = "\${message(code: 'default.not.found.message', args: [message(code: '${domainClass.propertyName}.label', default: '${className}'), params.id])}"
            redirect(action: "list")
        }
        else {
            boolean okPermission= PhrsCommonsService.processResourceAuthorization(
                    [ 'instanceName':${propertyName},'className':${className},'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_EDIT])
            if(! okPermission){
            //flash.message = "\${message(code: 'default.not.found.message', args: [message(code: '${domainClass.propertyName}.label', default: '${className}'), params.id])}"
            println("permission fail EDIT")
            redirect(action: "index")
            }
            return  [${propertyName}: ${propertyName},'theAction':'edit']
        }
    }

    def update = {
        def ${propertyName} = ${className}.get(params.id)

        if (${propertyName}) {
            boolean okPermission= PhrsCommonsService.processResourceAuthorization(
                    ['instanceName':${propertyName},'className':${className},'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_EDIT])
            if(! okPermission){
            //flash.message = "\${message(code: 'default.not.found.message', args: [message(code: '${domainClass.propertyName}.label', default: '${className}'), params.id])}"
                println("permission fail UPDATE (EDIT)")
                redirect(action: "index")
            }

            if (params.version) {
                def version = params.version.toLong()
                if (${propertyName}.version > version) {
                    <% def lowerCaseName = grails.util.GrailsNameUtils.getPropertyName(className) %>
                    ${propertyName}.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: '${domainClass.propertyName}.label', default: '${className}')] as Object[], "Another user has updated this ${className} while you were editing")
                    render(view: "edit", model: [${propertyName}: ${propertyName},'theAction':'edit'])
                    return
                }
            }
            ${propertyName}.properties = params
            if (!${propertyName}.hasErrors() && ${propertyName}.save(flush: true)) {
                flash.message = "\${message(code: 'default.updated.message', args: [message(code: '${domainClass.propertyName}.label', default: '${className}'), ${propertyName}.id])}"
                redirect(action: "show", id: ${propertyName}.id)
            }
            else {

                render(view: "edit", model: [${propertyName}: ${propertyName},'theAction':'edit'])
            }
        }
        else {
            flash.message = "\${message(code: 'default.not.found.message', args: [message(code: '${domainClass.propertyName}.label', default: '${className}'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def ${propertyName} = ${className}.get(params.id)
        if (${propertyName}) {
            boolean okPermission= PhrsCommonsService.processResourceAuthorization(
                    [ 'instanceName':${propertyName},'className':${className},'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_DELETE])
            if(! okPermission){
            //flash.message = "\${message(code: 'default.not.found.message', args: [message(code: '${domainClass.propertyName}.label', default: '${className}'), params.id])}"
            println("permission fail DELETE")
            redirect(action: "index")
            }
            try {
                ${propertyName}.delete(flush: true)
                flash.message = "\${message(code: 'default.deleted.message', args: [message(code: '${domainClass.propertyName}.label', default: '${className}'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "\${message(code: 'default.not.deleted.message', args: [message(code: '${domainClass.propertyName}.label', default: '${className}'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "\${message(code: 'default.not.found.message', args: [message(code: '${domainClass.propertyName}.label', default: '${className}'), params.id])}"
            redirect(action: "list")
        }
    }
}
