package at.srfg.kmt.ehealth.phrs.presentation.utils;

import at.srfg.kmt.ehealth.phrs.dataexchange.model.Constants;

import java.util.UUID;

public class PortalConstants {

    public static boolean JSON_TEST = false; //can access json of domain objects
    public static boolean CORE_JSON_TEST = false;

    public static boolean CORE_WRITE = true;
    public static final String ACTION_CAREGIVER_ACTION_PARAM="ACTION_CAREGIVER_ACTION_PARAM";
    public static final String ACTION_CAREGIVER_ACTION_PARAM_VALUE_MONITOR_VIEW="MONITOR_VIEW_ONLY";
    /*

//TODO not in forms
Boolean _phrsBeanCanRead =Boolean.TRUE
//TODO not in forms
Boolean _phrsBeanCanWrite =Boolean.TRUE
//TODO not in forms
String _phrsBeanName
//TODO not in forms
Boolean _phrsBeanCanUse = Boolean.TRUE

//"ehr.phrtestgenerated"
    */
    public static final String Model_PROPERTY_OWNER_URI = "_phrsBeanOwnerUri";
    public static final String Model_PROPERTY_CREATE_DATE = "_phrsBeanCreateDate";

    public static final String MODEL_PROPERTY_RESOURCE_URI = "_phrsBeanUri";

    public static final String MODEL_PROPERTY_REFERS_TO_SOURCE = "_phrsBeanRefersToSourceUri";
    public static final String CORE_MESSAGE_ACTION_IMPORT_EHR = "CORE_MESSAGE_ACTION_IMPORT_EHR";
    public static final String CORE_MESSAGE_ACTION_EXPORT_CORE = "CORE_MESSAGE_ACTION_EXPORT_CORE";

    public static final String CORE_MESSAGE_STATUS_FAIL_REDO = "CORE_MESSAGE_STATUS_FAIL_REDO";

    public static String CORE_MESSAGE_STATUS_SUCCESS = "CORE_MESSAGE_STATUS_SUCCESS";
    public static final String CORE_MESSAGE_STATUS_SUCCESS_HOLD = "CORE_MESSAGE_STATUS_SUCCESS_HOLD";
    public static final String CORE_MESSAGE_STATUS_SUCCESS_CONSUMED = "CORE_MESSAGE_STATUS_SUCCESS_CONSUMED";


    public static final String MODEL_ACTIVITY_OF_DAILY_LIVING_CLASS_URI = Constants.ACTIVITY_OF_DAILY_LIVING_CLASS_URI;

    public static final String MODEL_BLOOD_PREASURE_CLASS_URI = Constants.BLOOD_PREASURE_CLASS_URI;

    public static final String MODEL_BODY_WEIGHT_CLASS_URI = Constants.BODY_WEIGHT_CLASS_URI;

    public static final String MODEL_MEDICATION_CLASS_URI = Constants.MEDICATION_CLASS_URI;

    public static final String MODEL_ACTIVITY_ITEM_CLASS_URI = Constants.ACTIVITY_ITEM_CLASS_NAME;

    public static final String MODEL_PROBLEMS_CLASS_URI = Constants.PROBLEMS_CLASS_URI;

    public static final String MODEL_RISK_FACTOR_CLASS_URI = Constants.RISK_CLASS_URI;

    public static final String MODEL_ACTIVITY_LEVEL_CLASS_URI = Constants.ACTIVITY_LEVEL_CLASS_URI;

    public static final String CLASS_URI_NAME = "_phrsBeanClassURI";
    // ------------------------------------------

    public final static String PROPERTY_OWNER_USER_FOR_DYNAMIC_QUERY = "OwnerUser";

    public final static String ACTION_MAIN_MENU_INDEX = "index";
    public final static String ACTION_MAIN_MENU_HOME = "home";
    public final static String ACTION_MAIN_MENU_ACTIONPLAN = "section_actionplan";
    public final static String ACTION_MAIN_MENU_OBSERVATIONS = "section_observations";
    public final static String ACTION_MAIN_MENU_EDUCATION = "section_education";
    public final static String ACTION_MAIN_MENU_PROFILE = "section_profile";
    public final static String ACTION_MAIN_MENU_ADMIN = "section_admin";
    public final static String ACTION_MAIN_MENU_LOGOUT = "section_logout";


    /*
    public static final String NS_PHR_ACTIVITY_LIFESTYLE = "phlife";
    public static final String NS_PHR_PROBLEM = "phprob";

    //    public static final String NS_PHR_FORM = "phf";
    public static final String NS_PHR_OBSERVATION = "pho";
    public static final String NS_PHR_RISKFACTORS = "phrisk";

    //no use codes
    public static final String NS_PHR_VITALS = "phvital";


    public static final String NS_PHR_PATIENT_INFO = "phi";
    public static final String NS_DELIMITER = "__";

    public static final String CATEGORIES = "Categories";
    public static final String TAGS = "Tags";

    public static final String OBSERVATION_DATE = "ObservationDate";
    public static final String OBSERVATION_DATE_END = "ObservationDateEnd";
    public static final String COMMENT = "Comment";
    public static final String STATUS_BOOLEAN = "StatusBoolean";

    public static final String MOOD_OVERALL = "MoodOverall";
    public static final String OBS_VITAL_WEIGHT = "ObsVitalWeight";
    public static final String OBS_VITAL_HEIGHT = "ObsVitalHeight";
    public static final String OBS_VITAL_BMI = "ObsVitalBmi";

    public static final String OBS_BLOOD_PRESSURE_SYSTOLIC = "ObsBloodPressureSystolic";
    public static final String OBS_BLOOD_PRESSURE_DIASTOLIC = "ObsBloodPressureDiastolic";
    public static final String OBS_BLOOD_PRESSURE_HEART_RATE = "ObsBloodPressureSystolic";


    public static final String OBS_PROBLEM = "ObsProblem";

    public static final String TERMINOLOGY_DISPLAY_NAME = "TerminologyDisplayName";
    public static final String TERMINOLOGY_CODE = "TerminologyCode";

     //namespace ... used in HL7 as codeSystem

    public static final String TERMINOLOGY_CODE_SYSTEM_NAMESPACE = "TerminologyCodeNamespace";
     //Type related constants


    public static final String TYPE_FORM = "phf__Form";

    public static final String TYPE_FORM_OBSERVATION = "FormObservation";
    public static final String TYPE_FORM_RISKFACTOR_SERIES_A = "FormRiskFactor";

    //there can be a link to EHR vitals perhaps....

    public static final String TYPE_FORM_OBSERVATION_VITAL_SERIES_A = "FormObservationVitals";
    public static final String TYPE_FORM_OBSERVATION_VITAL_BLOOD_PRESSURE = "FormBloodPressure";
    public static final String TYPE_FORM_OBSERVATION_PROBLEM_SERIES_A = "FormProblem";


    public static final String TYPE_FORM_ACTIVITY_LIFESTYLE = "FormActivityLifestyle";
    public static final String TYPE_FORM_ACTIVITY_SPORT_SERIES_A = "FormActivitySport";
    public static final String TYPE_FORM_ACTIVITY_LIFESTYLE_OTHER_SERIES_A = "FormActivityOther";
    public static final String TYPE_FORM_ACTIVITY_LIFESTYLE_ASSISTED_SERIES_A = "FormActivityAssisted";

    public static final String TYPE_FORM_HEALTH_PROFILE_DATA_A = "FormHealthProfileData";
    public static final String TYPE_FORM_HEALTH_PROFILE_BASIC_INFO_A = "FormHealthProfileBasicInfo";
    public static final String TYPE_FORM_HEALTH_DATA_MANAGED_ = "FormHealthDataManaged";
    public static final String TYPE_HEALTH_DATA_EHR_ASSOCIATED = "HealthDataEhrAssociated";
    public static final String TYPE_HEALTH_DATA_EXT_PHR_ASSOCIATED = "HealthDataExtPhrAssociated";
    public static final String TYPE_HEALTH_DATA_THIS_PHR_ASSOCIATED = "HealthDataThisPhrAssociated";
    public static final String TYPE_HEALTH_DATA_ANNOTATABLE = "HealthDataAnnotatable";

    public static final String TYPE_ASSOCIATED_INFO_EHR = "phrel__Ehr";
    public static final String TYPE_ASSOCIATED_INFO_PHR = "phrel__Phr";


    public static final String PROPERTY_SUFFIX_MULTI_CHOICE = "multichoice";
    public static final String PROPERTY_SUFFIX_SINGLE_CHOICE = "singlechoice";
    public static final String PROPERTY_SUFFIX_INDICATOR = "indicator";
    */
    //user phi
    public static final String TYPE_PATIENT_INFO = "";
    /**
     * Use patient info codes from HL7
     * paitne
     */
    public static final String TYPE_PATIENT_INFO_CODE = "";
    /**
     * Is the resource derived from the EHR ?  either   _phrsBeanRefersToSourceUri   _phrsBeanCreatorUri have prefix "ehr"
     */
    public static final String EHR_SOURCE_INDICATOR = "ehr";
    public static final String EHR_SOURCE_INDICATOR_PHRS_GENERATED_TEST = "ehr.phrtestgenerated";

    public static final String EHR_SOURCE_INDICATOR_PROPERTY_SOURCE = "_phrsBeanRefersToSourceUri";
    public static final String EHR_SOURCE_INDICATOR_PROPERTY_CREATOR = "_phrsBeanCreatorUri";

    public static final String ROLE_PHRS_PATTERN = "role_phrs_";
    public static final String ROLE_PHRS_PATIENT = ROLE_PHRS_PATTERN + "patient";

    //phrs cannot authorize these roles...
    public static final String ROLE_HEALTHCARE_ACTOR_PATTERN = "role_healthcare_actor_";
    public static final String ROLE_HEALTHCARE_ACTOR_PHYSICIAN = ROLE_HEALTHCARE_ACTOR_PATTERN + "physician";
    public static final String ROLE_HEALTHCARE_ACTOR_NURSE = ROLE_HEALTHCARE_ACTOR_PATTERN + "nurse";

    public static final String ROLE_PHRS_NON_MEDICAL_CAREGIVER_PATTERN = ROLE_PHRS_PATTERN + "nonmedical_";
    public static final String ROLE_PHRS_NON_MEDICAL_SOCIAL_WEB_FRIEND = ROLE_PHRS_PATTERN + ROLE_PHRS_NON_MEDICAL_CAREGIVER_PATTERN + "socialweb_friend";
    public static final String ROLE_PHRS_NON_MEDICAL_CAREGIVER = ROLE_PHRS_PATTERN + ROLE_PHRS_NON_MEDICAL_CAREGIVER_PATTERN + "caregiver";

    //public static final String ROLE_NON_MEDICAL_CAREGIVER = ROLE_NON_MEDICAL_CAREGIVER_PATTERN + "caregiver";

    public static final String PCC_RESOURCE_ALLERGY = "ALLERGY";
    public static final String PCC_RESOURCE_CONDITION = "CONDITIONS";
    public static final String PCC_RESOURCE_MEDICATION_ = "MEDICATION";
    public static final String PCC_RESOURCE_TEST_RESULTS_ = "TESTRESULT"; //Test Result
    public static final String PCC_RESOURCE_IMMUNIZATION = "IMMUNIZATION";
    public static final String PCC_RESOURCE_HOSPITAL_VISIT = "HOSPITALVISIT"; //Hospital Visit
    public static final String PCC_RESOURCE_BASIC_HEALTH = "BASICHEALTH";   //Basic Health Information


    public static final String ACTION_CONTROLLER_SHOW_HISTORY_ALL_CORE_EHR = "phrs_action_show_history_core_objects";
    public static final String ACTION_CONTROLLER_SHOW_NEW_CORE_EHR_OBJECTS = "phrs_action_show_new_ehr_core_objects";
    public static final String ACTION_CONTROLLER_SHOW_HISTORY_LOCAL_VERSIONS = "phrs_action_show_local_vesion_history";
    public static final String ACTION_CONTROLLER_SHOW = "phrs_action_show";
    public static final String ACTION_CONTROLLER_EDIT = "phrs_action_edit";

    public static final String ACTION_CONTROLLER_SAVE = "phrs_action_save"; //create/edit, implies save rights
    public static final String ACTION_CONTROLLER_CREATE = "phrs_action_create";
    public static final String ACTION_CONTROLLER_LIST = "phrs_action_list";
    public static final String ACTION_CONTROLLER_DELETE = "phrs_action_delete";

    public static final String ACTION_CONTROLLER_INDEX = "phrs_action_index";
    public static final int TEST_ADMIN_ID = 2;


    public static final String DELIMITER_URI_COLON = ":";
    public static final String NS_CODING_SYSTEM_LOINC = "2.16.840.1.113883.6.1";
    public static final String NS_CODING_SYSTEM_SNOMED = "UMLS";//TODO refactor snomed 2.16.840.1.113883.6.96";
    public static final String NS_CODING_SYSTEM_UMLS = "UMLS";
    public static final String NS_PHR_FORM = "PHRS.CS";//ok tag
    public static final String TAG_TRUE_POSITIVE = NS_PHR_FORM + DELIMITER_URI_COLON + "S0013";//ok tag
    public static final String TAG_FALSE_NEGATIVE = NS_PHR_FORM + DELIMITER_URI_COLON + "S0014";//ok tag
    /*
     PHRS.CS@S0013 true or positive
     PHRS.CS@S0014 false or negative
     PHRS.CS@S0001    Smoking duration
 PHRS.CS@S0002    Smoking quantity
     */
    public static final String TERM_SNOMED_ACTIVITY_PHYSICAL = NS_PHR_FORM + DELIMITER_URI_COLON + "S0018"; //ok tag
    //NS_CODING_SYSTEM_UMLS + DELIMITER_URI_COLON + "68130003";//???

    public static final String TERM_PHYSICAL_ACTIVITY_FREQUENCY = NS_PHR_FORM + DELIMITER_URI_COLON + "S0041";//ok
    public static final String TERM_PHYSICAL_ACTIVITY_DURATION = NS_PHR_FORM + DELIMITER_URI_COLON + "S0040 ";//ok

    /**
     * the term and the tag
     */
    public static final String TERM_SNOMED_SYMPTOM = NS_CODING_SYSTEM_UMLS + DELIMITER_URI_COLON + "C1457887";//ok tag UMLS@C1457887

    public static final String TERM_ACTIVITY_OF_DAILY_LIVING_PHRS = NS_PHR_FORM + DELIMITER_URI_COLON + "S0006"; //use UI tag, not UMLS tag for specific activities "C1269688";//ok tag
    //I can do or I need assistance to do an activity
    public static final String TERM_ACTIVITY_LIFESTYLE_STATUS_VALUE = NS_PHR_FORM + DELIMITER_URI_COLON + "S0044";
    //Physical Activity	38223-4	68130003	physical activity
    /*
 //diabetes
public static final String TERM_RISK_CODE_DIABETES_Mellitus= "UMLS@C0011849";

//hypertension
UMLS@C0020538

//cholesterol
UMLS@C0008377

//smoking
UMLS@C0337664
     */
    public static final String TERM_RISK_CODE_DIABETES_MELLITUS = NS_CODING_SYSTEM_UMLS + DELIMITER_URI_COLON + "C0011849";
    public static final String TERM_RISK_CODE_HYPERTENSION = NS_CODING_SYSTEM_UMLS + DELIMITER_URI_COLON + "C0020538";
    public static final String TERM_RISK_CODE_CHOLESTEROL = NS_CODING_SYSTEM_UMLS + DELIMITER_URI_COLON + "C0008377";
    public static final String TERM_RISK_CODE_SMOKING = NS_CODING_SYSTEM_UMLS + DELIMITER_URI_COLON + "C0337664";

    public static final String TERM_RISK_TREATMENTS_DIABETES = NS_PHR_FORM + DELIMITER_URI_COLON + "S0022";//ok
    public static final String TERM_RISK_TREATMENTS_HYPERTENSION = NS_PHR_FORM + DELIMITER_URI_COLON + "S0023";//ok
    public static final String TERM_RISK_TREATMENTS_CHOLESTEROL = NS_PHR_FORM + DELIMITER_URI_COLON + "S0024";//ok

    public static final String TERM_RISK_MEDICATIONS_TYPES_DIABETES = NS_PHR_FORM + DELIMITER_URI_COLON + "S0026";//ok //PHRS.CS@S0026

    /**
     * @deprecated
     */
    public static final String TERM_RISK_TREATMENTS_WEIGHT_GAIN = NS_PHR_FORM + DELIMITER_URI_COLON + "TERM_RISK_TREATMENTS_WEIGHT_GAIN";

    /**
     * @deprecated
     */
    public static final String TERM_RISK_TREATMENTS_SMOKING = NS_PHR_FORM + DELIMITER_URI_COLON + "TERM_RISK_TREATMENTS_SMOKINGXXXXX";//not available

    //PHRS.CS@S0001    Smoke duration;  PHRS.CS@S0002    Smoke quantity
    public static final String TERM_RISK_SMOKING_DURATION = NS_PHR_FORM + DELIMITER_URI_COLON + "S0001";//ok
    public static final String TERM_RISK_SMOKING_QUANTITY = NS_PHR_FORM + DELIMITER_URI_COLON + "S0002";//ok

    public static final String TERM_RISK_SMOKING_TYPES = NS_PHR_FORM + DELIMITER_URI_COLON + "S0036";//ok


    public static final String TERM_RISK_FACTOR_OF_TYPE_OVERVIEW_PHRS = NS_PHR_FORM + DELIMITER_URI_COLON + "S0019";//ok

    public static final String TERM_RELATION_OPTION_OF = TERM_RISK_FACTOR_OF_TYPE_OVERVIEW_PHRS;//NS_PHR_FORM + DELIMITER_URI_COLON + "option_of";

    //not used, tags everything without regard for sub grouping
    public static final String TERM_RISK_FACTOR_OF_TYPE = NS_CODING_SYSTEM_UMLS + DELIMITER_URI_COLON + "C0332167";

    public static final String TERM_DRUG_CONSUMPTION_STATUS_CODE_PHRS = NS_PHR_FORM + DELIMITER_URI_COLON + "S0015";//ok

    /**
     * @deprecated
     */
    public static final String TERM_DRUG_PRESCRIBED_BY_ROLE = NS_PHR_FORM + DELIMITER_URI_COLON + "TERM_DRUG_PRESCRIBED_BY_ROLE";

    public static final String TERM_DRUG_REASON_KEYWORDS = TERM_RISK_FACTOR_OF_TYPE_OVERVIEW_PHRS;


    public static final String TERM_DOSAGE_UNITS = NS_PHR_FORM + DELIMITER_URI_COLON + "S0003";//ok tag


    public static final String TERM_DRUG_FREQUENCY_INTERVAL_1 = NS_PHR_FORM + DELIMITER_URI_COLON + "S0042";

    /**
     * @deprecated Use as number source in tag
     */
    public static final String TERM_DRUG_FREQUENCY_QUANTITY = NS_PHR_FORM + DELIMITER_URI_COLON + "TERM_DRUG_FREQUENCY_QUANTITY";
    public static final String TERM_DRUG_FREQUENCY_TIME_OF_DAY_1 = NS_PHR_FORM + DELIMITER_URI_COLON + "S0043";


    public static final String PREFIX_USER_UID = "phrsuid";
    public static final String TEST_USER_UID_SYSTEM_ADMIN = PREFIX_USER_UID + "_default_admin_system_administrator";
    public static final String TEST_USER_UID_USER_TEST = PREFIX_USER_UID + "_default_user_test";
    public static final String TEST_USER_UID_USER_ANDREAS = PREFIX_USER_UID + "_default_user_patient_andreas";
    public static final String TEST_USER_UID_USER_ELLEN = PREFIX_USER_UID + "_default_user_nurse_ellen";
    //public static final String PREFIX_RESOURCE_UUID = "resourceguid";


    public static String createUUID(String prefix) {
        return prefix + "_" + UUID.randomUUID().toString();
    }

}
