package at.srfg.kmt.ehealth.phrs.presentation.utils; /**
 * HealthProfileIndividual: bmulreni
 */

import org.apache.commons.beanutils.*;

//import org.apache.commons.beanutils.BasicDynaBean;
//import org.apache.commons.beanutils.DynaClass

public class DynabeanGenerator {



    /**
     * get a backing bean definition, it might even be recursive when looking up another bean definition ?? but keep simple
     * <p/>
     * A table row might be a map
     *
     * @param uri
     * @return
     */
    public static DynaBean getBean(String uri) {
     /*
        DynaBean bean = null;

        DynaProperty[] props = new DynaProperty[]{
                new DynaProperty("address", java.util.Map.class),
                new DynaProperty("subordinate", ViewLabelValue[].class),    //columns defined
                //new DynaProperty("riskfactors", java.util.Map.class),
                //new DynaProperty("riskfactors", java.util.Map.class),
                new DynaProperty("firstName", String.class),
                new DynaProperty("lastName", String.class)
        };
        try {
            BasicDynaClass dynaClass = new BasicDynaClass("employee", null, props);

            bean = dynaClass.newInstance();
            bean.set("address", new HashMap());
            bean.set("subordinate", new ViewLabelValue[0]);
            bean.set("firstName", "Fred");
            bean.set("lastName", "Flintstone");

        } catch (IllegalAccessException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (InstantiationException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }


        return bean;
       */
        return null;

    }


    /*
    public static DynaBean doBinding(DynaBean bean, Map paramsValues) {
        //Set names = params.keySet();
        if (paramsValues != null && !paramsValues.isEmpty()) {
            //
        } else {
            return null;
        }
        try {
            HashMap map = new HashMap();
            //Enumeration names = request.getParameterNames();
            Set names = paramsValues.keySet();
            Iterator it = names.iterator();
            while (it.hasNext()) {
                String id = (String) it.next();
                map.put(id, paramsValues.get(id));//request.getParameterValues(id));
            }

            BeanUtils.populate(bean, map);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static DynaBean doBinding(DynaBean bean, Enumeration names, Map paramsValues) {
        //Set names = params.keySet();
        if (paramsValues != null && !paramsValues.isEmpty()) {
            //
        } else {
            return null;
        }
        try {
            HashMap map = new HashMap();
            //Enumeration names = request.getParameterNames();
            while (names.hasMoreElements()) {
                String id = (String) names.nextElement();
                map.put(id, paramsValues.get(id));//request.getParameterValues(id));
            }

            BeanUtils.populate(bean, map);
        } catch (IllegalAccessException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        } catch (InvocationTargetException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

        return null;
    }
    */
    /*
    HttpServletRequest request = ...;
    MyBean bean = ...;
    HashMap map = new HashMap();
    Enumeration names = request.getParameterNames();
    while (names.hasMoreElements()) {
      String id = (String) names.nextElement();
      map.put(id, request.getParameterValues(id));
    }
    BeanUtils.populate(bean, map);

     */

}
