package at.srfg.kmt.ehealth.phrs.presentation.utils;

/*import at.srfg.kmt.ehealth.phrs.dataexchange.api.ControlledItemRepository;
import at.srfg.kmt.ehealth.phrs.dataexchange.model.ControlledItem;
import at.srfg.kmt.ehealth.phrs.dataexchange.api.VocabularyLoader;

import static at.srfg.kmt.ehealth.phrs.dataexchange.api.Constants.*;

import java.util.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 */

import java.util.Map;
import java.util.HashMap;
//import static at.srfg.kmt.ehealth.phrs.util.JBossJNDILookup.lookupLocal;

/**
 * @deprecated - must be within JBoss container ear
 *             Wrapping the Vocabulary server and providing additional functionality for the user interfaces
 */
public class IntegratedVocabularyServer {

    public static final String KEY_NS = "ns";
    public static final String KEY_CODE = "ns";
    private static IntegratedVocabularyServer m_instance;

    private static boolean serverAvailable = true;

    private IntegratedVocabularyServer() {

    }

    /**
     * Must try to start once...
     *
     * @return
     */
    protected static boolean isServerAvailable(boolean start) {

        return serverAvailable;
    }

    /**
     * it will return null, if server not available e.g. not in correct context
     *
     * @return
     */
    public static IntegratedVocabularyServer instance() {

        if (m_instance == null && serverAvailable) { //
            try {
                //loadVocabularyItems();

                if (serverAvailable) {
                    m_instance = new IntegratedVocabularyServer();
                }
            } catch (Exception e) {
                e.printStackTrace();
                serverAvailable = false;
                m_instance = null;
            }

        }
        return m_instance;
    }

    /*
   private static final Logger LOGGER =
           LoggerFactory.getLogger(IntegratedVocabularyServer.class);

   public List<ControlledItem> findTermsByTags(List<String> tagUris) {
       List<ControlledItem> results = new ArrayList<ControlledItem>();

       return results;
   }
    */
    public static String createUri(String codeSystem, String code) {
        String uri = codeSystem + PortalConstants.DELIMITER_URI_COLON + code;
        return uri;
    }

    /*
     * @param terms
     * @return Label values where id=uri (code sys:code) and labe is display name
     */
    /*
    public static List<ViewLabelValue> toLabelValues(List<ControlledItem> terms, String language) {

        List<ViewLabelValue> results = new ArrayList<ViewLabelValue>();
        try {
            for (ControlledItem term : terms) {
                ViewLabelValue lv = toLabelValue(term, language);
                if (lv != null) results.add(lv);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return results;
    }

    public static ViewLabelValue toLabelValue(ControlledItem term, String language) {
        if (term != null) {
            try {
                String uri = createUri(term.getCodeSystem(), term.getCode());
                ViewLabelValue lv = new ViewLabelValue(uri, term.getPrefLabel());
                if (language != null) lv.setLang(language);
                return lv;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }  */


    /*
     * @param uri              usually includes full codesystem as namespace and colin separated namespace and code
     * @param defaultNameSpace - true then if URI does not contain a namespace, then add default one PortalConstants.NS_PHR_FORM
     * @return
     */
    public static Map<String, String> decomposeUri(String uri, boolean defaultNameSpace) {

        Map<String, String> result = new HashMap<String, String>();

        try {
            String[] uriArray = uri.split(":");
            if (uriArray != null && uriArray.length > 1) {
                result.put(KEY_NS, uriArray[0]);
                result.put(KEY_CODE, uriArray[1]);
            } else if (uriArray != null && uriArray.length == 1) {
                //code ?
                result.put(KEY_CODE, uriArray[0]);
                if (defaultNameSpace) {
                    result.put(KEY_NS, PortalConstants.NS_PHR_FORM);
                } else {
                    result.put(KEY_NS, "");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        return result;
    }
    /*
    public List<ViewLabelValue> findTermUrisByTagToLabelValues(String termUri, String language, boolean defaultNameSpace) {
        Map<String, String> result = decomposeUri(termUri, true);
        String codeSystem = result.containsKey(KEY_NS) ? result.get(KEY_NS) : null;
        String tagCode = result.containsKey(KEY_CODE) ? result.get(KEY_CODE) : null;

        return toLabelValues(findTermsByTag(codeSystem, tagCode, language), language);

    }

    public ViewLabelValue findTermUriToLabelValue(String termUri, String language) {
        Map<String, String> result = decomposeUri(termUri, true);
        String codeSystem = result.containsKey(KEY_NS) ? result.get(KEY_NS) : null;
        String tagCode = result.containsKey(KEY_CODE) ? result.get(KEY_CODE) : null;

        return toLabelValue(findTerm(codeSystem, tagCode, language), language);

    }

    public List<ViewLabelValue> findTermsByTagToLabelValues(String codeSystem, String tagCode, String language) {

        return toLabelValues(findTermsByTag(codeSystem, tagCode, language), language);

    }

    public ViewLabelValue findTermToLabelValue(String codeSystem, String termCode, String language) {

        return toLabelValue(findTerm(codeSystem, termCode, language), language);

    } */

    /**
     * @param codeSystem - if null, default to SNOMED codesystem
     * @param tagCode
     * @return empty list if nothing found
     */
    /*
    public List<ControlledItem> findTermsByTag(String codeSystem, String tagCode, String language) {

        String actualCodeSystem = codeSystem;
        //TODO if short prefix passed, then get code system...
        if (actualCodeSystem == null) {
            actualCodeSystem = SNOMED;
        }

        final ControlledItemRepository repository;
        List<ControlledItem> results = new ArrayList<ControlledItem>();

        if (codeSystem != null && tagCode != null) {
            //
        } else {
            return results;
        }

        try {
            repository = lookupLocal(ControlledItemRepository.class);

            final ControlledItem item =
                    repository.getByCodeSystemAndCode(actualCodeSystem, tagCode);    //SNOMED in at.srfg.kmt.ehealth.phrs.dataexchange.api.PortalConstants.*;

            final Set<ControlledItem> byTag = repository.getByTag(item);

            for (ControlledItem result : byTag) {
                results.add(result);
            }
        } catch (javax.naming.NameNotFoundException ne) {
            serverAvailable = false;
            LOGGER.error(ne.getMessage(), ne);

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);

            //return empty list
        }
        return results;
    } */
/*
            final ControlledItem item =
                    repository.getByCodeSystemAndCode(SNOMED, tagCode);
            final String msg = "Tag " + item + "</br>";
            final Set<ControlledItem> byTag = repository.getByTag(item);
 */

    /**
     * @param codeSystem
     * @param termCode
     * @return returns null if not found
     */
    /*
    public ControlledItem findTerm(String codeSystem, String termCode, String language) {
        if (codeSystem != null && termCode != null) {
            //
        } else {
            return null;
        }

        String actualCodeSystem = codeSystem;
        //TODO if short prefix passed, then get code system...
        if (actualCodeSystem == null) {
            actualCodeSystem = SNOMED;
        }

        final ControlledItemRepository repository;


        try {
            repository = lookupLocal(ControlledItemRepository.class);

            final ControlledItem result =
                    repository.getByCodeSystemAndCode(actualCodeSystem, termCode);    //SNOMED in at.srfg.kmt.ehealth.phrs.dataexchange.api.PortalConstants.*;

            return result;

        } catch (javax.naming.NameNotFoundException ne) {
            serverAvailable = false;
            LOGGER.error(ne.getMessage(), ne);

        } catch (Exception exception) {
            LOGGER.error(exception.getMessage(), exception);
        }
        return null;

    }  */
    /*
    protected static void loadVocabularyItems() throws Exception {

        final VocabularyLoader loader;
        try {
            loader = lookupLocal(VocabularyLoader.class);
            loader.load();
            System.out.println("Default vocabulary was successfully loaded.");
        } catch (javax.naming.NameNotFoundException ne) {
            serverAvailable = false;

            //LOGGER.error(exception.getMessage(), exception);
            System.out.println("FAILURE ! vocabulary server - (javax.naming.NameNotFoundException not in correct context)");

        } catch (Exception exception) {
            serverAvailable = false;

            //LOGGER.error(exception.getMessage(), exception);
            System.out.println("FAILURE ! vocabulary server - vocab not loaded");

        }
    }*/
}
