package at.srfg.kmt.ehealth.phrs.presentation.utils;


public class PhrsCoreInitializationException extends Exception {

    public PhrsCoreInitializationException() {
    }

    public PhrsCoreInitializationException(String s, Throwable throwable) {
        super(s, throwable);
    }

    public PhrsCoreInitializationException(Throwable throwable) {
        super(throwable);
    }

    public PhrsCoreInitializationException(String s) {
        super(s);
    }
}
