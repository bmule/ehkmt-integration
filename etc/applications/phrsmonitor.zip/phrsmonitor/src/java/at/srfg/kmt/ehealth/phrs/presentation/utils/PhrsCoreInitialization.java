package at.srfg.kmt.ehealth.phrs.presentation.utils;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * User: bmulreni
 * <p/>
 * This provides the means to configure the interaction with the Phrs Core
 * When bootstrapping the application, init params from the web.xml can be read and used
 * to initialize this class e.g. core phrs serverUrl
 * When we have a publication subscribe or  queue mgt, then we can hold messages for sending later.
 */
public class PhrsCoreInitialization {


    private transient final Log LOGGER = LogFactory.getLog(this.getClass());

    //public static String SERVER_URL = "http://localhost:8080/"
    /*
    persist
     */
    private static PhrsCoreInitialization _instance = null;

    public boolean simulatePhrsCoreEhrMessages = true;
    public boolean exportToPhrsCore = true;
    private boolean isInteropVocabServerLoaded = false;
    private boolean isInteropClassesLoaded = false;
    private String serverUrl = "http://localhost:7070/";

    private boolean externallySet = false;
    private Set<String> results;


    private PhrsCoreInitialization() {


    }

    public static PhrsCoreInitialization getInstance() {
        if (_instance == null) {
            _instance = new PhrsCoreInitialization();
        }
        return _instance;

    }


        /*
    public static boolean isReachable(String address) {

        Socket t = null;
        boolean isReachable = false;
        try {
            t = new Socket(address, 7070); // 7 echo port ? ok on jboss?

            DataInputStream dis = new DataInputStream(t.getInputStream());
            PrintStream ps = new PrintStream(t.getOutputStream());
            ps.println("Hello");
            String str = dis.readLine();
            if (str.equals("Hello")) {
                System.out.println("Alive!");
                isReachable = true;
            } else {
                System.out.println("Dead or echo port not responding");
            }

            t.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (t != null) t.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return false;
    }  */


    /**
     * Call when  bootstraping production system,  currently only the vocab server
     * Eventually need to send an exception to the front end  controllers...
     *
     * @return
     * @throws PhrsCoreInitializationException
     */
    public boolean initializeCoreVocabularyServer() throws PhrsCoreInitializationException {

        VocabServerLookup.loadVocabularyFeaturesServer();
        if (!isInteropVocabServerLoaded) {
            throw new PhrsCoreInitializationException("PHRS Core server could not load vocabularies, perhaps the PHRS JBOSS Core server is not running or available at" + this.getCoreServerUrl());
        }
        return true;
    }


    public boolean loadRemoteServerVocabularies() {
        VocabServerLookup.loadVocabularyFeaturesServer();
        return isInteropVocabServerLoaded;
    }

    public boolean loadRemoteServerCoreClasses() {
        InteropServerClient.loadInteropFeaturesServer();

        return isInteropVocabServerLoaded;
    }

    public boolean isSimulatePhrsCoreEhrMessages() {
        return simulatePhrsCoreEhrMessages;
    }

    public void setIsSimulatePhrsCoreEhrMessages(boolean simulatePhrsCoreEhrMessages) {
        this.simulatePhrsCoreEhrMessages = simulatePhrsCoreEhrMessages;
    }

    public boolean isExportToPhrsCore() {
        return exportToPhrsCore;
    }

    public void setExportToPhrsCore(boolean exportToPhrsCore) {
        this.exportToPhrsCore = exportToPhrsCore;
    }

    public boolean isInteropClassesLoaded() {
        return isInteropClassesLoaded;
    }

    public void setIsInteropClassesLoaded(boolean isInteropClassesLoaded) {
        this.isInteropClassesLoaded = isInteropClassesLoaded;
    }

    public boolean isInteropVocabServerLoaded() {
        return isInteropVocabServerLoaded;
    }

    public void setIsInteropVocabServerLoaded(boolean isInteropVocabServerLoaded) {
        this.isInteropVocabServerLoaded = isInteropVocabServerLoaded;
    }

    /**
     * @param serverUrl - overwrites the server URL that is used by other  clients
     * @return
     */
    public static PhrsCoreInitialization getInstance(String serverUrl) {

        _instance = getInstance();
        if (serverUrl != null && serverUrl.length() > 3) {
            _instance.serverUrl = serverUrl;
            _instance.externallySet = true;

        }
        return _instance;
    }


    public String getCoreServerUrl() {
        return serverUrl;
    }

    public boolean isExternallySet() {
        return externallySet;
    }

    public Set<String> getCoreClassUris() {

        if (results == null) {
            results = new HashSet<String>();
            initDefaultCoreClasses();
        }

        return results;

    }

    /**
     * replaces all
     *
     * @param coreClassUris
     */
    public void setCoreClasses(Set<String> coreClassUris) {
        results = coreClassUris;

    }

    /**
     * add new to initialized classes
     *
     * @param coreClassUri
     */
    public void addCoreClass(String coreClassUri) {
        //be sure it exists and initialized
        Set init = getCoreClassUris();
        results.add(coreClassUri);

    }

    private void initDefaultCoreClasses() {
        results.add(PortalConstants.MODEL_ACTIVITY_OF_DAILY_LIVING_CLASS_URI);
        results.add(PortalConstants.MODEL_BLOOD_PREASURE_CLASS_URI);
        results.add(PortalConstants.MODEL_BODY_WEIGHT_CLASS_URI);
        results.add(PortalConstants.MODEL_MEDICATION_CLASS_URI);
        results.add(PortalConstants.MODEL_ACTIVITY_ITEM_CLASS_URI);
        results.add(PortalConstants.MODEL_PROBLEMS_CLASS_URI);
        results.add(PortalConstants.MODEL_RISK_FACTOR_CLASS_URI);
        results.add(PortalConstants.MODEL_ACTIVITY_LEVEL_CLASS_URI);

    }


}
