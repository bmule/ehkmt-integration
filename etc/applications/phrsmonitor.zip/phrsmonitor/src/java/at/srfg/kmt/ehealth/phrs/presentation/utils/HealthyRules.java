package at.srfg.kmt.ehealth.phrs.presentation.utils;

/**
 * User: bmulreni
 */
public class HealthyRules {

    public static boolean okBloodPressure(Integer bpSystolic, Integer bpDiastolic){
        if(bpDiastolic > 1000) return false;
        if(bpSystolic > 1000) return false;

        return true ;

    }

    /**
     *
     * @param weight
     * @param height
     * @return
     */
    public static Float computeBMI(Float weight, Float height) {
        Float bmi=0F;
        try {
            if(height != null && height != 0F && weight !=null && weight != 0F){

            } else {
                return 0F;
            }
            Float thisHeight= new Float(height);
            if(height < 3){ //meter
                 //
            } else {
                thisHeight = thisHeight / 100F;
            }

            bmi= weight / (thisHeight * thisHeight);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return bmi;
    }

}
