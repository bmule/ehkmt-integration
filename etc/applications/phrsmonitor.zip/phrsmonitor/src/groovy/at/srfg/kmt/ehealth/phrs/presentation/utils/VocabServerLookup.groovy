package at.srfg.kmt.ehealth.phrs.presentation.utils

import static groovyx.net.http.ContentType.JSON

import groovyx.net.http.RESTClient

class VocabServerLookup {

    //query param either ---> codesystem or codesystem:code
    static final String REST_PATH_VOCAB_GET_ALL_BY_CODE_SYSTEM = "get"
    //query param --> codesystem:code
    static final String REST_PATH_VOCAB_ACTION_GET_ALL_BY_TAG = "getForTag"
    //label query
    static final String REST_PATH_VOCAB_ACTION_GET_TERM_LABEL = "getForExactLabel"
    //label query
    static final String REST_PATH_VOCAB_ACTION_GET_TERM_PREFIX = "getForPrefixLabel"
    static final String REST_PATH_VOCAB_REPOSITORY = "dataexchange_ws/controlled_item_repository/"
    //2.16.840.1.113883.6.96

    static String testCodeSystem1() {
        def term = '2.16.840.1.113883.6.96'
        def jsonOut = getTermsToJSONArray(term, 'en')
        println("testCodeSystem1 " + jsonOut?.toString())
        return jsonOut

    }
    /*
  static Map transformJson(String json) {
      Map map = RestServices.stringToMap(json)
      println("transformJson entries" + map)
      return map
  }  */

    static String testCodeSystem2() {
        def queryParm = "2.16.840.1.113883.6.96"
        def jsonArray = getTermsToJSONArray(queryParm)
        println("testCodeSystem2 " + jsonArray?.toString())
        return jsonArray

    }

    static String testTag1() {
        def queryParm = "2.16.840.1.113883.6.96:C1457887"
        def jsonArray = getTermsToJSONArray(queryParm, 'en')
        println("testTag1 " + jsonArray?.toString())
        return jsonArray

    }

    static String testTerm1() {
        def queryParm = "2.16.840.1.113883.6.96:C1457887"
        def jsonArray = getTermsToJSONArray(queryParm, 'en')
        println("testTerm1 " + jsonArray?.toString())
        return jsonArray

    }

    /*

assert resp.contentType == JSON.toString()
assert ( resp.data instanceof net.sf.json.JSON )
assert resp.data.status.size() > 0
     */

    /**
     *
     * @param jsonArray
     * @return  List of Label values; sorted by label
     */
    static List<ViewLabelValue> transformToTermLabelValue(jsonArray) {
        List<ViewLabelValue> lvs = new ArrayList<ViewLabelValue>()
        if (jsonArray) {
            try {
                //for (int i = 0;� i < jsonArray.length(); ++i)  --> .length does not work
                jsonArray.each { row ->

                    String codeSystem = row.getString("codeSystem");
                    String code = row.getString("code");
                    String prefLabel = row.get("prefLabel");

                    String lang = row.containsKey("locale") ? row.get("locale") : 'en'

                    ViewLabelValue lv = new ViewLabelValue(codeSystem + ':' + code, prefLabel, lang)
                    lvs.add(lv)
                }
            } catch (Exception e) {
                println("transformToTermLabelValue exception" + e)
            }
        }
        //list.sort{it.name}  or assert ['a1', 'A2', 'a3'] == ['A2','a3', 'a1'].sort { a, b -> a.compareToIgnoreCase b }

       // try { sorting against mix labels 1 hr, 15 min,etc
        //    if(lvs) lvs.sort{it.value}
        //} catch(Exception e){}
       // if(lvs) lvs.sort{ a, b -> a.value.compareToIgnoreCase() b }

        return lvs

    }

    /**
     *
     * @param pathVar
     * @param queryMap
     * @return JSONArray
     */
    static def doJsonQueryToJSONArray(String pathVar, queryMap) {
        //def client = RestServices.getPhrsCoreRestClient() //new RESTClient(SERVER_URL)

        try {
            RESTClient client = getVocabularyRestClient()

            //if (client.headers.st) println("client not null")

            //println("doJsonQueryToJSONArray pathVar= " + pathVar + " queryMap= " + queryMap)

            groovyx.net.http.HttpResponseDecorator theResponse = client.get(path: pathVar, query: queryMap, contentType: JSON, requestContentType: JSON)
            if (InteropServerClient.validateContentResponse(theResponse) && theResponse?.data) {
                return theResponse.data
            }

        } catch (Exception e) {
            println(e.stackTrace)
        } finally {
        }
        println("doJsonQueryToJSONArray() fail ")
        return null
    }
    /**
     * expect only useful for getting all terms for a particular code system, and not a codesystem:code
     * @param uri
     * @param language
     * @return
     */
    static List<ViewLabelValue> getTermsToLabelValues(String uri, String language) {

        //single results vs multiple result?
        def queryMap = [q: uri]
        println("getTermsToLabelValues uri=" + uri)
        def jsonArray = doJsonQueryToJSONArray(REST_PATH_VOCAB_REPOSITORY + REST_PATH_VOCAB_GET_ALL_BY_CODE_SYSTEM, queryMap)
        //println("json=" + jsonArray)

        def lvs = transformToTermLabelValue(jsonArray)
        //println("lvs=" + lvs)
        return lvs
    }
/**
 * expect only useful for getting all terms for a particular code system, and not a codesystem:code
 * @param uri
 * @param language
 * @return
 */
    static def getTermsToJSONArray(String uri, String language) {


        def queryMap = [q: uri]
        def jsonArray = doJsonQueryToJSONArray(REST_PATH_VOCAB_REPOSITORY + REST_PATH_VOCAB_GET_ALL_BY_CODE_SYSTEM, queryMap)
        return jsonArray
    }
    //getForTag?q=2.16.840.1.113883.6.96:C1457887
    /*
   static String getTermsByTagJson(String paramValue) {
       return getTermsByTagJson(paramValue, 'en')
   } */


    static def getTermsByTagToJSONArray(String paramValue, String language) {

        // groovyx.net.http.HttpResponseDecorator theResponseMain
        def queryMap = [q: paramValue]
        def jsonArray = doJsonQueryToJSONArray(REST_PATH_VOCAB_REPOSITORY + REST_PATH_VOCAB_ACTION_GET_ALL_BY_TAG, queryMap)

        return jsonArray

    }

    static List<ViewLabelValue> getTermsByTagToLabelValues(String paramValue, String language) {

        // groovyx.net.http.HttpResponseDecorator theResponseMain
        def queryMap = [q: paramValue]
        def jsonArray = doJsonQueryToJSONArray(REST_PATH_VOCAB_REPOSITORY + REST_PATH_VOCAB_ACTION_GET_ALL_BY_TAG, queryMap)

        def lvs = transformToTermLabelValue(jsonArray)
        return lvs

    }
    /**
     * Used for label lookup, if term is not found, then the code is used as the label
     * @param term
     * @param language
     * @return
     */
    static def ViewLabelValue getTermToLabelValue(String term, String language) {

        def queryMap = [q: term]
        ViewLabelValue lv

        try {
            def jsonArray = doJsonQueryToJSONArray(REST_PATH_VOCAB_REPOSITORY + REST_PATH_VOCAB_GET_ALL_BY_CODE_SYSTEM, queryMap)
            def lvs = transformToTermLabelValue(jsonArray)

            if (lvs) {
                lv = lvs.get(0)
            }


        } catch (Exception e) {
            println("getTermToLabelValue exception" + e)
        }

        if (!lv) lv = new ViewLabelValue(term, term, language)

        return lv
    }

    static RESTClient getVocabularyRestClient() {

        if (PhrsCoreInitialization.getInstance().isInteropVocabServerLoaded) {
            return getRestClient()
        } else {
            boolean success = loadVocabularyFeaturesServer()
            if (success) return getRestClient()
        }
        println("getInteropRestClient FAIL to get interop server access")
        return null

    }

    static boolean loadVocabularyFeaturesServer() {

        def pathVar = REST_PATH_VOCAB_REPOSITORY + "load"
        def queryMap = [:]
        try {
            RESTClient client = getRestClient()
            //println("doJsonQueryToJSONArray pathVar= " + pathVar + " queryMap= " + queryMap)

            groovyx.net.http.HttpResponseDecorator theResponse = client.get(path: pathVar, query: queryMap, contentType: JSON, requestContentType: JSON)
            //println("GET response" + theResponse)
            if (theResponse.success) {
                PhrsCoreInitialization.getInstance().setIsInteropVocabServerLoaded(true)
                //println("loadInteropFeaturesServer LOADED - SUCCESS")
                return true
            }

        } catch (Exception e) {
            println(e.stackTrace)
        } finally {
        }
        println("loadInteropFeaturesServer NOT LOADED - FAIL")
        return false
    }
    /**
     * Use getVocabularyRestClient directly because it checks if vocabulary is loaded
     *
     * @return if null, server is down or wrong port,etc
     * if null, use to set flags elsewhere to indicate availability.
     */
    static RESTClient getRestClient() {
        RESTClient client

        try {
            client = new RESTClient(PhrsCoreInitialization.getInstance().getCoreServerUrl())
        } catch (Exception e) {

            println("client error=" + e)
        }
        return client
    }

    /*

    def static String mapToJson(Map map) {
        net.sf.json.JSONObject jsonObject = new net.sf.json.JSONObject()
        jsonObject.putAll(map)
        String j = jsonObject.toString()

    }

    def static Map stringToMap(String jsonString) {
        net.sf.json.JSONObject obj = net.sf.json.JSONObject.fromObject(jsonString);
        Iterator i = obj.entrySet().iterator();
        while (i.hasNext()) {
            Map.Entry e = (Map.Entry) i.next();
            System.out.println("Key: " + e.getKey());
            System.out.println("Value: " + e.getValue());
        }
        Map map = obj.to
        return map
    }

    def static displayJsonMap(String jsonString) {
        net.sf.json.JSONObject obj = net.sf.json.JSONObject.fromObject(jsonString);
        Iterator i = obj.entrySet().iterator();
        while (i.hasNext()) {
            Map.Entry e = (Map.Entry) i.next();
            System.out.println("Key: " + e.getKey());
            System.out.println("Value: " + e.getValue());
        }

    } */


}
