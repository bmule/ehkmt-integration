package at.srfg.kmt.ehealth.phrs.presentation.utils

import static groovyx.net.http.ContentType.JSON

import groovyx.net.http.RESTClient
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import net.sf.json.JSONObject




class InteropServerClient {

    private static Logger logger = LoggerFactory.getLogger(InteropServerClient.class);


    public static final String PATH_INTEROP_CLASS_REPOSITORY = "dataexchange_ws/dynamic_class_repository/"
    public static final String PATH_INTEROP_CLASS_REPOSITORY_ACTION = "loadDefaultClasses"


    public static final String PATH_INTEROP_BEAN_REPOSITORY = "dataexchange_ws/dynamic_bean_repository/"

    public static final String ACTION_PERSIST_BEAN = "persist"
    public static final String ACTION_PERSIST_PARAM_DYNABEAN = "dynaBean" //this is a post and not a key in queryMap ??

    public static final String ACTION_GET_BEANS_FOR_CLASS = "getAllForClass"
    public static final String ACTION_GET_BEANS_FOR_CLASS_PARAM_CLASS_URI = "class_uri"

    //param is dynaBean={

    /*

CONTEXT=dataexchange_ws/dynamic_bean_repository

# this is the here all the versions for a a bean with class ...BodyWeight are
# pulled from the repository.
//get???
curl --fail  -X GET $HOST/$CONTEXT/getAllForClass?
}

HOST=http://localhost:8080
CONTEXT=dataexchange_ws/dynamic_bean_repository

# Here I send to the backend a BodyWeight in JSON form to be persisted
curl --fail -X POST --data 'dynaBean=


------
 CONTEXT=dataexchange_ws/dynamic_class_repository

#curl --fail -X GET $HOST/$CONTEXT/get?q=2.16.840.1.113883.6.96:19019007
curl --fail -X GET $HOST/$CONTEXT/loadDefaultClasses

*/

    /**
     *
     * @param pathVar
     * @param queryMap
     * @return
     * groovyx.net.http.HttpResponseDecorator response if successful (status code < 400) or NULL.  The response.data is normally null
     */
    static def doJsonPostInterop(String pathVar, bodyMap) {
        RESTClient client

        try {
            def json = bodyMap.dynaBean

            client = getInteropRestClient()
            //println("doJsonQueryToJSONArray pathVar= " + pathVar + " queryMap= " + queryMap)

            groovyx.net.http.HttpResponseDecorator theResponse =
            client.post(
                    path: pathVar,
                    body: json, //bodyMap,
                    contentType: JSON,
                    requestContentType: JSON)

            //println("GET response" + theResponse)
            if (InteropServerClient.validatePersistResponse(theResponse)) {
                return theResponse
            }
            //println("response = " + theResponse)
            //return theResponse?.data ? theResponse.data : null

        } catch (Exception e) {
            println(e.stackTrace)
        } finally {
            client = null
        }
        return null
    }
    /*
   uri
    Either a URI, URL, or object whose toString() method produces a valid URI string. If this parameter is not supplied, the HTTPBuilder's default URI is used.
path
    Request path that is merged with the URI
query
    Map of URL query parameters
headers
    Map of HTTP headers
contentType
    Request content type and Accept header. If not supplied, the HTTPBuilder's default content-type is used.
requestContentType
    content type for the request, if it is different from the expected response content-type
body
    Request body that will be encoded based on the given contentType
     */

    static boolean validatePersistResponse(groovyx.net.http.HttpResponseDecorator theResponse) {
        boolean success = theResponse?.success ? true : false
        return success
    }

    static boolean validateContentResponse(groovyx.net.http.HttpResponseDecorator theResponse) {
        boolean success = theResponse?.getStatus() != 204 ? true : false
        return success
    }

    static def doJsonGetInterop(String pathVar, queryMap) {
        try {
            RESTClient client = getInteropRestClient()

            groovyx.net.http.HttpResponseDecorator theResponse = client.get(path: pathVar, query: queryMap, contentType: JSON, requestContentType: JSON)

            if (InteropServerClient.validateContentResponse(theResponse) && theResponse?.data) {
                return theResponse.data
            }

        } catch (Exception e) {
            println(e.stackTrace)
            logger.error(" Restfull access error on POST doJsonGetInterop", e)
        } finally {
        }
        return null
    }
    //getAllForClass?class_uri     , String jsonObj
    /**
     *
     * @param params - must have classUri
     * @return groovyx.net.http.HttpResponseDecorator
     *
     * Map params = [:]
     * params.classUri=
     * groovyx.net.http.HttpResponseDecorator response = InteropServerClient.restGetAllByClass(params)
     */
    static def restGetAllByClass(Map params) {

        def classUri = params?.classUri ? params.classUri : params?._phrsBeanClassUri ? params._phrsBeanClassURI : null
        //TODO  when core query supports: def ownerUri = params?._phrsBeanOwnerUri  ? params._phrsBeanOwnerUri :null
        //_phrsBeanClassURI
        def ownerUriFilter = params?.ownerUri ? params.ownerUri : params?._phrsBeanOwnerUri ? params._phrsBeanOwnerUri : null
        def path = PATH_INTEROP_BEAN_REPOSITORY + ACTION_GET_BEANS_FOR_CLASS

        def response

        if (classUri) {

            def queryMap = [(ACTION_GET_BEANS_FOR_CLASS_PARAM_CLASS_URI): classUri]
            response = doJsonGetInterop(path, queryMap)

        }
        return response   //json array list of objects that must be transformed to bean class

    }

    /**
     *
     * @param params
     * @return groovyx.net.http.HttpResponseDecorator
     * must have jsonString of object to persist, object must have _phrsBeanUri with known loaded class
     *
     * Map params = [:]

     * groovyx.net.http.HttpResponseDecorator response = InteropServerClient.restPersistObject(params)
     *
     */
    static groovyx.net.http.HttpResponseDecorator restPersistObject(jsonObject) {
        //static def doJsonQueryToJSONArray(String pathVar, queryMap, String language) {
        //def client = RestServices.getPhrsCoreRestClient() //new RESTClient(SERVER_URL)
        //  def classUri  no param for classUri, that is in the object
        //keep as def!!
        //def jsonString = params?.jsonString ? params.jsonString : params?.(ACTION_PERSIST_PARAM_DYNABEAN) ? params.(ACTION_PERSIST_PARAM_DYNABEAN) : null
        if (jsonObject) {
            def queryMap = ["dynaBean": jsonObject]

            def path = PATH_INTEROP_BEAN_REPOSITORY + ACTION_PERSIST_BEAN //persist
            def response = doJsonPostInterop(path, queryMap)

            return response
        }
        return null
    }

    static groovyx.net.http.HttpResponseDecorator restPersistParamMap(Map params) {
        //static def doJsonQueryToJSONArray(String pathVar, queryMap, String language) {
        //def client = RestServices.getPhrsCoreRestClient() //new RESTClient(SERVER_URL)
        //  def classUri  no param for classUri, that is in the object
        //keep as def!!
        def jsonString = params?.jsonString ? params.jsonString : params?.(ACTION_PERSIST_PARAM_DYNABEAN) ? params.(ACTION_PERSIST_PARAM_DYNABEAN) : null
        if (jsonString) {
            def queryMap = ["dynaBean": jsonString]

            def path = PATH_INTEROP_BEAN_REPOSITORY + ACTION_PERSIST_BEAN //persist
            def response = doJsonPostInterop(path, queryMap)

            return response
        }
        return null
    }
    /*
     static def restRetrieveObject(obj){
            //static def doJsonQueryToJSONArray(String pathVar, queryMap, String language) {
        //def client = RestServices.getPhrsCoreRestClient() //new RESTClient(SERVER_URL)

        try {
            RESTClient client = getRestClient()
            //if (client.headers.st) println("client not null")

            //println("doJsonQueryToJSONArray pathVar= " + pathVar + " queryMap= " + queryMap)

            //groovyx.net.http.HttpResponseDecorator
            def theResponse = client.get(path: pathVar, query: queryMap, contentType: JSON, requestContentType: JSON)
            return theResponse?.data ? theResponse.data : null

        } catch (Exception e) {
            println(e.stackTrace)
        } finally {
        }
        println("doJsonQueryToJSONArray null")
        return null

    }
     */
    /**
     * Wraps RestClient - Checks if interop server classes are load, then returns rest client.
     * Use this instead of getRestClient directly
     * @return
     */
    static RESTClient getInteropRestClient() {
        //log.info "here"
        if (PhrsCoreInitialization.getInstance().isInteropClassesLoaded) {
            return getRestClient()
        } else {
            boolean success = loadInteropFeaturesServer()
            if (success) return getRestClient()
        }


        println("getInteropRestClient FAIL to get interop server access")
        return null

    }

    static boolean loadInteropFeaturesServer() {

        def pathVar = PATH_INTEROP_CLASS_REPOSITORY + PATH_INTEROP_CLASS_REPOSITORY_ACTION
        def queryMap = [:]
        RESTClient client
        try {
            client = getRestClient()
            groovyx.net.http.HttpResponseDecorator theResponse = client.get(path: pathVar, query: queryMap, contentType: JSON, requestContentType: JSON)

            if (theResponse?.success) {
                PhrsCoreInitialization.getInstance().setIsInteropClassesLoaded(true)
                //println("loadInteropFeaturesServer LOADED - SUCCESS")
                return true
            }

        } catch (Exception e) {
            println(e.stackTrace)
        } finally {
            client = null
        }
        // logger.log(Level.SEVERE"loadInteropFeaturesServer failed")

        println("loadInteropFeaturesServer NOT LOADED - FAIL")
        return false
    }

    static RESTClient getRestClient() {
        RESTClient client

        try {
            client = new RESTClient(PhrsCoreInitialization.getInstance().getCoreServerUrl())
        } catch (Exception e) {

            println("client error=" + e)
        }
        return client
    }

    static JSONObject transform(restJson) {
        JSONObject jsonObject;
        try {
            jsonObject = JSONObject.fromObject(restJson);
        } catch (RuntimeException rte) {
            //LOGGER.error("This dynabean JSON representation [{}] is not valid", dynaBean);
            //  LOGGER.error(rte.getMessage(), rte);
            //return Response.status(Status.BAD_REQUEST).build();
        }
        return jsonObject
    }
}