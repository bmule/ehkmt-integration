package at.srfg.kmt.ehealth.phrs.presentation.utils

/**
 * User: bmulreni
 */
class Temp {

    def test = {
        VocabServerLookup.testTerms()
    }

}
