package at.srfg.kmt.ehealth.phrs.presentation.utils

import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User
import net.sf.json.JSONObject
import org.apache.commons.logging.LogFactory
import org.apache.commons.logging.Log

/**
 Note: do not use the IDE reformating feature, it will alter some groovy code using GStrings
 and add spaces before quotes
 findAllBy"${xx  --> findAllBy" ${xx
 */
class PresentationUtils {
    private transient final Log LOGGER = LogFactory.getLog( this.getClass() );

    def processResourceInit = { attrs ->

        def beanInput = attrs.instanceName
        def classUri = attrs.classUri
        def paramsMap = attrs.params
        def theAuthenticatedUser = attrs.authenticatedUser
        //def attrMap = attrs.attrMap

        //print("processResourceInit start")
        //TODO when user is allowed to save another users object
        def user = theAuthenticatedUser ? theAuthenticatedUser : testUser
        beanInput?.ownerUser = theAuthenticatedUser
        //println("user id=" + user?.id)
        //println("user.healthProfileUid=" + user?.healthProfileUid)

        beanInput?._phrsBeanOwnerUri = user?.healthProfileUid
        beanInput?._phrsBeanCreatorUri = user?.healthProfileUid
        //set the primary time
        beanInput?._phrsBeanClassURI = classUri
        //beanInput?.getClass().toString()

        return true
    }

    //security: the init object or any edited objected on the client could be changed by client,
    def processResourceToPersist = { attrs ->

        def beanInput = attrs.instanceName
        //def className = attrs.className
        def classUri = attrs.classUri
        def paramsMap = attrs.params
        def theAuthenticatedUser = attrs.authenticatedUser
        // def attrMap = attrs.attrMap

        //print("processResourceToPersist start")
        //TODO when user is allowed to save another users object
        def user = theAuthenticatedUser ? theAuthenticatedUser : testUser
        //beanInput?.user = user
        beanInput?.ownerUser = theAuthenticatedUser
        //println("user id=" + user?.id)
        //println("user.healthProfileUid=" + user?.healthProfileUid)

        beanInput?._phrsBeanOwnerUri = user?.healthProfileUid
        beanInput?._phrsBeanCreatorUri = user?.healthProfileUid
        //set the primary time, reset primary type in case of corruption
        beanInput?._phrsBeanClassURI = classUri

        return true
    }
    /**
     * finding resources action: action, classUri, filterOwnerUri, theAuthenticatedUser
     * presisting action: action, classUri,, jsonObject
     */
    def processResourceInterop = { attrs ->

        def beanInput = attrs?.instanceName
        def className = attrs?.className
        def classUri = attrs?.classUri
        def paramsMap = attrs?.params
        def theAuthenticatedUser = attrs?.authenticatedUser
        def action = attrs?.action ? attrs.action : null
        def jsonObject = attrs?.jsonObject ? attrs.jsonObject : null
        def authorizationCheck = attrs?.authorizationCheck ? attrs.authorizationCheck : false
        def filterOwnerUri = attrs?.filterOwnerUri ? attrs.filterOwnerUri : theAuthenticatedUser ? theAuthenticatedUser : null
        // def queryProperty_1 =  attrs?.queryProperty ? attrs.queryProperty : null
        // def queryProperty_2 =  attrs?.queryProperty_2 ? attrs.queryProperty_2 : null

        def result
     /*
                        boolean okInterop = PhrsCommonsService.processResourceInterop(
                            ['instanceName': medicationSummaryInstance,
                                    'className': MedicationSummary,
                                    'jsonObject': medicationSummaryInstance.encodeAsJSON(),
                                    'classUri': CLASS_URI, 'params': params,
                                    'authenticatedUser': authenticatedUser,
                                    'action': PortalConstants.ACTION_CONTROLLER_SAVE])
      */
        if (jsonObject && action) {
            switch (action) {
                case PortalConstants.ACTION_CONTROLLER_SAVE:

                    if(PortalConstants.CORE_JSON_TEST) {
                         println("json out classUri?"+classUri)
                         println("json out jsonObject?"+jsonObject)
                    }
                    groovyx.net.http.HttpResponseDecorator response = InteropServerClient.restPersistObject(jsonObject)
                    if(PortalConstants.CORE_JSON_TEST) {
                          println("json out classUri?"+response)
                    }
                    break;

                case PortalConstants.ACTION_CONTROLLER_DELETE:
                    //
                    break;

                case PortalConstants.ACTION_CONTROLLER_LIST:
                    //
                    break;
                case PortalConstants.ACTION_CONTROLLER_SHOW:
                    //
                    break;
                case PortalConstants.ACTION_CONTROLLER_SHOW_HISTORY_ALL_CORE_EHR:
                    //groovyx.net.http.HttpResponseDecorator response =
                    //history of one item resource?
                    def objectList
                    if (classUri && filterOwnerUri) {
                        def response = InteropServerClient.restGetAllByClass(
                                ['_phrsBeanClassURI': classUri, '_phrsBeanOwnerUri': filterOwnerUri])
                        //pass JSONArray result when not null
                        objectList = response?.data && className ? transformToDomainObjectsUsingClassSample(response.data, className) : []
                        //filter list or compare with other existing.
                    }
                    return objectList
                    break;
                case PortalConstants.ACTION_CONTROLLER_SHOW_NEW_CORE_EHR_OBJECTS:
                    //groovyx.net.http.HttpResponseDecorator response =
                    //history of one item resource?
                    def objectList
                    if (classUri && filterOwnerUri) {
                        def response = InteropServerClient.restGetAllByClass(
                                ['_phrsBeanClassURI': classUri, '_phrsBeanOwnerUri': filterOwnerUri])
                        //pass JSONArray result when not null

                        objectList = response?.data && className ? transformToDomainObjectsUsingClassSample(response.data, className) : []
                        //filter list or compare with other existing.
                        def filterIds = findObjectUris(classUri, '_phrsBeanOwnerUri', filterOwnerUri)
                    }
                    return objectList
                    break;
                default:
                    //required
                    break;
            }

            return result
        }

        // _phrsBeanOwnerUri   _phrsBeanCreatorUri _phrsBeanClassURI theAuthenticatedUser
        //beanInput?._phrsBeanCreatorUri = user?.healthProfileUid

        return true
    }

    static List discoverNewResourcesOnHub(attrs) {
        //TODO FIXME   discoverNewResourcesOnHub
        def beanInput = attrs?.instanceName
        def className = attrs?.className
        def instance = attrs?.instance  //optional unless class name there
        def classUri = attrs?.classUri

        def paramsMap = attrs?.params
        def theAuthenticatedUser = attrs?.authenticatedUser
        def action = attrs?.action ? attrs.action : null
        //def jsonObject = attrs?.jsonObject ? attrs.jsonObject : null
        def authorizationCheck = attrs?.authorizationCheck ? attrs.authorizationCheck : false
        def filterOwnerUri = attrs?.filterOwnerUri ? attrs.filterOwnerUri : theAuthenticatedUser ? theAuthenticatedUser : null

        def resultList
        if (classUri && theAuthenticatedUser) {// and more..
            if (filterOwnerUri) {
                //TODO
            }

            def response = InteropServerClient.restGetAllByClass(["classUri": classUri]) //_phrsBeanOwnerUri, classUri or _phrsBeanClassURI

            if (response?.data && className) {
                resultList = transformToDomainObjectsUsingClassSample(response.data, className)
                //TODO discoverNewResourcesOnHub get list of ids...
            } else if (response?.data && instance) {
                resultList = transformToDomainObjectsUsingInstanceSample(response.data, instance)
            }
        }

        return resultList
    }
/*
see findObjectUris(resourceClazz, property, value) to provide (param: removeStringIdList or filterIds )
    get filtered list of objects e.g. label values or domain objects passed in as (labelValueList or fullObjectList)
pass list of labelvalues and list of string ids to remove based on matching to labelValue.id
param : use name either: fullObjectList or  labelValueList
param: ruser name either: emoveStringIdList or filterIds

findAllBy"${property}"(value)
findAllBy"${property}And${property2}"(value,value2)
Property must have upper case unless starting with underscore...
*/
/**
 *
 * @param jsonArray
 * @param domainObjectInstanceSample e.g.  the domain classes are injected into all controllers, not the instance
 * @return
 */
    static List transformToDomainObjectsUsingInstanceSample(jsonArray, domainObjectInstanceSample) { //instance
        List results = new ArrayList()
        List results2 = new ArrayList()
        if (jsonArray) {
            try {
                //for (int i = 0; i < jsonArray.length(); ++i)  --> .length does not work
                jsonArray.each { row ->

                    try {
                        if (row) {
                            //Class classDebugView = domainObjectInstanceSample.getClass() //success! correct class
                            def instance = JSONObject.toBean(row, domainObjectInstanceSample.getClass());
                            //def instance21 = JSONObject.toBean(row, ObsBodyWeightBMW01.class);
                            results.add(instance)

                            //works ok also def instance2 = JSONObject.toBean(row, classDebugView);
                        }
                    } catch (Exception e) {
                        println("transformToDomainObjects inner row exception" + e)
                    }
                }
            } catch (Exception e) {
                println("transformToDomainObjects exception" + e)
            }
        }
        return results

    }

    static List transformToDomainObjectsUsingClassSample(jsonArray, domainObjectClass) { //instance
        List results = new ArrayList()
        List results2 = new ArrayList()
        if (jsonArray) {
            try {
                //for (int i = 0; i < jsonArray.length(); ++i)  --> .length does not work
                jsonArray.each { row ->

                    try {
                        if (row) {
                            //Class classDebugView = domainObjectInstanceSample.getClass() //success! correct class

                            def instance = JSONObject.toBean(row, domainObjectClass);
                            //def instance21 = JSONObject.toBean(row, ObsBodyWeightBMW01.class);
                            results.add(instance)
                            //println("...instance2="+instance)
                            //def instance2 = JSONObject.toBean(row, classDebugView);
                            //println("...instance2="+instance2)
                        }
                    } catch (Exception e) {
                        println("transformToDomainObjects inner row exception" + e)
                       //log.error(e)
                    }
                }
            } catch (Exception e) {
                println("transformToDomainObjects exception" + e)
            }
        }
        return results

    }

    def queryList = { attrs ->

        //def viewInstanceName = attrs?.viewInstanceName ? attrs.viewInstanceName : attrs?.instanceName ? attrs.instanceName : null  //string
        def viewInstanceName = attrs.instanceName
        def classInstance = attrs?.classInstance ? attrs.classInstance : attrs?.className ? attrs.className : null    //the object
        def classUri = attrs.classUri
        def params = attrs.params
        def theAuthenticatedUser = attrs.authenticatedUser
        def controllerOptionProperties = attrs.controllerOptionProperties
        def theAction = attrs.theAction

        //user search term from params or the uri from the auth user.

        def filterSearchOwnerUri = params?._phrsBeanOwnerUri ? params?._phrsBeanOwnerUri : theAuthenticatedUser?.healthProfileUid ? theAuthenticatedUser?.healthProfileUid : testUser?.healthProfileUid
        //println("filterSearchOwnerUri=" + filterSearchOwnerUri)

        //restrict view, check later
        params._phrsBeanOwnerUri = filterSearchOwnerUri
        // className.list(params)
        // .findAllBy_phrsBeanOwnerUri
        //Set params.max


        String stringList = "${viewInstanceName}List"
        String stringTotal = "${viewInstanceName}Total"
        //println("p set bef="+params.entrySet())
        //change source object ...
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        //println("p set after="+params.entrySet())
        //parenthesis needed bc groovy will use string contents, not string name
        def results = [
                (stringList): classInstance.list(params),
                (stringTotal): classInstance.count(),
                'theAction': 'list',
                'visualizationAttributes': visualizationAttributes(['classUri': classUri]),
                'controllerOptionProperties': controllerOptionProperties]

        //println("queryList results="+results?.entrySet())
        return results

    }
    /** *
     *
     * @param resourceClazz
     * @param property - must be property in a local domain model
     * @param value
     * @return
     */
    /*
 findAllBy"${property}"(value)
 findAllBy"${property}And${property2}"(value,value2)

 ."findAllBy${property}"
     */

    static Set findObjectUris(resourceClazz, property, value) {
        Set uris
        //TODO resource?._phrsBeanUri
        //capitalize() first letter of word
        try {
            if (property) {
                def thisProperty = property.startsWith('_') ? property : property.capitalize()
                def resources = resourceClazz."findAllBy${property}"(value)
            }
        } catch (Exception e) {
            println(e)
        }
        //Phrs_uri
        return uris
    }

    static Set findObjectUris(resourceClazz, property, value, property2, value2) {
        Set uris
        //resource?._phrsBeanUri
        def resources = resourceClazz."findAllBy${property}And${property2}"(value, value2)
        //Phrs_uri
        return uris
    }

    def visualizationAttributes = { attrs ->
        def classUri = attrs?.classUri
        def props = [:]
        //['chartType': 'val1', 'xcord': 'prop1, prop2, prop3', 'y-coord': 'prop5,prop6']
        return props

    }
    def processController = { attrs ->
        //def theController = attrs.theController
        return true
    }

    def testUser = {
        def testUser = User.exists(1) ? User.exists(1) : null
        if (testUser == null) {
            testUser = new User()

        }

        return testUser
    }
/**
 * Can be used with findObjectUris(resourceClazz, property, value) to provide (param: removeStringIdList or filterIds )
 * return is the filtered list of objects e.g. label values or domain objects passed in as (labelValueList or fullObjectList)
 pass list of labelvalues and list of string ids to remove based on matching to labelValue.id
 param : use name either: fullObjectList or  labelValueList
 param: ruser name either: removeStringIdList or filterIds
 */
    def filterLabelValueListByIdList = { attrs ->
        //println "Fruits: ${xml.item.findAll {it.type == 'Fruit'}*.name }"

        def fullLabelValueList = attrs?.labelValueList ? attrs.labelValueList : attrs?.fullObjectList ? attrs.fullObjectList : null
        def removeStringIdList = attrs?.filterIds ? attrs.filterIds : attrs?.removeStringIdList ? attrs.removeStringIdList : null


        def results = new ArrayList<ViewLabelValue>()
        try {
            if (fullLabelValueList != null && !fullLabelValueList.isEmpty() && removeStringIdList && !removeStringIdList.isEmpty()) {

                fullLabelValueList.collect { labelValue ->
                    def id = labelValue?.id ? labelValue.id : null

                    if (id && !removeStringIdList.contains(id)) {
                        results.add(labelValue)
                    }
                }

            } else if (fullLabelValueList) {
                //nothing to remove
                results.addAll(fullLabelValueList)
            } else {
                //error

            }
        } catch (Exception e) {
        }
        return results
    }

    def importPhrByUser = {

        def classUriInterop = attrs?.classUriInterop ? attrs.classUriInterop : null
        def viewInstanceName = attrs.instanceName
        def classInstance = attrs?.classInstance ? attrs.classInstance : attrs?.className ? attrs.className : null    //the object
        def classUri = attrs.classUri
        def params = attrs.params
        def theAuthenticatedUser = attrs.authenticatedUser
        def controllerOptionProperties = attrs.controllerOptionProperties
        def theAction = attrs.theAction

        //user search term from params or the uri from the auth user.

        def filterSearchOwnerUri = theAuthenticatedUser?.healthProfileUid ? theAuthenticatedUser?.healthProfileUid : testUser?.healthProfileUid
        //params?._phrsBeanOwnerUri ? params?._phrsBeanOwnerUri :
        println("filterSearchOwnerUri=" + filterSearchOwnerUri)

        //restrict view, check later
        params._phrsBeanOwnerUri = filterSearchOwnerUri

        //params.max = Math.min(params.max ? params.int('max') : 10, 100)
        /*
       TODO query core for two params (_phrsBeanOwnerUri,) if only one then by _phrsBeanOwnerUri
       get list of known objects and compare with core objects:  _phrsBeanUri
       Create new instance , load direct via json or json -> map or grails instance.properties = params
        //obsBodyWeightBMW01Instance.properties = params
        */

    }

}
