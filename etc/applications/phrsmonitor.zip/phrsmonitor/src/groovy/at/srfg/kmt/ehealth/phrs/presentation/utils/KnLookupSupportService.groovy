package at.srfg.kmt.ehealth.phrs.presentation.utils



class KnLookupSupportService {
    static boolean TESTSYSTEM = true
    /*
    def lookupTermList = { attrs ->

        def classUri = attrs?.classUri ? attrs.classUri : null
        def tagUri = attrs?.tagUri ? attrs.tagUri : null
        //def format =   attrs?.format ? attrs.format : null

        //if service available, get it otherwise, get local vocab

        //def lv = new  ViewLabelValue()
    } */
    /*
    list of vocab items to label values
     */
    def formatToLabelValue = { attrs ->
        def phrsTermList = attrs?.phrsTermList
        if (phrsTermList) {
            phrsTermList.each { it ->
                println("phrsTermList it " + it)

            }
        }

    }


    public static List<ViewLabelValue> lookupTerminology(List<String> types) {
        List<ViewLabelValue> results = new ArrayList<ViewLabelValue>()

        if (types != null) println("lookupTerminology cats size=" + types.size())

        for (String type: types {
            try {
                def res = lookupUITerminologyList(['tag': type])
                if (res != null && !res.isEmpty()) results.add(res)
            } catch (Exception e) {
            }

        })

            if (results?.size() > 1) {
                //error, don't allow selection of default ??

            } else {
                results = new ArrayList<ViewLabelValue>()
            }

        return results;

    }
    /**
     *
     */
    static def lookupUITerminologyList = { attrs ->
        //KnLookupSupportService.testStuff(['one':'one123'])

        //println("lookupTerminologyList 0")

        List list = new ArrayList<ViewLabelValue>()

        String classedProperty = attrs?.property  //the class property as one classuri --> class.property
        String language = attrs?.lang ? attrs.lang : 'en'
        List tags = attrs?.tags ? attrs.tags : null
        String tag = attrs?.tag ? attrs.tag : null
        //UI can override and use local vocab
        def useLocalVocab = attrs?.useLocalVocab ? attrs.useLocalVocab : false

        boolean defaultNamespace = true

        if (((tags != null && !tags.isEmpty()) || tag != null && !tag.isEmpty())) {
            //
            // println("lookupTerminologyList 2")
        } else if (classedProperty != null && classedProperty.length() > 1) {
            tag = classedProperty
            //println("lookupTerminologyList assign property to tag")

        } else {
            println("lookupTerminologyList fail")
        }
        List<ViewLabelValue> lookup
        String selector = ''

        if (tag != null) {
            //ok use tag not tags
            //println("lookupTerminologyList selector  tag=" + tag)
            selector = tag

        } else if (tags != null) {

            selector = tags?.size() > 0 ? tags[0] : 'default'
            String[] typesExtract = selector?.split(',')
            selector = typesExtract[0]
            selector = (selector != null) ? selector : 'default'
        } else {
            println("tags and type = null")
        }



        //println("selector=" + selector)
        //println("cats=" + cats.each { item -> println("xxx="+item)})

        /* for(String cat:cats){
                      println("here "+cat.toString())
       } */

        /*
        if (isAvailable && !TESTSYSTEM && !useLocalVocab) {
            try {
                println("vocabularyServer available")

                lookup = IntegratedVocabularyServer.instance().findTermUrisByTagToLabelValues(selector, language, defaultNamespace)
                if (lookup && !lookup.isEmpty()) {
                    //ok
                } else {
                    //lookup local vocabulary
                    println("vocab server results empty: find test terms:")
                    lookup = KnLookupSupportService.findTestTerms(['selector': selector])
                }
            } catch (Exception e) {
                println("vocabulary server not available")
            }


        } else {
            println("...findTestTerms")
            lookup = KnLookupSupportService.findTestTerms(['selector': selector])

        }
         */

        if (isVocabularyServerAvailable()) {

            lookup = VocabServerLookup.getTermsByTagToLabelValues(selector, language) // getTermsToLabelValues(selector, language)
        }

        if (lookup && !lookup.isEmpty()) {
            //println("lookupUITerminologyList lookup " + lookup.size())

        } else if (useLocalVocab || TESTSYSTEM) {
            //println("...find local TestTerms useLocalVocab=" + useLocalVocab + " or testSystem set" + TESTSYSTEM)
            lookup = KnLookupSupportService.findTestTerms(['selector': selector])
        }
        if (lookup) {
            return lookup
        } else {

            //println("lookupUITerminologyList lookup empty return empty")
            return new ArrayList<ViewLabelValue>()
        }
    }

/**
 * @deprecated
 * @return
 */
    public static boolean isVocabularyServerAvailable() {

        return true;
        /*  integrated jboss scenario
       boolean isAvailable = false;
       try {
           IntegratedVocabularyServer vocabularyServer = null
           vocabularyServer = IntegratedVocabularyServer.instance()
           if (IntegratedVocabularyServer.isServerAvailable()) {
               println("vocabularyServer available")
               isAvailable = true
           } else {
               isAvailable = false
               println("vocabularyServer NOT available")
           }

       } catch (Exception e) {
           isAvailable = false
           println("vocabulary server not available")
       }
       return isAvailable;*/
    }


    static def findTestTerms = { attrs ->
        //println("findTestTerms")
        def selector = attrs?.selector ? attrs.selector : 'default'

        //println("findTestTerms selector=" + selector)

        List<ViewLabelValue> lookup
        //def lookup
        switch (selector) {

            case PortalConstants.TERM_ACTIVITY_LIFESTYLE_STATUS_VALUE:

                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'unassistedActivity', 'I can do without assistance'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'assistedActivity', 'I can do with assistance')
                ];
                break;
            case PortalConstants.TERM_SNOMED_SYMPTOM:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Chest Pain', 'Chest Pain'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Diarrhea', 'Diarrhea'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Fever', 'Fever'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Fatique', 'Fatique'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Rashes', 'Rashes'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Shortness of Breath', 'Shortness of Breath'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Swelling of the feet', 'Swelling of the feet'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Vomiting', 'Vomiting'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Increased Weight', 'Increased Weight'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'other', 'Other Symptom')
                ]; break;


            case PortalConstants.TERM_ACTIVITY_OF_DAILY_LIVING_PHRS:

                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'bathing', 'bathing'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'climbstairs', 'climbstairs'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'drivingcar', 'drivingcar'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'gardening', 'gardening'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'shopping', 'shopping')];
                break;


            case PortalConstants.TERM_DRUG_CONSUMPTION_STATUS_CODE_PHRS:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'active', 'Currently taking'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'completed', 'Completed')
                ]; break
                                        
               //new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'discontinued', 'discontinued')
            case PortalConstants.TERM_DOSAGE_UNITS:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'milligram', 'Milligrams'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'tablet', 'Tablets')
                        // new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'other', 'Other')
                ]; break


            case PortalConstants.TERM_DRUG_FREQUENCY_INTERVAL_1:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'on_occassion', 'On occasion'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'hourly', 'hourly'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'daily', 'daily'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'weekly', 'weekly'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'yearly', 'yearly'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'other', 'other')
                ]; break;
        //use this OR  TERM_DRUG_FREQUENCY_INTERVAL_1
           /* case [PortalConstants.TERM_DRUG_FREQUENCY_COMBINED,
                    PortalConstants.TERM_DRUG_FREQUENCY_COMBINED_PHRS]:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'on_occassion', 'On occasion'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '1_time_per_day', '1_time_per_day'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '2_time_per_day', '2_time_per_day'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '3_time_per_day', '3_time_per_day'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'other', 'other')
                ]; break;
                */
            case PortalConstants.TERM_DRUG_FREQUENCY_TIME_OF_DAY_1:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'not_specified', 'not specified'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'morning', 'morning'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'noon', 'noon'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'afternoon', 'afternoon'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'evening', 'evening'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'bedtime', 'bedtime')
                ]; break;
             /** @deprecated **/
            case PortalConstants.TERM_DRUG_FREQUENCY_QUANTITY:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '1', '1'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '2', '2'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '3', '3'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '4', '4'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '5', '6'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '7', '8'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '9', '9'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '10', '10'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '11', '11'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '12', '12')
                ]; break;
        //no break between the following cases.


            case [PortalConstants.TERM_RISK_FACTOR_OF_TYPE_OVERVIEW_PHRS,
                    PortalConstants.TERM_RISK_FACTOR_OF_TYPE,
                    PortalConstants.TERM_DRUG_REASON_KEYWORDS]:  //snomed risk of  but there are too many!

                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "diabetes", "Diabetes"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "cholesterol", "Cholesterol"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "hypertension", "Hypertension"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "smoking", "Smoking"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "weight_gain", "Weight gain"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "other", "Other")];
                break;
            case PortalConstants.TERM_DRUG_PRESCRIBED_BY_ROLE:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "general_practitioner", "General Practitioner"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "physician", "physician"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "pharmacist_recommended", "pharmacist recommended"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "other", "Other")];
                break;

            case PortalConstants.TERM_RISK_TREATMENTS_DIABETES:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "diet", "Diet"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "insulin", "Insulin"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "pills", "pills"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "other", "Other"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "no_treatment", "No treatment")
                ];
                break;
            case PortalConstants.TERM_RISK_TREATMENTS_HYPERTENSION:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "diet", "Diet"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "medication", "Medication"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "other", "Other"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "no_treatment", "No treatment")];
                break;
            case PortalConstants.TERM_RISK_TREATMENTS_CHOLESTEROL || PortalConstants.TERM_RISK_TREATMENTS_WEIGHT_GAIN:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "diet", "Diet"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "medication", "Medication"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "other", "Other"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "no_treatment", "No treatment")];
                break;
            case PortalConstants.TERM_RISK_TREATMENTS_SMOKING:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "nicotin_based_medication", "Nicotin based medication"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "no_treatment", "No treatment"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "other", "Other")];
                break;

            case PortalConstants.TERM_RISK_SMOKING_QUANTITY:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "1_pack_per_day", "1 pack per day"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "2_pack_per_day", "2 pack per day"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "3_pack_per_day", "3 pack per day")];
                break;
            case PortalConstants.TERM_RISK_SMOKING_TYPES:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "cigarette", "cigarette"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "cigar", "cigar"),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + "other", "Other")];
                break;


            case PortalConstants.TERM_SNOMED_ACTIVITY_PHYSICAL:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'gardening', 'gardening'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'housework', 'housework'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'jogging', 'jogging'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'swimming', 'swimming'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'walking', 'walking'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'walking_nordic', 'walking_nordic'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'other', 'other')
                ];
                break;

            case PortalConstants.TERM_PHYSICAL_ACTIVITY_DURATION:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '15_min', '15 min'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '45_min', '45 min'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '1_hr', '1 hr'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '2_hr', '2 hr'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '3_hr', '3 hr'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '4_hr', '4 hr'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '5_hr', '5 hr'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '6_hr', '6 hr'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + '7-12 hr', '6 hr'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'more_than_12_hours', 'more than 12 hours')]
                break;


            case PortalConstants.TERM_PHYSICAL_ACTIVITY_FREQUENCY:
                lookup = [
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Every_Day', 'Every_Day'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Few_times_during_week', 'A few times during the week'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Several times per month', 'Several times per month'),
                        new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Every_Month', 'Every_Month')]
                break;

            default:
                lookup = [new ViewLabelValue('', '....')]
            break;

        }

        if (lookup == null) {
            //println("lookup NULL return empty")
            return new ArrayList<ViewLabelValue>()
        } else {
            /*println("lookup=" + lookup.each {lv -> lv})
            lookup.each {
                println("test terms lookup " + it)
            } */
        }
        //println("lookup " + lookup.size())
        return lookup
    }
/*
case PortalConstants.:
lookup = [
      new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Every_Day', 'Every_Day'),
      new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Few_times_during_week', 'A few times during the week'),
      new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Several times per month', 'Several times per month'),
      new ViewLabelValue(PortalConstants.NS_PHR_FORM + ':' + 'Every_Month', 'Every_Month')]
break;  */
/*
PortalConstants.TERM_RISK_TREATMENTS_DIABETES
PortalConstants.TERM_RISK_TREATMENTS_HYPERTENSION
PortalConstants.TERM_RISK_TREATMENTS_CHOLESTEROL
PortalConstants.TERM_RISK_TREATMENTS_SMOKING
*/
/*
private static List<ViewLabelValue> findTestLabelValuesByTag(String tag) {

}

private static Map<String, List<ViewLabelValue>> buildTestVocab() {
   Map<String, List<ViewLabelValue>> vocab = new HashMap<String, List<ViewLabelValue>>()


} */

    public static String localTestLookupFindTermLabel(String tag, String term) {

        return localLookupFindTermLabel(['tag': tag, 'term': term])
    }
/**
 * lookup local vocab crudely
 * tag, term
 * requires tag to get superset of labelvalues and the term (id) in that set
 */
    public static ViewLabelValue localLookupFindTermLabel(String tag, String term) {
        return localLookupFindTermLabel(['tag': tag, 'term': term])
    }

    static def localLookupFindTermLabel = {   attrs ->
        def tag = attrs?.tag ? attrs.tag : null
        def term = attrs?.term ? attrs.term : null

        //looking for one term, get list
        def labelValues = tag ? findTestTerms(['selector': tag]) : null
        //take first one if exists
        ViewLabelValue resultLabelValue = labelValues ? labelValues.find {it?.id == term || it?.uriStandard} : null

        return resultLabelValue

    }
/**
 * helper function rather than using closure lookupTerminologyLabelValue
 * @param code
 * @return
 */
    public static ViewLabelValue lookupTerminologyTermLabel(String term, String language) {
        //println("lookupTerminologyTermLabel 1 term=" + term)
        return lookupTerminologyLabelValue(['term': term, 'lang': language])
    }

    public static ViewLabelValue lookupTerminologyTermLabel(String term) {
        //println("lookupTerminologyTermLabel 2 term=" + term)
        return lookupTerminologyLabelValue(['term': term])
    }
/**
 * returns ViewLabelValue, null if not found
 *
 * term required
 * tag optional, unless using crude lookup
 */
    def static lookupTerminologyLabelValue = { attrs ->

        String term = attrs?.term ? attrs.term : attrs?.code ? attrs.code : null
        //tag not required, only if need for test local lookup eg cannot find it in main vocab server
        String tag = attrs?.tag ? attrs.tag : null
        String language = attrs?.lang ? attrs.lang : 'en'
        String defaultLabel = attrs?.defaultLabel ? attrs?.defaultLabel : null

        boolean isAvailable = isVocabularyServerAvailable()

        ViewLabelValue lv
        if (term == null) {
            //
        } else {
            /*if (isAvailable && !TESTSYSTEM) {
                try {
                    println("vocabularyServer available")

                    lv = IntegratedVocabularyServer.instance().findTermUriToLabelValue(term, language)
                } catch (Exception e) {
                    println("vocabulary server not available")

                }
            }*/
            try {
                //println("vocabularyServer available")

                lv = VocabServerLookup.getTermToLabelValue(term, language) //.findTermUriToLabelValue(term, language)
            } catch (Exception e) {
               // println("vocabulary server not available")

            }

            //println("lookup label method: vocab server?")
            if (lv != null) {
                //println("lookup label method: localLookupFindTermLabel? lv id=" + lv.id + " val=" + lv.value)
                return lv
            }
            //println("lookup label method: localLookupFindTermLabel? tag=" + tag + " term=" + term)

            //closure call must be done differently
            //def lvx = {localLookupFindTermLabel(['tag': tag, 'term': term]) }
            lv = localLookupFindTermLabel(tag, term)

            //use part of uri as label
            if (lv != null) {
               // println("lookup label method: localLookupFindTermLabel? lvx closure id=" + lv?.id + " val=" + lv?.value)

                return lv
            }
            //last chance
            //println("lookup label method:extract code ")
            String label = extractCode(term, defaultLabel)
            lv = new ViewLabelValue(term, label, language)
            //println("lookup label method: localLookupFindTermLabel extractCode? lv id=" + lv.id + " val=" + lv.value)


        }

        return lv

    }

    public static String extractCode(String uri, String defaultCode) {
        String code
        if (uri != null) {
            def parts = uri.split(":")
            if (parts) code = parts.length > 1 ? parts[1] : parts.length == 1 ? parts[0] : defaultCode
        }
        //println("extractCode uri" + uri + " -->code=" + code)
        return code
    }

}