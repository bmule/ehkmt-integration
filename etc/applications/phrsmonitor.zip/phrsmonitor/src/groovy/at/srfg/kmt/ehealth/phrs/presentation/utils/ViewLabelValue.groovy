package at.srfg.kmt.ehealth.phrs.presentation.utils
/**
 * Created by IntelliJ IDEA.
 * HealthProfileIndividual: bmulreni

 */
class ViewLabelValue {

    String id
    String value
    String lang
    String uriStandard
    boolean isStandardUri
    /**
     *
     * @param id
     * @param value
     * @return
     */
    ViewLabelValue(String id, String value) {
        this.id = id;
        this.value = value
    }
    /**
     *
     * @param id
     * @param value
     * @param lang
     * @return
     */
    ViewLabelValue(String id, String value, String lang) {
        this.id = id;
        this.value = value
        this.lang = lang
    }
    /**
     * Setting up a local vs standard coding. The local vocab server might know both codings
     * @param id
     * @param value
     * @param lang
     * @param isStandardUri
     * @param uriStandard
     * @return
     */
    ViewLabelValue(String id, String value, String lang, boolean isStandardUri, String uriStandard) {
        this.id = id;
        this.value = value
        this.lang = lang
        this.uriStandard = uriStandard
        this.isStandardUri = isStandardUri
    }

    static ViewLabelValue createNameValue(String name, String value) {

        new ViewLabelValue(name, value)
    }

    static ViewLabelValue createNameValue(String name, String value, String lang) {

        new ViewLabelValue(name, value, lang)
    }

    static List createIdValue(String id, String value, List list) {

        list.add(ViewLabelValue.createNameValue(id, value))
    }

    static List createIdValue(String id, String value, String lang, List list) {

        list.add(ViewLabelValue.createNameValue(id, value, lang))
    }

    /**
     * Inputs a string list, and create a simple list where id values are the same
     *
     * @param list
     * @return
     */
    static List<ViewLabelValue> createIdValues(List<String> list) {

        List<ViewLabelValue> out = new ArrayList()
        for (j in out) {
            String name = list[j]
            out.add(ViewLabelValue.createNameValue(name, name))
        }
        return out
    }

    static List<ViewLabelValue> createIdValues(Map<String, String> source) {
        List<ViewLabelValue> out = new ArrayList()

        source.keySet().each { key ->
            println "funct key=" + key + " val=" + source[key]
            out.add(ViewLabelValue.createNameValue(key, source[key]))
        }

        return out
    }
    /**
     *
     * @return  label, used by views
     */
    @Override
    public String toString() {
        //return "idValue id=" + id + " value=" + value;
        def out =  value ? value : ""
        return out

    }


}
