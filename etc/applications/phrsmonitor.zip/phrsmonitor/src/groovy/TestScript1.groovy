import at.srfg.kmt.ehealth.phrs.presentation.utils.ViewLabelValue

/**
 * HealthProfileIndividual: bmulreni
 */

       def test = [
                'a11': 'the label a11',
                'one': 'the label one'
        ]

        List testList = ViewLabelValue.createIdValues(test)
        testList.each { entry -> println "test" + "id="+ entry.id +  " value="+ entry.value }


        Expando expandoMain    = new Expando()
        expandoMain.setProperty("phr__status",true)

        expandoMain.setProperty("phr__status",true)
        expandoMain.setProperty("phr__map",[key1:"aaa","key2":"bbb"])


