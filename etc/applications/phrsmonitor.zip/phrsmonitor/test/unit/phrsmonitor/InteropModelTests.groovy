package phrsmonitor

import grails.test.GrailsUnitTestCase

import at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsBloodPressureA01
import at.srfg.kmt.ehealth.phrs.presentation.utils.InteropServerClient
import at.srfg.kmt.ehealth.phrs.presentation.utils.PhrsCoreInitialization
import at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsBodyWeightBMW01
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants
import static groovyx.net.http.ContentType.JSON

import net.sf.json.JSONObject
import groovyx.net.http.RESTClient

import at.srfg.kmt.ehealth.phrs.presentation.utils.PresentationUtils


class InteropModelTests extends GrailsUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }
    /*
    void testGroovyString(){

        ObsBodyWeightBMW01.findAllBy"${property}"
    }*/

    void testGetAllObjectsByClassUsingInstanceSample() {
        def jsonArray = InteropServerClient.restGetAllByClass(["classUri": PortalConstants.MODEL_BODY_WEIGHT_CLASS_URI])


        assertNotNull("objects null" + jsonArray)
        //pass instance instead and take the class, passing the class directly was already tried...
        def resultDomainObjectList = PresentationUtils.transformToDomainObjectsUsingInstanceSample(jsonArray, new ObsBodyWeightBMW01()) // domainObjectClass)
        assertNotNull("resultDomainObjectList null" + resultDomainObjectList)

        assertTrue("objects null or empty", resultDomainObjectList.size() > 1)
    }

    void testGetAllObjectsByClassUsingClassSample() {
        def jsonArray = InteropServerClient.restGetAllByClass(["classUri": PortalConstants.MODEL_BODY_WEIGHT_CLASS_URI])


        assertNotNull("objects null" + jsonArray)
        //pass instance instead and take the class, passing the class directly was already tried...
        def resultDomainObjectList = PresentationUtils.transformToDomainObjectsUsingClassSample(jsonArray, ObsBodyWeightBMW01) // domainObjectClass)
        assertNotNull("resultDomainObjectList null" + resultDomainObjectList)

        assertTrue("objects null or empty", resultDomainObjectList.size() > 1)
    }
    /*
   PresentationUtils.discoverNewResourcesOnHub          classUri, filterOwnerUri, auth, authenticatedUser
        _phrsBeanClassUri

   PresentationUtils.transformToDomainObjects(jsonArray, domainObjectClass)
   ObsBodyWeightBMW01
    */

    void TODOtestFilterIds() {
        def results1Param = PresentationUtils.findObjectUris(ObsBodyWeightBMW01, "_phrsBeanOwnerUri", PortalConstants.TEST_USER_UID_SYSTEM_ADMIN)
        assertNotNull("", results1Param)
        assertTrue("results1Parm found", results1Param.size() > 1)

        def results2Param = PresentationUtils.findObjectUris(ObsBodyWeightBMW01,
                "_phrsBeanOwnerUri", PortalConstants.TEST_USER_UID_SYSTEM_ADMIN,
                "_phrsBeanClassUri", PortalConstants.MODEL_BODY_WEIGHT_CLASS_URI)

        assertNotNull("results2Param null", results2Param)
        assertTrue("results found", results2Param.size() > 1)
    }

    void TODOtestSearchLocalAndFilter() {

    }

    void testDiscoverObjectsByClassAndTransform() {

        def jsonArray = PresentationUtils.discoverNewResourcesOnHub(
                ["classUri": PortalConstants.MODEL_BODY_WEIGHT_CLASS_URI,
                        'ownerUri': PortalConstants.TEST_USER_UID_SYSTEM_ADMIN],
            'className':ObsBodyWeightBMW01) //ownerUri not supported for hub

        //PortalConstants.TEST_USER_UID_USER_ANDREAS
        //InteropServerClient.restGetAllByClass(["classUri": PortalConstants.MODEL_BODY_WEIGHT_CLASS_URI])
        assertNotNull("discoverNewResourcesOnHub result objects null" + jsonArray)

        def resultDomainObjectList = PresentationUtils.transformToDomainObjectsUsingClassSample(jsonArray, ObsBodyWeightBMW01) // domainObjectClass)
        assertNotNull("resultDomainObjectList null" + resultDomainObjectList)

        assertTrue("objects null or empty", resultDomainObjectList.size() > 1)
    }



    void testLoadDefaultClassesInServer() {

        boolean flag = InteropServerClient.loadInteropFeaturesServer()
        assertTrue("load default classes on loadInteropFeaturesServer", flag)
        assertTrue("set PhrsCoreInitialization isInteropVocabServerLoaded flag", PhrsCoreInitialization.getInstance().interopClassesLoaded)

    }

    void testLoadDefaultClassesInServerByInteropRestClient() {
        assertNotNull("PhrsCoreInitialization instance fail" + PhrsCoreInitialization.getInstance())
        assertNotNull("Interop RestClient problem", InteropServerClient.getInteropRestClient()) //setup
        assertTrue("Interop flag set to true, too early", PhrsCoreInitialization.getInstance().isInteropClassesLoaded())


    }

    void testJsonEncode() {
        String json = getBodyWeightJson()
        assertNotNull("json null", json)
        assertTrue("json null", json.contains(PortalConstants.MODEL_BODY_WEIGHT_CLASS_URI))
    }
    /*
     def params = [:]
     params.classUri=
     groovyx.net.http.HttpResponseDecorator response = InteropServerClient.restGetAllByClass(params)

     def params = [:]
     params.jsonString=
     groovyx.net.http.HttpResponseDecorator response = InteropServerClient.restPersistObject(params)

    */
    /*
    void testPersistOriginalBodyWeightSample() {
        String json = getBodyWeightOriginalTestSample()
        Map params = [:]

        params.jsonString = json
        groovyx.net.http.HttpResponseDecorator response = InteropServerClient.restPersistObject(params)
        assertNotNull("HttpResponseDecorator response is null ", response)
        assertTrue("status code > 399 fail", response?.success)
        //assertFalse("NO content 204",response.statusCode == 204)
        assertNotNull("response data null", response.data)
    } */

    /*
    @POST
    @Path("/persistbbb")
    @Produces("application/json")
    @Consumes("application/json")
    public Response persistBBB(String dynaBean) {
     */

    void testPersistBodyWeightSample() {
        String json = getBodyWeightJson()
        //Map params = [:]


        groovyx.net.http.HttpResponseDecorator response = InteropServerClient.restPersistObject(json)
        assertNotNull("HttpResponseDecorator response is null ", response)
        assertTrue("status code > 399 fail", response?.success)
        //assertFalse("NO content 204",response.statusCode == 204)
        assertNull("response data should be null because this is a POST", response.data)
    }


    void xxxtestPersistJSONObjectString() {
        RESTClient client = InteropServerClient.getInteropRestClient()
        groovyx.net.http.HttpResponseDecorator response
        def test = getSimpleJSONObject()//  getBodyWeightOriginalTestSample()//getSimpleJSONObject()


        def testString = test.toString()
        //String content = "{\"_phrsBeanUri\":\"yo111\",\"_phrsBeanClassURI\":\"at.srfg.kmt.ehealth.phrs.datamodel.impl.BodyWeight\"}"
        try {
            response = client.post(path: "dataexchange_ws/dynamic_bean_repository/persist", body: [dynabean: test],
                    contentType: JSON, requestContentType: JSON)//[dynaBean: getSimpleJSONObject()] )
            //body: [getSimpleJSONObject()]
        } catch (Exception e) {
            println(e)
        }
        assertTrue("successful response for post test", response.success)

    }

    void xxtestPersistPOST_IN_CORE_NoPARAM_CONSUME_JSON() {
        RESTClient client = InteropServerClient.getInteropRestClient()
        groovyx.net.http.HttpResponseDecorator response
        def test = getBodyWeightOriginalTestSample()//getSimpleJSONObject()


        def testString = test.toString()
        //String content = "{\"_phrsBeanUri\":\"yo111\",\"_phrsBeanClassURI\":\"at.srfg.kmt.ehealth.phrs.datamodel.impl.BodyWeight\"}"
        try {
            response = client.post(
                    path: "dataexchange_ws/dynamic_bean_repository/persist", //persistbbb
                    body: test,
                    contentType: JSON, requestContentType: JSON)//[dynaBean: getSimpleJSONObject()] )
            //body: [getSimpleJSONObject()]
        } catch (Exception e) {
            println(e)
        }
        assertTrue("successful response for post test", response.success)

    }

    void xxtestJSONObject() {

        JSONObject jo = JSONObject.fromObject(getBodyWeightOriginalTestSample())
        assertNull(jo)

    }

    void xxxtestPersistSampleBodyWeightPOST_IN_CORE_NoPARAM_CONSUME_JSON() {
        RESTClient client = InteropServerClient.getInteropRestClient()
        groovyx.net.http.HttpResponseDecorator response
        def test = getBodyWeightJson()//getSimpleJSONObject()


        def testString = test.toString()
        //String content = "{\"_phrsBeanUri\":\"yo111\",\"_phrsBeanClassURI\":\"at.srfg.kmt.ehealth.phrs.datamodel.impl.BodyWeight\"}"
        try {
            response = client.post(
                    path: "dataexchange_ws/dynamic_bean_repository/persist",//persistbbb
                    body: test,
                    contentType: JSON, requestContentType: JSON)//[dynaBean: getSimpleJSONObject()] )
            //body: [getSimpleJSONObject()]
        } catch (Exception e) {
            println(e)
        }
        assertTrue("successful response for post test", response.success)

    }

    void yytestJSONObject() {

        JSONObject jo = JSONObject.fromObject(getBodyWeightOriginalTestSample())
        def test = jo.toString()
        assertNull(jo)

    }
    /*
response = client.put(path: "parking_tickets/1234334325", contentType: JSON,
      requestContentType:  JSON,
      body: [officer: "Kristen Ree",
              location: "199 Baldwin Dr",
              vehicle_plate: "Maryland 77777",
              offense: "Parked in no parking zone",
              date: "2009/01/31"])

    */

    void xxtestPersistString() {
        RESTClient client = InteropServerClient.getInteropRestClient()
        groovyx.net.http.HttpResponseDecorator response
        String content = "{\"_phrsBeanUri\":\"yo111\",\"_phrsBeanClassURI\":\"at.srfg.kmt.ehealth.phrs.datamodel.impl.BodyWeight\"}"
        try {
            response = client.put(path: "dataexchange_ws/dynamic_bean_repository/persist", contentType: JSON, requestContentType: JSON,
                    body: [dynaBean: content])

        } catch (Exception e) {
            println(e)
        }
        assertTrue("successful response for post test", response.success)

    }
    /*
def http = new HTTPBuilder( 'http://twitter.com/statuses/' )

http.get( path: 'user_timeline.json',
       query: [id:'httpbuilder', count:5] ) { resp, json ->

   println resp.status

   json.each {  // iterate over JSON 'status' object in the response:
       println it.created_at
       println '  ' + it.text
   }
}
    */
/*
groovyx.net.http.HttpResponseDecorator theResponse =
       client.post(
               path: pathVar,
               query: ['dynaBean':''],
               body: [object], //bodyMap,
               contentType: JSON,
               requestContentType: JSON)
*/

    void xxtestPersistMiniTest() {
        String json = "{'test':'112111211212'}"
        //Map params = [:]

        //params.(InteropServerClient.ACTION_PERSIST_PARAM_DYNABEAN) = json
        groovyx.net.http.HttpResponseDecorator response = InteropServerClient.restPersistObject(json)
        assertNotNull("HttpResponseDecorator response is null ", response)
        assertTrue("status code > 399 fail", response?.success)
        //assertFalse("NO content 204",response.statusCode == 204)
        assertNotNull("response data null", response.data)
    }

/*
void testGetAllBeansByClass() {
   String json = getBodyWeightOriginalTestSample()
   Map params = [:]
   params.classUri = "PortalConstants.MODEL_BODY_WEIGHT_CLASS_URI"

   groovyx.net.http.HttpResponseDecorator response = InteropServerClient.restGetAllByClass(params)
   assertTrue("status code > 399 fail", response.success)
   assertFalse("NO content 204", response.statusCode == 204)
   assertNotNull("response data null", response.data)

   assertContains("_phrsBeanClassUri not found in response", response.data)
}
*/
// static URI_SAMPLE_WEIGHT_1 = "phrs_bodyweight_myuri123";

    static String getBodyWeightJson() {

        ObsBodyWeightBMW01 instance = new ObsBodyWeightBMW01()
        instance._phrsBeanClassURI = PortalConstants.MODEL_BODY_WEIGHT_CLASS_URI


        instance._phrsBeanUri = "mybeanuri_unique_" + UUID.randomUUID().toString()
        instance._phrsBeanCreateDate = new Date()

        instance._phrsBeanOwnerUri = "my_creator_uri_123"
        instance._phrsBeanCreatorUri = instance._phrsBeanOwnerUri
        instance.comment = "mycomment"

        instance.observationDate = new Date() //?? What does UI do???

        instance.bodyweight = 78F
        instance.bodyBMI = 26.2F
        instance.height = 172F

        //String json = instance.encodeAsJSON()
        grails.converters.JSON converter = new grails.converters.JSON('123target123': instance);
        String json = converter.toString()
        String json1 = json.replace('{\"123target123\":', '')
        String json2 = json1.replace('}}', '}')

        //println("converter props"+converter.properties)
        // {"target":
        //def converter = instance as grails.converters.JSON
        println("json2 --> " + json2)

        return json2
    }
    //does not work, error about missing the _phrsBeanURI   on the core...

    static String getBodyWeightOriginalTestSample() {
        //def raw = '{"class":"at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsBloodPressureA01","id":null,"_phrsBeanCanRead":true,"_phrsBeanCanUse":true,"_phrsBeanCanWrite":true,"_phrsBeanClassURI":null,"_phrsBeanCreateDate":"2011-04-14T15:30:56Z","_phrsBeanCreatorUri":null,"_phrsBeanIsDeleted":false,"_phrsBeanName":null,"_phrsBeanOwnerUri":null,"_phrsBeanRefersToSourceUri":null,"_phrsBeanUri":"phrs_uuid_b5f9c623-65af-4db8-a61d-ef5b9b7b4edb","bpDiastolic":78,"bpHeartRate":78,"bpSystolic":123,"comment":"sf","observationDate":"2011-04-14T15:30:00Z","ownerUser":{"class":"User","id":2}}'
        String raw = "{\"class\":\"at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsBloodPressureA01\",\"id\":null,\"_phrsBeanCanRead\":true,\"_phrsBeanCanUse\":true,\"_phrsBeanCanWrite\":true,\"_phrsBeanClassURI\":null,\"_phrsBeanCreateDate\":\"2011-04-14T15:30:56Z\",\"_phrsBeanCreatorUri\":null,\"_phrsBeanIsDeleted\":false,\"_phrsBeanName\":null,\"_phrsBeanOwnerUri\":null,\"_phrsBeanRefersToSourceUri\":null,\"_phrsBeanUri\":\"phrs_uuid_b5f9c623-65af-4db8-a61d-ef5b9b7b4edb\",\"bpDiastolic\":78,\"bpHeartRate\":78,\"bpSystolic\":123,\"comment\":\"sf\",\"observationDate\":\"2011-04-14T15:30:00Z\",\"ownerUser\":{\"class\":\"User\",\"id\":2}}"

        return raw
        //String json = raw.toString() as grails.converters.deep.JSON
        //String json = raw.toString() as grails.converters.JSON
        //JSONObject jsonObject = new JSONObject(raw)
        // return jsonObject.toString()

        //String json = raw.replaceAll("�", "\\\\u0027")

        //return json
        //return jsonObject

    }

    static JSONObject getSimpleJSONObject() {
        JSONObject jsonObject = new JSONObject()
        jsonObject.put("_phrsBeanClassURI", "at.srfg.kmt.ehealth.phrs.datamodel.impl.BodyWeight")
        jsonObject.put("_phrsBeanUri", "my1234")
        return jsonObject
    }
/*
{"class":"at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsBloodPressureA01","id":null,"_phrsBeanCanRead":true,"_phrsBeanCanUse":true,"_phrsBeanCanWrite":true,"_phrsBeanClassURI":null,"_phrsBeanCreateDate":"2011-04-14T15:30:56Z","_phrsBeanCreatorUri":null,"_phrsBeanIsDeleted":false,"_phrsBeanName":null,"_phrsBeanOwnerUri":null,"_phrsBeanRefersToSourceUri":null,"_phrsBeanUri":"phrs_uuid_b5f9c623-65af-4db8-a61d-ef5b9b7b4edb","bpDiastolic":78,"bpHeartRate":78,"bpSystolic":123,"comment":"sf","observationDate":"2011-04-14T15:30:00Z","ownerUser":{"class":"User","id":2}}
*/
/**
 * change obj._phrsBeanUri when used more than once
 * @return
 */
    static ObsBloodPressureA01 getBloodPressure() {
        ObsBloodPressureA01 obj = new ObsBloodPressureA01()


        obj._phrsBeanClassURI = PortalConstants.MODEL_BLOOD_PREASURE_CLASS_URI
        obj._phrsBeanUri = "mybeanuri111"
        obj._phrsBeanCreateDate = new Date()
        obj._phrsBeanCreatorUri = "mycreatoruri_1.1123456"

        obj._phrsBeanOwnerUri = "myowneruri"

        obj._phrsBeanIsDeleted = Boolean.FALSE
        obj.observationDate = new Date()
        obj.bpDiastolic = 80
        obj.bpSystolic = 120
        obj.bpHeartRate = 70
        obj.observationDate = new Date()

        return obj
    }
/*
void testSaveNewPojo() {

   //Riskfactor obj = getSampleRiskFactor()
   ObsBloodPressureA01 obj = new ObsBloodPressureA01()


   obj._phrsBeanClassURI = "my_class_uri"
   obj._phrsBeanUri = "mybeanuri"
   obj._phrsBeanCreateDate = new Date()
   obj._phrsBeanCreatorUri = "mycreatoruri_1.1123456"

   obj._phrsBeanOwnerUri = "myowneruri"

   obj._phrsBeanIsDeleted = Boolean.FALSE
   obj.observationDate = new Date()
   obj.bpDiastolic = 80
   obj.bpSystolic = 120
   obj.bpHeartRate = 70
   obj.observationDate = new Date()


   def deepJson = ""// obj as grails.converters.JSON
   println("json deep= " + deepJson)
   assertNotNull("is risk json (deep) null?", deepJson)

   Map theMap = obj.properties
   println("properties map raw = " + theMap.entrySet())
   assertNotNull("is map null?", theMap)

   def jsonRegular = obj.encodeAsJSON()
   assertNotNull("is risk json (encodeAsJSON) null?", jsonRegular)


} */
/*
static def persistToInterop(obj) {
  //dataexchange_ws/dynamic_bean_repository

}  */

/**
 * change obj._phrsBeanUri when used more than once
 * @return

 static ObsBloodPressureA01 getSampleBloodPressure() {
 ObsBloodPressureA01 obj = new ObsBloodPressureA01()


 obj._phrsBeanClassURI = "my_class_uri"
 obj._phrsBeanUri = "mybeanuri"
 obj._phrsBeanCreateDate = new Date()
 obj._phrsBeanCreatorUri = "mycreatoruri_1.1123456"

 obj._phrsBeanOwnerUri = "myowneruri"

 obj._phrsBeanIsDeleted = Boolean.FALSE
 obj.observationDate = new Date()
 obj.bpDiastolic = 80
 obj.bpSystolic = 120
 obj.bpHeartRate = 70
 obj.observationDate = new Date()
 return obj
 }static Riskfactor getSampleRiskFactor() {
 Riskfactor obj = new Riskfactor()

 obj._phrsBeanClassURI = "my_class_uri"
 obj._phrsBeanUri = "mybeanuri"
 obj._phrsBeanCreateDate = new Date()
 obj._phrsBeanCreatorUri = "mycreatoruri_1.1123456"

 obj._phrsBeanOwnerUri = "myowneruri"

 obj.observationDateStart = new Date()
 obj._phrsBeanIsDeleted = Boolean.FALSE
 obj.riskFactorCode = "my_riskFactorCode"
 obj.riskFactorDuration = "mydurationcode"
 obj.riskFactorType = "my obj type"

 obj.isTreated = Boolean.TRUE
 obj.isActiveStatus = Boolean.TRUE

 obj.riskFactorAttributes = ['smokeType': 'my_code_cigars']
 obj.riskFactorAttributes = ['smokeXXX': 'my_code_xxxx']

 return obj
 } */
}
