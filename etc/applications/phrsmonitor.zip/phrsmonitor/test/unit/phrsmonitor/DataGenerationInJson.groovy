package phrsmonitor

import grails.test.GrailsUnitTestCase
import at.srfg.kmt.ehealth.phrs.presentation.model.observation.ActivityItem
import at.srfg.kmt.ehealth.phrs.presentation.model.patientdata.MedicationSummary
import at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsIssue
import at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsBodyWeightBMW01
import at.srfg.kmt.ehealth.phrs.presentation.model.observation.ActivityOfDailyLivingItem
import at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsBloodPressureA01
import at.srfg.kmt.ehealth.phrs.presentation.model.observation.ActivityLevel
import at.srfg.kmt.ehealth.phrs.presentation.model.riskfactors.Riskfactor
import net.sf.json.JSONObject

class DataGenerationInJson extends GrailsUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testGenerateJsonByModel() {
        def resultsMap
        resultsMap.ActivityItem = ActivityItem.list()
        resultsMap.ActivityLevel = ActivityLevel.list()
        resultsMap.ActivityOfDailyLivingItem = ActivityOfDailyLivingItem.list()
        resultsMap.ObsBloodPressureA01 = ObsBloodPressureA01.list()
        resultsMap.ObsBodyWeightBMW01 = ObsBodyWeightBMW01.list()
        resultsMap.ObsIssue = ObsIssue.list()
        resultsMap.MedicationSummary = MedicationSummary.list()
        resultsMap.Riskfactor = Riskfactor.list()



        def jsonLists = resultsMap.collect { objectList ->

            def jsonObjects = objectList.collect { mapItem ->
                JSONObject json = new JSONObject()
                if (mapItem?.value?.properties) {
                    json.putAll(mapItem.value.properties);

                    println("json string:" + json.toString(2));

                    if (json) {
                        def entryItem = [(mapItem.key): json.toString()]
                        entryItem  //collect the mapEntry
                    }
                }
                println("fin mapItem= " + mapItem?.key)
            }

            jsonObjects  // collect the list
        }
        println(jsonLists)
    }


}
