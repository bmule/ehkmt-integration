package phrsmonitor

import grails.test.GrailsUnitTestCase
import at.srfg.kmt.ehealth.phrs.presentation.utils.VocabServerLookup
import groovyx.net.http.RESTClient
//import at.srfg.kmt.ehealth.phrs.presentation.utils.KnLookupSupportService
//import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants

class VocabRestAccess extends GrailsUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }
    /*
HOST=http://localhost:8080
CONTEXT=dataexchange_ws/controlled_item_repository

#C0235439
#curl --fail  -X GET $HOST/$CONTEXT/get?q=2.16.840.1.113883.6.96:C0235439
#2.16.840.1.113883.6.96:19019007 - the syntax is code system code : item code
#curl --fail  -X GET http://localhost:8080/dataexchange_ws/controlled_item_repository/getForTag?q=2.1840.1.113883.6.96:C0042963

curl --fail  -X GET $HOST/$CONTEXT/getForTag?q=2.16.840.1.113883.6.96:C0042963


-----
HOST=http://localhost:8080
CONTEXT=dataexchange_ws/controlled_item_repository

#2.16.840.1.113883.6.96:19019007 - the syntax is code system code : item code
curl --fail  -X GET $HOST/$CONTEXT/get?q=2.16.840.1.113883.6.96
    */
    static final String VOCAB_SERVER_CONTEXT = "dataexchange_ws/controlled_item_repository"

    void testVocabTagQuery1() {


        def jsonOut = VocabServerLookup.testTag1()

        assertNotNull(jsonOut)
    }

    void testRestClientSetup() {

        RESTClient client = VocabServerLookup.getRestClient()
        assertNotNull(client)
    }

    void testVocabCodeSystemQuery() {


        def jsonOut = VocabServerLookup.testCodeSystem1()
        assertNotNull(jsonOut)
    }

    void testVocabTransformJsonStringToMap() {
        def jsonOut = VocabServerLookup.testCodeSystem1()
        assertNotNull(jsonOut)

        // jsonOut.each {println it}
        //Map map = VocabServerLookup.transformJson(jsonOut.toList())
        //assertNotNull(list)

    }

    void testVocabTermLookup() {
        def jsonOut = VocabServerLookup.testTerm1()
        assertNotNull(jsonOut)

        //jsonOut.each {println it}
        //Map map = VocabServerLookup.transformJson(jsonOut.toList())
        //assertNotNull(list)

    }

    void testVocabSingleTermLabelValue() {
        def lv = VocabServerLookup.getTermToLabelValue('2.16.840.1.113883.6.96:C1457887', 'en')
        assertNotNull(lv)
        assertNotNull(lv.id)
        assertNotNull(lv.value)
        assertEquals(lv?.id, '2.16.840.1.113883.6.96:C1457887')
        assertNotSame( "Using default when label value null, not actual -fail",'2.16.840.1.113883.6.96:C1457887',lv.value)

    }

    void testVocabTermLabelValueList() {

        def lvs = VocabServerLookup.getTermsToLabelValues('2.16.840.1.113883.6.96', 'en')

        assertNotNull(lvs)
        assertTrue("Are there many label values?", lvs.size() > 10)
    }



}
