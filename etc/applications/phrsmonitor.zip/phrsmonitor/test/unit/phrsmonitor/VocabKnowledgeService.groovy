package phrsmonitor

import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants
import at.srfg.kmt.ehealth.phrs.presentation.utils.KnLookupSupportService

import grails.test.GrailsUnitTestCase

class VocabKnowledgeService extends GrailsUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }
    /*
HOST=http://localhost:8080
CONTEXT=dataexchange_ws/controlled_item_repository

#C0235439
#curl --fail  -X GET $HOST/$CONTEXT/get?q=2.16.840.1.113883.6.96:C0235439
#2.16.840.1.113883.6.96:19019007 - the syntax is code system code : item code
#curl --fail  -X GET http://localhost:8080/dataexchange_ws/controlled_item_repository/getForTag?q=2.1840.1.113883.6.96:C0042963

curl --fail  -X GET $HOST/$CONTEXT/getForTag?q=2.16.840.1.113883.6.96:C0042963


-----
HOST=http://localhost:8080
CONTEXT=dataexchange_ws/controlled_item_repository

#2.16.840.1.113883.6.96:19019007 - the syntax is code system code : item code
curl --fail  -X GET $HOST/$CONTEXT/get?q=2.16.840.1.113883.6.96
    */
    static final String VOCAB_SERVER_CONTEXT = "dataexchange_ws/controlled_item_repository"



    void testVocabKnowledgeServiceLookupTermListByUserInterfaceTag() {
        def results = KnLookupSupportService.lookupUITerminologyList(['tag': PortalConstants.TERM_DRUG_CONSUMPTION_STATUS_CODE_PHRS])

        assertNotNull(results)

        /*
        static def lookupUITerminologyList = { attrs ->
        //KnLookupSupportService.testStuff(['one':'one123'])

        println("lookupTerminologyList 0")

        List list = new ArrayList<ViewLabelValue>()

        String classedProperty = attrs?.property  //the class property as one classuri --> class.property
        String language = attrs?.lang ? attrs.lang : 'en'
        List tags = attrs?.tags ? attrs.tags : null
        String tag = attrs?.tag ? attrs.tag : null
        //UI can override and use local vocab
        def useLocalVocab = attrs?.useLocalVocab ? attrs.useLocalVocab : false
        */

    }

    void testVocabKnowledgeServiceLookupTermLabel() {
        //return a string of something based on the input
        def results = KnLookupSupportService.lookupTerminologyTermLabel( "mytermBlah")


        assertNotNull(results)
    }

    void testUriParser() {
        /*
        static def testStuff = { attrs ->
    println("testStuff")
    Map<String, String> a = IntegratedVocabularyServer.decomposeUri("mns111:code123", true)
    //println("IntegratedVocabularyServer.decomposeUri uri = " + a.entrySet())

}
         */
    }

}
