package phrsmonitor

import grails.test.GrailsUnitTestCase
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants
import phrsmonitor.PhrsTagLib

class PhrsTagTests extends GrailsUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {

        //def label = new PhrsTagLib().lookuplabel(['term': PortalConstants.TERM_RISK_CODE_DIABETES_MELLITUS])
        def label = new PhrsTagLib().testLookuplabel( PortalConstants.TERM_RISK_CODE_DIABETES_MELLITUS)
        assertNotNull("lookup label for diabetes from tag" + label)

        def label2 = new PhrsTagLib().testLookuplabel(null,'mydefault')
        println("labelDefault="+label2)
        assertEquals("lookup but let default to labelDefault", label2,'mydefault')


    }
}
