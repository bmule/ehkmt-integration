package phrsmonitor

import grails.test.*

class PhrsCoreInitializationFilterFiltersTests extends GrailsUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }
      /*
    void testReachable() {
        def reachable = false

        try {
            String serverAddress = null;
            String serverUrl = "http://localhost:7070/"
            if (serverUrl != null) {
                serverAddress = serverUrl.replace("http:", "")
                serverAddress = serverAddress.replace("/", "")
            };
            assertEquals("serverUrl?", "localhost:7070", serverAddress,)
            InetAddress address = InetAddress.getByName("127.0.0.1","7070");

            // Try to reach the sspecified address within the timeout
            // periode. If during this periode the address cannot be
            // reach then the method returns false.
            //Windows ping ok, but linux need root access??    http://bordet.blogspot.com/2006/07/icmp-and-inetaddressisreachable.html

            reachable = address.isReachable(10000);
            assertTrue("reachable?", reachable == true)
            //System.out.println("Is host reachable? " + reachable);

        } catch (IOException e) {
            println(e)
            assertTrue("exception caught - reachable?", reachable == true)

        }
        assertTrue("final reachable?", reachable == true)

    }

    void testInetAddress() {
        InetAddress address = new InetAddress("localhost",7070);

        boolean reachable = address.isReachable(10000);
        assertTrue("testInetAddress 127.0.0.1 reachable?", reachable == true)

    }

    void testInetAddress2() {
        InetAddress address = new InetAddress("localhost","7070");

        boolean reachable = address.isReachable(10000);
        assertTrue("testInetAddress localhost reachable?", reachable == true)

    }*/
}
