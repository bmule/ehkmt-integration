package at.srfg.kmt.ehealth.phrs.presentation

import grails.test.*

class RestingControllerTests extends ControllerUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {

    }
}
