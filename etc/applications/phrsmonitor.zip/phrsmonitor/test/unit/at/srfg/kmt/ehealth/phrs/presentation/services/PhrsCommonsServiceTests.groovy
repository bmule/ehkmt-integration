package at.srfg.kmt.ehealth.phrs.presentation.services

import grails.test.*

class PhrsCommonsServiceTests extends GrailsUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {

    }
}
