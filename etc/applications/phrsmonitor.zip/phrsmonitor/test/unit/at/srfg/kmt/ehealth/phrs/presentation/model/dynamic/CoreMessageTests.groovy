package at.srfg.kmt.ehealth.phrs.presentation.model.dynamic

import grails.test.*

class CoreMessageTests extends GrailsUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {

    }
}
