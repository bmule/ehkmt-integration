package at.srfg.kmt.ehealth.phrs.presentation.model.profile

import grails.test.*

class HealthProfileIndividualControllerTests extends ControllerUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {

    }
}
