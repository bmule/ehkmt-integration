package at.srfg.kmt.ehealth.phrs.presentation.model.observation

import grails.test.*

class ActivityLevelTests extends GrailsUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {

    }
}
