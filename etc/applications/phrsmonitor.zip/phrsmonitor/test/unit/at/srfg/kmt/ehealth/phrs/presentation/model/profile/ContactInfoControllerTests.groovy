package at.srfg.kmt.ehealth.phrs.presentation.model.profile

import grails.test.*

class ContactInfoControllerTests extends ControllerUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {

    }
}
