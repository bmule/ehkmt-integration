package at.srfg.kmt.ehealth.phrs.presentation.model.patientdata

import grails.test.*

class MedicationSummaryControllerTests extends ControllerUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {

    }
}
