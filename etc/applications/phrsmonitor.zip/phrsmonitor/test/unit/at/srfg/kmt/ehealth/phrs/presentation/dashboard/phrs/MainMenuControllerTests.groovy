package at.srfg.kmt.ehealth.phrs.presentation.dashboard.phrs

import grails.test.*

class MainMenuControllerTests extends ControllerUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {

    }
}
