package at.srfg.kmt.ehealth.phrs.presentation.model.riskfactors

import grails.test.*

class RiskfactorSummaryControllerTests extends ControllerUnitTestCase {
    protected void setUp() {
        super.setUp()
    }

    protected void tearDown() {
        super.tearDown()
    }

    void testSomething() {

    }
}
