/*$(function() {

    $('#dialog-form').dialog({
        autoOpen: false,
        height: 300,
        width: 350,
        modal: true,
        buttons: {
            'Create a Reminder': function() {

            },
            Cancel: function() {
                $(this).dialog('close');
            }

        }
    });
}); */



$(function() {

    $('#dialog-form').dialog({
        autoOpen: false,
        height: 300,
        width: 350,
        modal: true,
        buttons: {
            'Create a Reminder': function() {
                var duration = $("#duration").val();
                var reminderType = $("#reminderType option:selected").val();
                var event = $("#id").val();
                $.post(contextPath + '/reminder/save', {'event.id':event, duration:duration, reminderType:reminderType}, function(data) {
                    var item = $("<li>");
                    var link = $("<a>").attr("href", contextPath + "/reminder/show/" + data.id).html(data.reminderType.name + " : " + data.duration);
                    item.append(link);
                    $('#reminder_list').append(item);
                }, 'json');
                $(this).dialog('close');
            },
            Cancel: function() {
                $(this).dialog('close');
            }

        }
    });

    $('#add_reminder').click(function() {
        $('#dialog-form').dialog('open');
    });
});