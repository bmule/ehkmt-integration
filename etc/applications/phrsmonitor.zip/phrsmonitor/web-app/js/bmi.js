function  calculateBMI() {

  //metric height centimeters meters if height < 3, otherwise centimeters
  var weight = eval(document.bodyform.bodyweight.value)
  var height = eval(document.bodyform.height.value)
  //  alert("calculateBMI wt="+weight+" height="+height)
  //if(height < 3) height= height*100 //
  var height2 = height / 100
  var BMI = weight  / (height2 * height2)
  //alert(BMI)
  document.bodyform.bodyBMI.value=custRound(BMI,1);
}
/*
  var weight = eval(document.form.bodyweight.value)
  var height = eval(document.form.height.value)
function  calculateBMIByParam(weight,height,bmiElement) {
  var weight = eval(weight)
  var height = eval(height)
  var height2 = height / 100
  var BMI = weight  / (height2 * height2)
  document.form.bmiElement.value=custRound(BMI,1);
} */
function custRound(x,places) {
  return (Math.round(x*Math.pow(10,places)))/Math.pow(10,places)
}