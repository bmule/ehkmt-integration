grails.project.class.dir = "target/classes"
grails.project.test.class.dir = "target/test-classes"
grails.project.test.reports.dir = "target/test-reports"
//grails.project.war.file = "target/${appName}-${appVersion}.war"
grails.project.dependency.resolution = {
    // inherit Grails' default dependencies
    inherits("global") {
        // uncomment to disable ehcache
        // excludes 'ehcache'
    }
    log "warn" // log level of Ivy resolver, either 'error', 'warn', 'info', 'debug' or 'verbose'
    repositories {
        grailsPlugins()
        grailsHome()
        grailsCentral()

        // uncomment the below to enable remote dependency resolution
        // from public Maven repositories
        //mavenLocal()
        //mavenCentral()
        //mavenRepo "http://snapshots.repository.codehaus.org"
        //mavenRepo "http://repository.codehaus.org"
        //mavenRepo "http://download.java.net/maven/2/"
        //mavenRepo "http://repository.jboss.com/maven2/"
    }
    dependencies {
        // specify dependencies here under either 'build', 'compile', 'runtime', 'test' or 'provided' scopes eg.

        // runtime 'mysql:mysql-connector-java:5.1.13'
    }

    // Remove the JDBC jar before the war is bundled
    // grails.war.resources = { stagingDir ->
    //  delete(file:"${stagingDir}/WEB-INF/lib/jdbc2_0-stdext.jar")
    //
    //}

        grails.war.resources = {stagingDir, args ->
            delete file: "${stagingDir}/WEB-INF/lib/postgresql-9.0-801.jdbc4.jar"  //postgres driver
        }
 /*
 def toRemove = [
          "$stagingDir/WEB-INF/lib/log4j-1.2.14.jar", // log4j supplied by JBoss
          "$stagingDir/WEB-INF/lib/log4j-1.2.15.jar", // log4j supplied by JBoss
          "$stagingDir/WEB-INF/classes/log4j.properties", // logging conf done in JBoss only
          "$stagingDir/WEB-INF/lib/slf4j-api-1.5.6.jar", // slf4j supplied by JBoss 5+
          "$stagingDir/WEB-INF/lib/slf4j-api-1.5.8.jar", // slf4j supplied by JBoss 5+
          "$stagingDir/WEB-INF/lib/slf4j-log4j12-1.5.6.jar", // slf4j supplied by JBoss 5+
          "$stagingDir/WEB-INF/lib/slf4j-log4j12-1.5.8.jar", // slf4j supplied by JBoss 5+
          "$stagingDir/WEB-INF/lib/jcl-over-slf4j-1.5.6.jar", // jcl supplied by JBoss as well
          "$stagingDir/WEB-INF/lib/jcl-over-slf4j-1.5.8.jar", // jcl supplied by JBoss as well
        // see also Config.grails.logging.jul.usebridge - shouldn't be used
        //     http://www.slf4j.org/legacy.html#jul-to-slf4j
        //          "$stagingDir/WEB-INF/lib/jul-to-slf4j-1.5.6.jar",
        //          "$stagingDir/WEB-INF/lib/jul-to-slf4j-1.5.8.jar",
        // you might want to remove JDBC drivers when using server supplied JNDI...
        //          "$stagingDir/WEB-INF/lib/hsqldb-1.8.0.5.jar",
    ].each {
        delete(file: it)
    }
 }
 */
    /*
    grails.war.resources = { stagingDir, args ->
        //remove icardea related phrs core libs used for compiling, these are provided in the phrs EAR class path
        delete file: "${stagingDir}/WEB-INF/lib/commons-beanutils-1.8.3.jar"
        delete file: "${stagingDir}/WEB-INF/lib/commons-collections-3.2.1.jar"
        delete file: "${stagingDir}/WEB-INF/lib/commons-io-1.3.2.jar"
        delete file: "${stagingDir}/WEB-INF/lib/commons-lang-2.5.jar"
        delete file: "${stagingDir}/WEB-INF/lib/commons-logging-1.1.1.jar"
        delete file: "${stagingDir}/WEB-INF/lib/dataexchange-0.0.1.jar"
        //delete file: "${stagingDir}/WEB-INF/lib/ezmorph-1.0.6.jar"
        //delete file: "${stagingDir}/WEB-INF/lib/json-lib-2.4-jdk15.jar"
        delete file: "${stagingDir}/WEB-INF/lib/phrs-util-0.0.1.jar"
        //delete file: "${stagingDir}/WEB-INF/lib/postgresql-9.0-801.jdbc4.jar"
        //might not be in this web app
        delete file: "${stagingDir}/WEB-INF/lib/slf4j-api-1.6.1.jar"

        //other versions of above provided by grails
        delete file: "${stagingDir}/WEB-INF/lib/commons-beanutils-1.8.0.jar"
        delete file: "${stagingDir}/WEB-INF/lib/commons-io-1.4.jar"
        delete file: "${stagingDir}/WEB-INF/lib/commons-lang-2.4.jar"

        // relating to jboss
        delete file: "$stagingDir/WEB-INF/lib/log4j-1.2.14.jar" // log4j supplied by JBoss
        delete file: "$stagingDir/WEB-INF/lib/log4j-1.2.15.jar" // log4j supplied by JBoss
        delete file: "$stagingDir/WEB-INF/lib/log4j-1.2.16.jar" // log4j supplied by JBoss
        delete file: "$stagingDir/WEB-INF/classes/log4j.properties" // logging conf done in JBoss only

        delete file: "$stagingDir/WEB-INF/lib/slf4j-api-1.5.6.jar" // slf4j supplied by JBoss 5+
        delete file: "$stagingDir/WEB-INF/lib/slf4j-api-1.5.8.jar" // slf4j supplied by JBoss 5+
        delete file: "$stagingDir/WEB-INF/lib/slf4j-log4j12-1.5.6.jar" // slf4j supplied by JBoss 5+
        delete file: "$stagingDir/WEB-INF/lib/slf4j-log4j12-1.5.8.jar" // slf4j supplied by JBoss 5+

        //jcl-over-slf4j-1.5.8.jar
        delete file: "$stagingDir/WEB-INF/lib/jcl-over-slf4j-1.5.6.jar" // jcl supplied by JBoss as well
        delete file: "$stagingDir/WEB-INF/lib/jcl-over-slf4j-1.5.8.jar" // jcl supplied by JBoss as well

        //JDBC drivers -- using server provided JNDI ??
        delete file: "stagingDir/WEB-INF/lib/hsqldb-1.8.0.5.jar"   //remove JDBC drivers when using server supplied JNDI
        delete file: "stagingDir/WEB-INF/lib/hsqldb-1.8.0.10.jar" //exists
        //logging legacy??
        delete file: "$stagingDir/WEB-INF/lib/jul-to-slf4j-1.5.8.jar"  //http://www.slf4j.org/legacy.html#jul-to-slf4j
        delete file: "$stagingDir/WEB-INF/lib/jul-to-slf4j-1.5.6.jar"

        delete file: "$stagingDir/WEB-INF/lib/hibernate-annotations-3.4.0.GA.jar"

        delete file: "$stagingDir/WEB-INF/lib/hibernate-commons-annotations-3.1.0.GA.jar"
        delete file: "$stagingDir/WEB-INF/lib/hibernate-core-3.3.1.GA.jar"
        delete file: "$stagingDir/WEB-INF/lib/hibernate-ehcache-3.3.1.GA.jar"
        delete file: "$stagingDir/WEB-INF/lib/hibernate-validator-3.1.0.GA.jar"
        delete file: "$stagingDir/WEB-INF/lib/hsqldb-1.8.0.10.jar"
        delete file: "$stagingDir/WEB-INF/lib/xalan-2.7.1.jar"
        delete file: "$stagingDir/WEB-INF/lib/xercesImpl-2.9.1.jar"
        delete file: "$stagingDir/WEB-INF/lib/xmlsec-1.4.2.jar"

        //becareful with these... xalan-2.7.1.jar  xercesImpl-2.9.1.jar   dom4j-1.6.1.jar
    }   */


}
