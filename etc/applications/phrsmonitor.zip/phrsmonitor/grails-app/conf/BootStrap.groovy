import at.srfg.kmt.ehealth.phrs.presentation.utils.PhrsCoreInitialization

class BootStrap {

    def init = { servletContext ->

        //try {
        /**
         * Die if this fails, otherwise the vocabulary server is not available
         */
            String coreServerUrl = servletContext.getInitParameter("phrs_core.url")
            PhrsCoreInitialization start = PhrsCoreInitialization.getInstance(coreServerUrl) //set server
            //PhrsCoreInitialization.getInstance().initializeCoreVocabularyServer()


       // } catch (Exception e) {
            //"init core error "+e)
        //}


    }
    def destroy = {
    }
    /*



       only for jquery calendar http://www.grails.org/plugin/jquery-calendar
      def calendarService

      def init = { servletContext ->

          calendarService.securityDelegate = [
                  getCurrentUser: {-> [id: 1]}, isUserAllowedToCreateEvents: {-> true}, isUserAllowedToEditEvent: {calendarEvent -> true}, isUserAllowedToCreateReminder: {calendarEvent -> true}
          ]

          calendarService.mailDelegate = [ sendReminder: {reminder -> println 'reminder sent' }, ]

      }
    */
    /*
    void createAdminUserIfRequired() {
        if (!User.findByUserId("admin")) {
//Ensures admin user doesn�t exist
            switch (Environment.current) {case Environment.DEVELOPMENT:
                createAdminUserIfRequired()
                break;
                case Environment.PRODUCTION:
                    println "No special configuration required" break;
                    println "Fresh Database. Creating ADMIN user."
                    def profile = new Profile(email: "admin@yourhost.com")
                    def user = new User(userId: "admin",
                            password: "secret", profile: profile).save()
            } else {
            println "Existing admin user, skipping creation"
        }  */
}
