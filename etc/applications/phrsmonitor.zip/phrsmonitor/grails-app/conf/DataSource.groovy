dataSource {
    pooled = true
    dbCreate = "update"
    url = "jdbc:postgresql://localhost/phrs_portal_source"
    driverClassName = "org.postgresql.Driver"
    dialect = "org.hibernate.dialect.PostgreSQLDialect"
    username = "phrs"
    password = "phrs"
}
/*dataSource {
    pooled = true
    driverClassName = "org.hsqldb.jdbcDriver"
    username = "sa"
    password = ""
}*/
hibernate {
    cache.use_second_level_cache = true
    cache.use_query_cache = true
    cache.provider_class = 'net.sf.ehcache.hibernate.EhCacheProvider'
}
// environment specific settings. Here you can override any or all datasource params set above
environments {
    development {
        /* dataSource {
           dbCreate = "create-drop" // one of 'create', 'create-drop','update'
           url = "jdbc:hsqldb:mem:devDB"
           driverClassName = "org.hsqldb.jdbcDriver"
           pooled = true
           username = "sa"
           password = ""
       } */
        dataSource {
            pooled = true
            dbCreate = "update"
            url = "jdbc:postgresql://localhost/phrs_portal_source"
            driverClassName = "org.postgresql.Driver"
            dialect = "org.hibernate.dialect.PostgreSQLDialect"
            username = "phrs"
            password = "phrs"
        }
    }
    test {
        /*
        dataSource {
            dbCreate = "update"
            url = "jdbc:hsqldb:mem:testDb"
            driverClassName = "org.hsqldb.jdbcDriver"
            pooled = true
            username = "sa"
            password = ""
        }*/
        dataSource {
            pooled = true
            dbCreate = "update"
            url = "jdbc:postgresql://localhost/phrs_portal_source"
            driverClassName = "org.postgresql.Driver"
            dialect = "org.hibernate.dialect.PostgreSQLDialect"
            username = "phrs"
            password = "phrs"
        }
    }
    /*
    test {
        dataSourcePostgres {
            pooled = true
            dbCreate = "update"
            url = "jdbc:postgresql://localhost/phrs_portal_source"
            driverClassName = "org.postgresql.Driver"
            dialect = "org.hibernate.dialect.PostgreSQLDialect"
            username = "phrs"
            password = "phrs"
        } */
    /*
  dataSource {
      dbCreate = "update"
      url = "jdbc:hsqldb:file:prodDb123;shutdown=true"
      driverClassName = "org.hsqldb.jdbcDriver"
      pooled = true
      username = "sa"
      password = ""
  }  }*/



    production {
        dataSource {
            pooled = true
            dbCreate = "update"
            url = "jdbc:postgresql://localhost/phrs_portal_source"
            driverClassName = "org.postgresql.Driver"
            dialect = "org.hibernate.dialect.PostgreSQLDialect"
            username = "phrs"
            password = "phrs"
        }
    }
    /*
   production {
       dataSource {
           pooled = false
           dbCreate = "update"
           jndiName = "java:comp/env/phrs_portal_storage"
       }
   }
    */

}
/*
//dbCreate = "create-drop"  // one of 'create', 'create-drop','update'

  dataSourcePostgres {
	pooled = true
	dbCreate = "update"
	url = "jdbc:postgresql://localhost/phrs_portal_source"
	driverClassName = "org.postgresql.Driver"
	dialect="org.hibernate.dialect.PostgreSQLDialect"
	username = "phrs"
	password = "phrs"
 }
manual setup of postgres
owner:phrs_portal
CREATE DATABASE phrs_portal_storage
  WITH OWNER = phrs_portal
       ENCODING = 'UTF8'
       TABLESPACE = pg_default
       LC_COLLATE = 'en_US.UTF-8'
       LC_CTYPE = 'en_US.UTF-8'
       CONNECTION LIMIT = -1;

CREATE ROLE phrs_portal LOGIN
  ENCRYPTED PASSWORD 'md54fb85fc2f5b6a82d6724fb99b4b1a1f7'
  NOSUPERUSER INHERIT NOCREATEDB NOCREATEROLE;


  dataSource {
    pooled = true
    driverClassName = "org.hsqldb.jdbcDriver"
    username = "sa"
    password = ""
}

environments {
    development {
        dataSource {
            dbCreate = "create-drop" // one of 'create', 'create-drop','update'
            url = "jdbc:hsqldb:mem:devDB"
        }
    }
    test {
        dataSource {
            dbCreate = "update"
            url = "jdbc:hsqldb:mem:testDb"
        }
    }
    production {
        dataSource {
            dbCreate = "update"
            url = "jdbc:hsqldb:file:prodDb;shutdown=true"
        }
    }
}
*/