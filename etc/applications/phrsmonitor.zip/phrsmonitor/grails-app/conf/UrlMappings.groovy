class UrlMappings {

    static mappings = {

        "/$controller/$action?/$id?" {
            constraints {
                // apply constraints here
            }
        }

        "/"(view: "/index")

        "500"(view: "/error")

        "/test1"(controller:"at.srfg.kmt.ehealth.phrs.presentation.DynabeanFormController",action:"testbean")
        "/test2"(controller:"at.srfg.kmt.ehealth.phrs.presentation.DynabeanFormController",action:"list")
        "/test3"(controller:"DynabeanFormController",action:"list")


    }
    /**


   "/test"(controller:'home', action:'default')

     "/"{
        controller = "yourController"
        action = "yourAction"
     }

     "/product" {
        controller = "product"
        action = "list"
     }
     */
}
