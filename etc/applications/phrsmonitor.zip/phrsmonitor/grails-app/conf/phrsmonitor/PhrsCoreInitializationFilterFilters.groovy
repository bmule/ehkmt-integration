package phrsmonitor

//import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User



import at.srfg.kmt.ehealth.phrs.presentation.utils.PhrsCoreInitialization
import at.srfg.kmt.ehealth.phrs.presentation.utils.PhrsCoreInitializationException
import org.apache.commons.logging.LogFactory
import org.apache.commons.logging.Log
//import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User
//import org.apache.shiro.SecurityUtils;


class PhrsCoreInitializationFilterFilters {
    private static final Log LOGGER = LogFactory.getLog(this)

    def filters = {
        all(controller: '*', action: '*') {   //except save

            before = {
                boolean isCoreVocabAvailable = false;
                try {
                    isCoreVocabAvailable = PhrsCoreInitialization.getInstance().isInteropVocabServerLoaded()
                    if (!isCoreVocabAvailable) {
                        //try to load, maybe server is ready ?
                        PhrsCoreInitialization.getInstance().initializeCoreVocabularyServer()
                        //ask again
                        isCoreVocabAvailable = PhrsCoreInitialization.getInstance().isInteropVocabServerLoaded()
                    }
                } catch (PhrsCoreInitializationException e) {
                    LOGGER.error("PHRS core is not available and the vocabulary service is required to support the User Interfaces, please start the JBOSS server, it must be completely started", e)
                    isCoreVocabAvailable=false
                }


                if (!isCoreVocabAvailable) {
                    LOGGER.error("PHRS core is not available and the vocabulary service is required to support the User Interfaces, please start the JBOSS server, it must be completely started")
                    render(view:'error_core_unavailable_mainmenu', controller: 'mainMenu', action: 'error_core_unavailable')//template: '/shared/error_phrscore_initialization')
                    return false    //stops other filters,etc

                }

            }
            /*
            after = {

            }
            afterView = {

            }*/
        }
    }

}
