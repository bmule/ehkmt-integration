package phrsmonitor

class AuthorizationCheckFilters {

    def filters = {
        all(controller:'coreMessage', action:'*') {
            before = {
                
            }
            after = {
                
            }
            afterView = {
                
            }
        }
    }
    
}
