package phrsmonitor


import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants

class TestStuffController {
    /*
        def xxx = new Application(params)

        xxx.clearErrors()

        if (params?.createDate) {
            xxx.createDate = new Date().parse("MM/dd/yyyy", params.createDate)
        } else {
            xxx.createDate = null
        }

        if (!xxx.hasErrors()){
            xxx.save(failOnError:true)
        }
     */
    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
    //matches form model, but we can use from elsewhere
    static final String CLASS_URI="phrsmonitor.TestStuff"

    //default unless changed
    User targetUser = authenticatedUser
    String targetUserUri =  targetUser?.healthProfileUid

    Map attrMap=[:]
    def PhrsCommonsService //injected service
    def controllerOptionProperties


    def failAuthorization = {
         redirect(action: "goHome", params: params)
    }
    def goHome = {
        redirect(controller:"mainMenu", action: "index", params: params)
    }

    def index = {
        redirect(action: "list", params: params)
    }

    def list = {

        //parms for phr_ownerUri by authenticated user
        //if no params, then redirect to listAll and check permission
        //'instanceName':testStuffInstance,'className':TestStuff,
       /*
        boolean okPermission= PhrsCommonsService.processResourceAuthorization(
          [ 'viewInstanceName':"testStuffInstance",'classInstance':TestStuff,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
        //hack

        if(! okPermission) {
            redirect(action: "failAuthorization", params: params)
        }
         */
            params.max = Math.min(params.max ? params.int('max') : 10, 100)

            [testStuffInstanceList: TestStuff.list(params),
             testStuffInstanceTotal: TestStuff.count(),
             'theAction':'list',
             'visualizationAttributes':PhrsCommonsService.visualizationAttributes(['classUri':CLASS_URI]),
             'controllerOptionProperties':controllerOptionProperties]

        //PhrsCommonsService.queryList(
         //  [ 'instanceName':testStuffInstance,'className':TestStuff,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
    }

    def listAll = {
        /*boolean okPermission= PhrsCommonsService.processResourceAuthorization(
           ['viewInstanceName':"testStuffInstance",'classInstance':TestStuff,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])

        if(!okPermission ){
            redirect(action: "failAuthorization", params: params)
        }
         */
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
            [
                    testStuffInstanceList: TestStuff.list(params),
                    testStuffInstanceTotal: TestStuff.count(),
                    'theAction':'list',
                    'visualizationAttributes':PhrsCommonsService.visualizationAttributes(['classUri':CLASS_URI]),
                    'controllerOptionProperties':controllerOptionProperties
            ]
    }

    def create = {
        def testStuffInstance = new TestStuff()
        testStuffInstance.properties = params
        testStuffInstance.ownerUser=authenticatedUser


        boolean okPermission= true
        //PhrsCommonsService.processResourceAuthorization(
         // ['instanceName':testStuffInstance,'className':TestStuff,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_CREATE])
        if(! okPermission){
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff.label', default: 'TestStuff'), params.id])}"
            println("permission fail CREATE")
            redirect(action: "index")
        }

        //preform afterwards in case of malicious tampering of properties.
        //PhrsCommonsService.processResourceInit(
        //     [ 'instanceName':testStuffInstance,'className':TestStuff,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'attrMap':attrMap])

        //edit view does both edit and create
        render(view: "edit", model: [testStuffInstance: testStuffInstance,'theAction':'create'])
    }

    def save = {
        def testStuffInstance = new TestStuff(params)
        testStuffInstance.clearErrors()

        PhrsCommonsService.prepareParamsValidation(['params':params,'classUri':CLASS_URI])
       /* params.remove("hideDate")
        params.remove("ownerUser")
        params.remove("createDate")
        */

        if( !testStuffInstance.validate(params.keySet().toList()) ) {
            println("validation fail")
            testStuffInstance.errors.each {
               println it
            }
        }else {
            println("validation ok")
        }

        println("CLASS_URI"+CLASS_URI)
       //beanInput, classUri, paramsMap, theAuthenticatedUser, attrMap
        boolean okSave= true
        //PhrsCommonsService.processResourceToPersist(
         //       [ 'instanceName':testStuffInstance,'className':TestStuff,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'attrMap':attrMap])
        /*
        boolean okPermission= PhrsCommonsService.processResourceAuthorization(
                    [ 'instanceName':testStuffInstance,'className':TestStuff,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SAVE])
        if(! okPermission){
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff.label', default: 'TestStuff'), params.id])}"
            println("permission fail SAVE")
            redirect(action: "index")
        } */
        //permission check.... that sends a message if no permission
        if( ! okSave){
          println("")
          redirect(action: "index")
        }
        else if (testStuffInstance.save(flush: true)) {
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'testStuff.label', default: 'TestStuff'), testStuffInstance.id])}"
            redirect(action: "show", id: testStuffInstance.id)
        }
        else if(testStuffInstance.errors){
               testStuffInstance.errors.each{
                   print("error"+it)
               }
            //edit view does both edit and create
            render(view: "edit", model: [testStuffInstance: testStuffInstance,'theAction':'create'])
        }
    }

    def show = {
        def testStuffInstance = TestStuff.get(params.id)


        if (!testStuffInstance) {

            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff.label', default: 'TestStuff'), params.id])}"
            redirect(action: "list")
        }
        else {
            //can pass only resource uri and owner uri, authenticated user id or uri
            boolean okPermission= PhrsCommonsService.processResourceAuthorization(
                    [ 'instanceName':testStuffInstance,'className':TestStuff,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
            if(! okPermission){
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff.label', default: 'TestStuff'), params.id])}"
            println("permission fail")
            redirect(action: "index")
            }
            else [testStuffInstance: testStuffInstance,'theAction':'show']
        }
    }

    def edit = {
        def testStuffInstance = TestStuff.get(params.id)
        if (!testStuffInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff.label', default: 'TestStuff'), params.id])}"
            redirect(action: "list")
        }
        else {
            boolean okPermission= true
            //PhrsCommonsService.processResourceAuthorization(
              //      [ 'instanceName':testStuffInstance,'className':TestStuff,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_EDIT])
            if(! okPermission){
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff.label', default: 'TestStuff'), params.id])}"
            println("permission fail EDIT")
            redirect(action: "index")
            }
            return  [testStuffInstance: testStuffInstance,'theAction':'edit']
        }
    }

    def update = {
        def testStuffInstance = TestStuff.get(params.id)

        if (testStuffInstance) {
            boolean okPermission= true
            //PhrsCommonsService.processResourceAuthorization(
              //      ['instanceName':testStuffInstance,'className':TestStuff,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_EDIT])
           /* if(! okPermission){
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff.label', default: 'TestStuff'), params.id])}"
                println("permission fail UPDATE (EDIT)")
                redirect(action: "index")
            } */

            if (params.version) {
                def version = params.version.toLong()
                if (testStuffInstance.version > version) {
                    
                    testStuffInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'testStuff.label', default: 'TestStuff')] as Object[], "Another user has updated this TestStuff while you were editing")
                    render(view: "edit", model: [testStuffInstance: testStuffInstance,'theAction':'edit'])
                    return
                }
            }
            testStuffInstance.properties = params
            if (!testStuffInstance.hasErrors() && testStuffInstance.save(flush: true)) {
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'testStuff.label', default: 'TestStuff'), testStuffInstance.id])}"
                redirect(action: "show", id: testStuffInstance.id)
            }
            else {

                render(view: "edit", model: [testStuffInstance: testStuffInstance,'theAction':'edit'])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff.label', default: 'TestStuff'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def testStuffInstance = TestStuff.get(params.id)
        if (testStuffInstance) {
            boolean okPermission= PhrsCommonsService.processResourceAuthorization(
                    [ 'instanceName':testStuffInstance,'className':TestStuff,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_DELETE])
            if(! okPermission){
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff.label', default: 'TestStuff'), params.id])}"
            println("permission fail DELETE")
            redirect(action: "index")
            }
            try {
                testStuffInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'testStuff.label', default: 'TestStuff'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'testStuff.label', default: 'TestStuff'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff.label', default: 'TestStuff'), params.id])}"
            redirect(action: "list")
        }
    }
}
