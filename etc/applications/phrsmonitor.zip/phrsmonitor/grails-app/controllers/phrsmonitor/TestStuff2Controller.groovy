package phrsmonitor


import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants

class TestStuff2Controller {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
    //matches form model, but we can use from elsewhere
    static final String CLASS_URI = "phrsmonitor.TestStuff2"

    //default unless changed
    User targetUser = authenticatedUser
    String targetUserUri = targetUser?.healthProfileUid

    Map attrMap = [:]
    def PhrsCommonsService //injected service
    def controllerOptionProperties


    def failAuthorization = {
        redirect(action: "goHome", params: params)
    }
    def goHome = {
        redirect(controller: "mainMenu", action: "index", params: params)
    }

    def index = {
        redirect(action: "list", params: params)
    }

    def list = {
        /*
       def c = Account.createCriteria()
       def results = c {
            like("holderFirstName", "Fred%")
             and {
                between("balance", 500, 1000)
                eq("branch", "London")
            }
            maxResults(10)
            order("holderLastName", "desc")
         }

        */
        User filterUser = authenticatedUser
        def filterUserUri = filterUser.healthProfileUid
        def theCriteria = TestStuff2.createCriteria()

        def searchResults  = theCriteria {
            and {
                eq("_phrsBeanClassURI",CLASS_URI)
                eq("_phrsBeanOwnerUri",filterUserUri)
            }
            //            maxResults(10)
            order("_phrsBeanCreateDate", "desc")
        }
        //parms for phr_ownerUri by authenticated user
        //if no params, then redirect to listAll and check permission
        //'instanceName':testStuff2Instance,'className':TestStuff2,

        boolean okPermission = true
        // okPermission= PhrsCommonsService.processResourceAuthorization(
        //  [ 'viewInstanceName':"testStuff2Instance",'classInstance':TestStuff2,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
        //hack

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)

        def temp = [testStuff2InstanceList: TestStuff2.list(params),
                testStuff2InstanceTotal: TestStuff2.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties]

        def results = PhrsCommonsService.queryList(
                ['instanceName': 'testStuff2Instance', 'className': TestStuff2, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
        results
    }

    def listAll = {
        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['viewInstanceName': "testStuff2Instance", 'classInstance': TestStuff2, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }
        /*
       stringList=testStuff2InstanceList
     stringTotal=testStuff2InstanceTotal
        */
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [
                testStuff2InstanceList: TestStuff2.list(params),
                testStuff2InstanceTotal: TestStuff2.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties
        ]
    }

    def create = {
        def testStuff2Instance = new TestStuff2()
        //params.test = [key1: 'value1xx', key1: 'value2xx']
        testStuff2Instance.properties = params

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': testStuff2Instance, 'className': TestStuff2, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_CREATE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff2.label', default: 'TestStuff2'), params.id])}"
            println("permission fail CREATE")
            redirect(action: "index")
        }

        //preform afterwards in case of malicious tampering of properties.
        PhrsCommonsService.processResourceInit(
                ['instanceName': testStuff2Instance, 'className': TestStuff2, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        //edit view does both edit and create
        render(view: "edit", model: [testStuff2Instance: testStuff2Instance, 'theAction': 'create'])
    }

    def save = {
        def testStuff2Instance = new TestStuff2(params)
         def p= params
        def value1 = params?.test?.key1 ? params.test.key1 : null


        println("CLASS_URI" + CLASS_URI)
        //beanInput, classUri, paramsMap, theAuthenticatedUser, attrMap
        boolean okSave = PhrsCommonsService.processResourceToPersist(
                ['instanceName': testStuff2Instance, 'className': TestStuff2, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': testStuff2Instance, 'className': TestStuff2, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SAVE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff2.label', default: 'TestStuff2'), params.id])}"
            println("permission fail SAVE")
            redirect(action: "index")
        }
        //permission check.... that sends a message if no permission
        if (!okSave) {
            println("")
            redirect(action: "index")
        }
        else if (testStuff2Instance.save(flush: true)) {
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'testStuff2.label', default: 'TestStuff2'), testStuff2Instance.id])}"
            redirect(action: "show", id: testStuff2Instance.id)
        }
        else if (testStuff2Instance.errors) {
            testStuff2Instance.errors.each {
                log.error(it)
            }
            //edit view does both edit and create
            render(view: "edit", model: [testStuff2Instance: testStuff2Instance, 'theAction': 'create'])
        }
    }

    def show = {
        def testStuff2Instance = TestStuff2.get(params.id)


        if (!testStuff2Instance) {

            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff2.label', default: 'TestStuff2'), params.id])}"
            redirect(action: "list")
        }
        else {
            //can pass only resource uri and owner uri, authenticated user id or uri
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': testStuff2Instance, 'className': TestStuff2, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff2.label', default: 'TestStuff2'), params.id])}"
                println("permission fail")
                redirect(action: "index")
            }
            else [testStuff2Instance: testStuff2Instance, 'theAction': 'show']
        }
    }

    def edit = {
        def testStuff2Instance = TestStuff2.get(params.id)
        if (!testStuff2Instance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff2.label', default: 'TestStuff2'), params.id])}"
            redirect(action: "list")
        }
        else {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': testStuff2Instance, 'className': TestStuff2, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff2.label', default: 'TestStuff2'), params.id])}"
                println("permission fail EDIT")
                redirect(action: "index")
            }
            return [testStuff2Instance: testStuff2Instance, 'theAction': 'edit']
        }
    }

    def update = {
        def testStuff2Instance = TestStuff2.get(params.id)

        if (testStuff2Instance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': testStuff2Instance, 'className': TestStuff2, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff2.label', default: 'TestStuff2'), params.id])}"
                println("permission fail UPDATE (EDIT)")
                redirect(action: "index")
            }

            if (params.version) {
                def version = params.version.toLong()
                if (testStuff2Instance.version > version) {

                    testStuff2Instance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'testStuff2.label', default: 'TestStuff2')] as Object[], "Another user has updated this TestStuff2 while you were editing")
                    render(view: "edit", model: [testStuff2Instance: testStuff2Instance, 'theAction': 'edit'])
                    return
                }
            }
            testStuff2Instance.properties = params
            if (!testStuff2Instance.hasErrors() && testStuff2Instance.save(flush: true)) {
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'testStuff2.label', default: 'TestStuff2'), testStuff2Instance.id])}"
                redirect(action: "show", id: testStuff2Instance.id)
            }
            else {

                render(view: "edit", model: [testStuff2Instance: testStuff2Instance, 'theAction': 'edit'])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff2.label', default: 'TestStuff2'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def testStuff2Instance = TestStuff2.get(params.id)
        if (testStuff2Instance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': testStuff2Instance, 'className': TestStuff2, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_DELETE])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff2.label', default: 'TestStuff2'), params.id])}"
                println("permission fail DELETE")
                redirect(action: "index")
            }
            try {
                testStuff2Instance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'testStuff2.label', default: 'TestStuff2'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'testStuff2.label', default: 'TestStuff2'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'testStuff2.label', default: 'TestStuff2'), params.id])}"
            redirect(action: "list")
        }
    }
}
