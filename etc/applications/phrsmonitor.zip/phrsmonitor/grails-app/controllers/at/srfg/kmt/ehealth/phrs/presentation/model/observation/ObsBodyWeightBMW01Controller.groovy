package at.srfg.kmt.ehealth.phrs.presentation.model.observation


import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants
import at.srfg.kmt.ehealth.phrs.presentation.utils.InteropServerClient

class ObsBodyWeightBMW01Controller {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
    //matches form model, but we can use from elsewhere
    static final String CLASS_URI = PortalConstants.MODEL_BODY_WEIGHT_CLASS_URI //"at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsBodyWeightBMW01"
    static final String CLASS_URI_INTEROP = PortalConstants.MODEL_BODY_WEIGHT_CLASS_URI //"1.at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsBodyWeightBMW01"
    //default unless changed
    User targetUser = authenticatedUser
    String targetUserUri = targetUser?.healthProfileUid

    Map attrMap = [:]
    def PhrsCommonsService //injected service
    def controllerOptionProperties


    def failAuthorization = {
        redirect(action: "goHome", params: params)
    }
    def goHome = {
        redirect(controller: "mainMenu", action: "index", params: params)
    }

    def index = {
        redirect(action: "list", params: params)
    }
    def importehr = {
        PhrsCommonsService.importEhrByUser(
                ['instanceName': 'obsBodyWeightBMW01Instance', 'className': ObsBodyWeightBMW01, 'theAction': 'list', 'classUriInterop': CLASS_URI_INTEROP, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        redirect(action: "list", params: params)
    }
    def list = {

        def filterUserUri = params?.filterUserUri ? params.filterUserUri : authenticatedUser?.healthProfileUid ? authenticatedUser.healthProfileUid : null

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': 'obsBodyWeightBMW01Instance', 'className': ObsBodyWeightBMW01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
        //TODO permsission filter

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        def results
        try {
            def queryString = "from ObsBodyWeightBMW01 as m where m._phrsBeanOwnerUri=:owner"
            results = ObsBodyWeightBMW01.findAll(queryString, [owner: filterUserUri])
        } catch (Exception e) {
            log.error(e)
        }
        //params.max = Math.min(params.max ? params.int('max') : 10, 100)

        [obsBodyWeightBMW01InstanceList: results,//ObsBodyWeightBMW01.list(params),
                obsBodyWeightBMW01InstanceTotal: ObsBodyWeightBMW01.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties]

        // PhrsCommonsService.queryList(
        //         ['instanceName': 'obsBodyWeightBMW01Instance', 'className': ObsBodyWeightBMW01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
    }

    def listAll = {
        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': 'obsBodyWeightBMW01Instance', 'className': ObsBodyWeightBMW01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [
                obsBodyWeightBMW01InstanceList: ObsBodyWeightBMW01.list(params),
                obsBodyWeightBMW01InstanceTotal: ObsBodyWeightBMW01.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties
        ]
    }

    def create = {
        def obsBodyWeightBMW01Instance = new ObsBodyWeightBMW01()
        obsBodyWeightBMW01Instance.properties = params

        try {
            obsBodyWeightBMW01Instance.height = authenticatedUser?.healthProfileIndividual?.bodyHeight ? authenticatedUser.healthProfileIndividual.bodyHeight : null
        } catch (Exception e) {
            println(e)
        }


        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': obsBodyWeightBMW01Instance, 'className': ObsBodyWeightBMW01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_CREATE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01'), params.id])}"
            println("permission fail CREATE")
            redirect(action: "index")
        }

        //preform afterwards in case of malicious tampering of properties.
        PhrsCommonsService.processResourceInit(
                ['instanceName': obsBodyWeightBMW01Instance, 'className': ObsBodyWeightBMW01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        //edit view does both edit and create
        render(view: "edit", model: [obsBodyWeightBMW01Instance: obsBodyWeightBMW01Instance, 'theAction': 'create'])
    }

    def save = {
        def obsBodyWeightBMW01Instance = new ObsBodyWeightBMW01(params)

        try {
            //if (obsBodyWeightBMW01Instance?.bodyBMI) {

            //} else {
            obsBodyWeightBMW01Instance.bodyBMI =
                at.srfg.kmt.ehealth.phrs.presentation.utils.HealthyRules.computeBMI(obsBodyWeightBMW01Instance?.bodyweight, obsBodyWeightBMW01Instance?.height)
            //}
        } catch (Exception e) {
            println("exception BMI " + e)
        }


        boolean okSave = PhrsCommonsService.processResourceToPersist(
                ['instanceName': obsBodyWeightBMW01Instance, 'className': ObsBodyWeightBMW01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        if (PortalConstants.JSON_TEST) {
            def json = obsBodyWeightBMW01Instance.encodeAsJSON()
            println("json = " + json)
        }

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': obsBodyWeightBMW01Instance, 'className': ObsBodyWeightBMW01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SAVE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01'), params.id])}"
            //println("permission fail SAVE")
            redirect(action: "index")
        }
        //permission check.... that sends a message if no permission
        try {
            if (authenticatedUser && obsBodyWeightBMW01Instance?.height) authenticatedUser.healthProfileIndividual.bodyHeight = obsBodyWeightBMW01Instance.height
        } catch (Exception e) {}

        if (!okSave) {
            println("")
            redirect(action: "index")
        }
        else if (obsBodyWeightBMW01Instance.save(flush: true)) {
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01'), obsBodyWeightBMW01Instance.id])}"
            /* try {
                //def jsonOject = obsBodyWeightBMW01Instance.encodeAsJSON()

                boolean okInterop = PhrsCommonsService.processResourceInterop(
                        ['instanceName': obsBodyWeightBMW01Instance, 'className': ObsBodyWeightBMW01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser,
                                'jsonObject': obsBodyWeightBMW01Instance.encodeAsJSON(), 'action': PortalConstants.ACTION_CONTROLLER_SAVE])

            } catch (Exception e) {
                println("restPersistObject error" + e.stackTrace)
            }*/
            if (PortalConstants.CORE_WRITE) {
                try {
                    boolean okInterop = PhrsCommonsService.processResourceInterop(
                            ['instanceName': obsBodyWeightBMW01Instance,
                                    'className': ObsBodyWeightBMW01,
                                    'jsonObject': obsBodyWeightBMW01Instance.encodeAsJSON(),
                                    'classUri': CLASS_URI, 'params': params,
                                    'authenticatedUser': authenticatedUser,
                                    'action': PortalConstants.ACTION_CONTROLLER_SAVE])

                } catch (Exception e) {
                    log.error(e)  //println("restPersistObject error" + e.stackTrace)
                }
            }

            redirect(action: "show", id: obsBodyWeightBMW01Instance.id)
        }
        else if (obsBodyWeightBMW01Instance.errors) {
            obsBodyWeightBMW01Instance.errors.each {
                log.error(it)
            }
            //edit view does both edit and create
            render(view: "edit", model: [obsBodyWeightBMW01Instance: obsBodyWeightBMW01Instance, 'theAction': 'create'])
        }
    }

    def show = {
        def obsBodyWeightBMW01Instance = ObsBodyWeightBMW01.get(params.id)


        if (!obsBodyWeightBMW01Instance) {

            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01'), params.id])}"
            redirect(action: "list")
        }
        else {
            //can pass only resource uri and owner uri, authenticated user id or uri
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': obsBodyWeightBMW01Instance, 'className': ObsBodyWeightBMW01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01'), params.id])}"
                println("permission fail")
                redirect(action: "index")
            }
            else [obsBodyWeightBMW01Instance: obsBodyWeightBMW01Instance, 'theAction': 'show']
        }
    }

    def edit = {
        def obsBodyWeightBMW01Instance = ObsBodyWeightBMW01.get(params.id)

        try {

            obsBodyWeightBMW01Instance.bodyBMI =
                at.srfg.kmt.ehealth.phrs.presentation.utils.HealthyRules.computeBMI(obsBodyWeightBMW01Instance?.bodyweight, obsBodyWeightBMW01Instance?.height)

        } catch (Exception e) {
            println("exception BMI " + e)
        }
        try {
            if (authenticatedUser && obsBodyWeightBMW01Instance?.height) authenticatedUser.healthProfileIndividual.bodyHeight = obsBodyWeightBMW01Instance.height
        } catch (Exception e) {}

        if (!obsBodyWeightBMW01Instance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01'), params.id])}"
            redirect(action: "list")
        }
        else {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': obsBodyWeightBMW01Instance, 'className': ObsBodyWeightBMW01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01'), params.id])}"
                println("permission fail EDIT")
                redirect(action: "index")
            }
            return [obsBodyWeightBMW01Instance: obsBodyWeightBMW01Instance, 'theAction': 'edit']
        }
    }

    def update = {
        def obsBodyWeightBMW01Instance = ObsBodyWeightBMW01.get(params.id)

        if (obsBodyWeightBMW01Instance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': obsBodyWeightBMW01Instance, 'className': ObsBodyWeightBMW01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01'), params.id])}"
                println("permission fail UPDATE (EDIT)")
                redirect(action: "index")
            }
            try {
                obsBodyWeightBMW01Instance.bodyBMI =
                    at.srfg.kmt.ehealth.phrs.presentation.utils.HealthyRules.computeBMI(obsBodyWeightBMW01Instance?.bodyweight, obsBodyWeightBMW01Instance?.height)
            } catch (Exception e) {
                println("exception BMI update" + e)
            }
            if (params.version) {
                def version = params.version.toLong()
                if (obsBodyWeightBMW01Instance.version > version) {

                    obsBodyWeightBMW01Instance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01')] as Object[], "Another user has updated this ObsBodyWeightBMW01 while you were editing")
                    render(view: "edit", model: [obsBodyWeightBMW01Instance: obsBodyWeightBMW01Instance, 'theAction': 'edit'])
                    return
                }
            }
            obsBodyWeightBMW01Instance.properties = params
            if (!obsBodyWeightBMW01Instance.hasErrors() && obsBodyWeightBMW01Instance.save(flush: true)) {
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01'), obsBodyWeightBMW01Instance.id])}"
                if (PortalConstants.CORE_WRITE) {
                    try {
                        boolean okInterop = PhrsCommonsService.processResourceInterop(
                                ['instanceName': obsBodyWeightBMW01Instance,
                                        'className': ObsBodyWeightBMW01,
                                        'jsonObject': obsBodyWeightBMW01Instance.encodeAsJSON(),
                                        'classUri': CLASS_URI, 'params': params,
                                        'authenticatedUser': authenticatedUser,
                                        'action': PortalConstants.ACTION_CONTROLLER_SAVE])

                    } catch (Exception e) {
                        log.error(e)  //println("restPersistObject error" + e.stackTrace)
                    }
                }


                redirect(action: "show", id: obsBodyWeightBMW01Instance.id)
            }
            else {

                render(view: "edit", model: [obsBodyWeightBMW01Instance: obsBodyWeightBMW01Instance, 'theAction': 'edit'])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def obsBodyWeightBMW01Instance = ObsBodyWeightBMW01.get(params.id)
        if (obsBodyWeightBMW01Instance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': obsBodyWeightBMW01Instance, 'className': ObsBodyWeightBMW01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_DELETE])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01'), params.id])}"
                println("permission fail DELETE")
                redirect(action: "index")
            }
            try {
                obsBodyWeightBMW01Instance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBodyWeightBMW01.label', default: 'ObsBodyWeightBMW01'), params.id])}"
            redirect(action: "list")
        }
    }
}
