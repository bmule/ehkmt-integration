package at.srfg.kmt.ehealth.phrs.presentation.model.profile

import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants

class ContactInfoController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
    //matches form model, but we can use from elsewhere
    static final String CLASS_URI = "at.srfg.kmt.ehealth.phrs.presentation.model.profile.ContactInfo"

    //default unless changed
    User targetUser = authenticatedUser
    String targetUserUri = targetUser?.healthProfileUid

    Map attrMap = [:]
    def PhrsCommonsService //injected service
    def controllerOptionProperties


    def failAuthorization = {
        redirect(action: "goHome", params: params)
    }
    def goHome = {
        redirect(controller: "mainMenu", action: "index", params: params)
    }

    def index = {
        redirect(action: "list", params: params)
    }

    def list = {
        boolean filterUserFound = params?.filterUserUri ? true : false

        def filterUserUri = params?.filterUserUri ? params.filterUserUri : authenticatedUser?.healthProfileUid ? authenticatedUser.healthProfileUid : null

        //def contactInfoInstance =    ContactInfo.findByOwnerUser(authenticatedUser) //ContactInfo.find('_phrsBeanOwnerUri':filterUserUri)
        //ContactInfo.get(filterUserId)
        def contactInfoInstance
        try {
            def queryString = "from ContactInfo as m where m._phrsBeanOwnerUri=:owner"
            //find, not findAll !
            contactInfoInstance = ContactInfo.find(queryString, [owner: filterUserUri])

        } catch (Exception e) {
            log.error(e)
        }

        if (contactInfoInstance) {
            //exists, show
            //def contactInfoId = ContactInfo.findByOwnerUserId(authenticatedUser.id)
           /*params.id = contactInfoInstance.id  //:["myparam":"myvalue"]
            if(filterUserFound) {
                params.filterUserUri = filterUserUri
            }   */

            redirect(action: "show", id:contactInfoInstance.id )

        } else {
            //no exist, create
            redirect(action: "create")

        }

        /*
       TODO permission fail on save
       flash.message = "${message(code: 'default.created.message', args: [message(code: 'permisssion.fail.label', default: 'You are not the owner'), contactInfoInstance.id])}"

        */

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': 'contactInfoInstance', 'className': ContactInfo, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
        //hack

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)

        [contactInfoInstanceList: ContactInfo.list(params),
                contactInfoInstanceTotal: ContactInfo.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties]

        // PhrsCommonsService.queryList(
        //    [ 'instanceName':null,'className':ContactInfo,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
    }

    def listAll = {
        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': 'contactInfoInstance', 'className': ContactInfo, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [
                contactInfoInstanceList: ContactInfo.list(params),
                contactInfoInstanceTotal: ContactInfo.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties
        ]
    }

    def create = {
        def contactInfoInstance = new ContactInfo()
        contactInfoInstance.properties = params

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': contactInfoInstance, 'className': ContactInfo, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_CREATE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'contactInfo.label', default: 'ContactInfo'), params.id])}"
            println("permission fail CREATE")
            redirect(action: "index")
        }

        //preform afterwards in case of malicious tampering of properties.
        PhrsCommonsService.processResourceInit(
                ['instanceName': contactInfoInstance, 'className': ContactInfo, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        //edit view does both edit and create
        render(view: "edit", model: [contactInfoInstance: contactInfoInstance, 'theAction': 'create'])
    }

    def save = {
        def contactInfoInstance = new ContactInfo(params)
        //<g:hiddenField name="ownerUser.id" value="${medicationSummaryInstance?.ownerUser.id}"/>
        if (contactInfoInstance?.ownerUser?.id == authenticatedUser?.id) {
            // allowed
        } else {
            flash.message = "${message(code: 'permisssion.fail.label', args: [message(code: 'contactInfo.label', default: 'You are not permitted to save this data'), params.id])}"
            redirect(action: "index")
        }

        contactInfoInstance.ownerUser = authenticatedUser

        //contactInfoInstance.healthProfile = authenticatedUser?.healthProfile

        //contact info does not have commonform properties?
        boolean okSave = PhrsCommonsService.processResourceToPersist(
                ['instanceName': contactInfoInstance, 'className': ContactInfo, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': contactInfoInstance, 'className': ContactInfo, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SAVE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'contactInfo.label', default: 'ContactInfo'), params.id])}"
            println("permission fail SAVE")
            redirect(action: "index")
        }
        //permission check.... that sends a message if no permission
        if (!okSave) {
            println("")
            redirect(action: "index")
        }
        else if (contactInfoInstance.save(flush: true)) {
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'contactInfo.label', default: 'ContactInfo'), contactInfoInstance.id])}"
            redirect(action: "show", id: contactInfoInstance.id)
        }
        else if (contactInfoInstance.errors) {
            contactInfoInstance.errors.each {
                log.error(it)
            }
            //edit view does both edit and create
            render(view: "edit", model: [contactInfoInstance: contactInfoInstance, 'theAction': 'create'])
        }
    }

    def show = {
        def contactInfoInstance = ContactInfo.get(params.id)

        def filterUserUri = params?.filterUserUri ? params.filterUserUri : authenticatedUser?.healthProfileUid ? authenticatedUser.healthProfileUid : null

        if (!contactInfoInstance) {

            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'contactInfo.label', default: 'ContactInfo'), params.id])}"
            redirect(action: "list")
        }
        else {
            //can pass only resource uri and owner uri, authenticated user id or uri
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': contactInfoInstance, 'className': ContactInfo, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'contactInfo.label', default: 'ContactInfo'), params.id])}"
                println("permission fail")
                redirect(action: "index")
            }
            else [contactInfoInstance: contactInfoInstance, 'theAction': 'show']
        }
    }

    def edit = {
        def contactInfoInstance = ContactInfo.get(params.id)
        if (!contactInfoInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'contactInfo.label', default: 'ContactInfo'), params.id])}"
            redirect(action: "list")
        }
        else {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': contactInfoInstance, 'className': ContactInfo, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'contactInfo.label', default: 'ContactInfo'), params.id])}"
                println("permission fail EDIT")
                redirect(action: "index")
            }
            return [contactInfoInstance: contactInfoInstance, 'theAction': 'edit']
        }
    }

    def update = {
        def contactInfoInstance = ContactInfo.get(params.id)


        if (contactInfoInstance) {

            if (contactInfoInstance?.ownerUser?.id == authenticatedUser?.id) {
                // allowed
            } else {
                flash.message = "${message(code: 'permisssion.fail.label', args: [message(code: 'contactInfo.label', default: 'You are not permitted to save this data'), params.id])}"

            } /*
            try{
            //contactInfoInstance.ownerUser = authenticatedUser

            //contactInfoInstance.healthProfile = authenticatedUser?.healthProfile
            } catch (Exception e){
                //log.error(e)
                println("error updating contactInfoInstance")
            }*/
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': contactInfoInstance, 'className': ContactInfo, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'contactInfo.label', default: 'ContactInfo'), params.id])}"
                println("permission fail UPDATE (EDIT)")
                redirect(action: "index")
            }

            if (params.version) {
                def version = params.version.toLong()
                if (contactInfoInstance.version > version) {

                    contactInfoInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'contactInfo.label', default: 'ContactInfo')] as Object[], "Another user has updated this ContactInfo while you were editing")
                    render(view: "edit", model: [contactInfoInstance: contactInfoInstance, 'theAction': 'edit'])
                    return
                }
            }
            contactInfoInstance.properties = params
            if (!contactInfoInstance.hasErrors() && contactInfoInstance.save(flush: true)) {
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'contactInfo.label', default: 'ContactInfo'), contactInfoInstance.id])}"
                redirect(action: "show", id: contactInfoInstance.id)
            }
            else {

                render(view: "edit", model: [contactInfoInstance: contactInfoInstance, 'theAction': 'edit'])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'contactInfo.label', default: 'ContactInfo'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def contactInfoInstance = ContactInfo.get(params.id)
        if (contactInfoInstance) {

            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': contactInfoInstance, 'className': ContactInfo, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_DELETE])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'contactInfo.label', default: 'ContactInfo'), params.id])}"
                println("permission fail DELETE")
                redirect(action: "index")
            }

            /*  no delete possible
            try {
                contactInfoInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'contactInfo.label', default: 'ContactInfo'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'contactInfo.label', default: 'ContactInfo'), params.id])}"
                redirect(action: "show", id: params.id)
            }*/
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'contactInfo.label', default: 'ContactInfo'), params.id])}"
            redirect(action: "list")
        }
    }
}
