package at.srfg.kmt.ehealth.phrs.presentation.model.observation


import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants
import at.srfg.kmt.ehealth.phrs.presentation.utils.KnLookupSupportService
//import at.srfg.kmt.ehealth.phrs.presentation.utils.RestServices

import at.srfg.kmt.ehealth.phrs.presentation.utils.ViewLabelValue

class ActivityOfDailyLivingItemController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
    //matches form model, but we can use from elsewhere
    static final String CLASS_URI = PortalConstants.MODEL_ACTIVITY_OF_DAILY_LIVING_CLASS_URI //"at.srfg.kmt.ehealth.phrs.presentation.model.observation.ActivityOfDailyLivingItem"
    static final String CLASS_URI_INTEROP = PortalConstants.MODEL_ACTIVITY_OF_DAILY_LIVING_CLASS_URI //"1.at.srfg.kmt.ehealth.phrs.presentation.model.observation.ActivityOfDailyLivingItem"

    //default unless changed
    User targetUser = authenticatedUser
    String targetUserUri = targetUser?.healthProfileUid

    Map attrMap = [:]
    def PhrsCommonsService //injected service
    def controllerOptionProperties

    static boolean tableOrientedFlag = false

    def failAuthorization = {
        redirect(action: "goHome", params: params)
    }
    def goHome = {
        redirect(controller: "mainMenu", action: "index", params: params)
    }

    def index = {
        redirect(action: "list", params: params)
    }
    def importehr = {
        PhrsCommonsService.importEhrByUser(
                ['instanceName': 'activityOfDailyLivingItemInstance', 'className': ActivityOfDailyLivingItem, 'theAction': 'list', 'classUriInterop': CLASS_URI_INTEROP, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        redirect(action: "list", params: params)
    }
    def list = {

        def filterUserUri = params?.filterUserUri ? params.filterUserUri : authenticatedUser?.healthProfileUid ? authenticatedUser.healthProfileUid : null

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': 'activityOfDailyLivingItemInstance', 'className': ActivityOfDailyLivingItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
        //TODO permissions user filter instead for roles and action, but need to get authenticated user in filter somehow
        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }
        //TODO def filterUserId =  authenticatedUser.id

        /*
        * setup select box items, only show what user doesn't have
         */

        def results
        try {
            def queryString = "from ActivityOfDailyLivingItem as m where m._phrsBeanOwnerUri=:owner"
            results = ActivityOfDailyLivingItem.findAll(queryString, [owner: filterUserUri])

        } catch (Exception e) {
            log.error(e)
        }

        def filterIds = results.collect { res -> res?.activityCode}

        String language = 'en'
        def labelValueList = KnLookupSupportService.lookupUITerminologyList(['tag': PortalConstants.TERM_ACTIVITY_OF_DAILY_LIVING_PHRS, 'lang': language])
        def createNewOptions = PhrsCommonsService.filterLabelValueListByIdList(['filterIds': filterIds, 'labelValueList': labelValueList])
        if (!createNewOptions) createNewOptions = new ArrayList<ViewLabelValue>()

        // no paging right now params.max = Math.min(params.max ? params.int('max') : 10, 100)

        [activityOfDailyLivingItemInstanceList: results, //ActivityOfDailyLivingItem.list(params),
                activityOfDailyLivingItemInstanceTotal: ActivityOfDailyLivingItem.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties, 'selectboxCreateNew': createNewOptions]

        //filter by rule e.g. ownerUser _phrsBeanOwnerUri, etc params.ownerUser = XXX
        /*def resultList = PhrsCommonsService.queryList(
           [ 'instanceName':'activityOfDailyLivingItemInstance','className':ActivityOfDailyLivingItem,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
        //append
        resultList['selectboxCreateNew':createNewOptions]
        return resultList
        */
    }

    def listAll = {
        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': 'activityOfDailyLivingItemInstance', 'className': ActivityOfDailyLivingItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [
                activityOfDailyLivingItemInstanceList: ActivityOfDailyLivingItem.list(params),
                activityOfDailyLivingItemInstanceTotal: ActivityOfDailyLivingItem.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties
        ]
    }

    def create = {
        def activityOfDailyLivingItemInstance = new ActivityOfDailyLivingItem()

        activityOfDailyLivingItemInstance.properties = params

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': activityOfDailyLivingItemInstance, 'className': ActivityOfDailyLivingItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_CREATE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem'), params.id])}"
            println("permission fail CREATE")
            redirect(action: "index")
        }

        //preform afterwards in case of malicious tampering of properties.
        PhrsCommonsService.processResourceInit(
                ['instanceName': activityOfDailyLivingItemInstance, 'className': ActivityOfDailyLivingItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        //edit view does both edit and create
        return render(view: "edit", model: [activityOfDailyLivingItemInstance: activityOfDailyLivingItemInstance, 'theAction': 'create'])

    }

    def save = {
        def activityOfDailyLivingItemInstance = new ActivityOfDailyLivingItem(params)

        if (PortalConstants.JSON_TEST) {
            def json = activityOfDailyLivingItemInstance.encodeAsJSON()
            println("json = " + json)
        }

        //beanInput, classUri, paramsMap, theAuthenticatedUser, attrMap
        boolean okSave = PhrsCommonsService.processResourceToPersist(
                ['instanceName': activityOfDailyLivingItemInstance, 'className': ActivityOfDailyLivingItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': activityOfDailyLivingItemInstance, 'className': ActivityOfDailyLivingItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SAVE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem'), params.id])}"
            println("permission fail SAVE")
            redirect(action: "index")
        }
        //permission check.... that sends a message if no permission
        if (!okSave) {
            println("")
            redirect(action: "index")
        }

        if (activityOfDailyLivingItemInstance.save(flush: true)) {

            if (PortalConstants.CORE_WRITE) {
                try {
                    boolean okInterop = PhrsCommonsService.processResourceInterop(
                            ['instanceName': activityOfDailyLivingItemInstance,
                                    'className': ActivityOfDailyLivingItem,
                                    'jsonObject': activityOfDailyLivingItemInstance.encodeAsJSON(),
                                    'classUri': CLASS_URI, 'params': params,
                                    'authenticatedUser': authenticatedUser,
                                    'action': PortalConstants.ACTION_CONTROLLER_SAVE])

                } catch (Exception e) {
                    log.error(e)  //println("restPersistObject error" + e.stackTrace)
                }
            }
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem'), activityOfDailyLivingItemInstance.id])}"
            redirect(action: "show", id: activityOfDailyLivingItemInstance.id)
        }
        else if (activityOfDailyLivingItemInstance.errors) {

            activityOfDailyLivingItemInstance.errors.each {
                log.error(it)
                //println(it)
            }
            //edit view does both edit and create
            render(view: "edit", model: [activityOfDailyLivingItemInstance: activityOfDailyLivingItemInstance, 'theAction': 'create'])
        }
    }

    def show = {
        def activityOfDailyLivingItemInstance = ActivityOfDailyLivingItem.get(params.id)


        if (!activityOfDailyLivingItemInstance) {

            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem'), params.id])}"
            redirect(action: "list")
        }
        else {
            //can pass only resource uri and owner uri, authenticated user id or uri
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': activityOfDailyLivingItemInstance, 'className': ActivityOfDailyLivingItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem'), params.id])}"
                println("permission fail")
                redirect(action: "index")
            }

            return [activityOfDailyLivingItemInstance: activityOfDailyLivingItemInstance, 'theAction': 'show']

        }
        //render(view: "showTable", model: [activityOfDailyLivingItemInstance: activityOfDailyLivingItemInstance,'theAction':'show'])
    }

    def edit = {
        def activityOfDailyLivingItemInstance = ActivityOfDailyLivingItem.get(params.id)
        if (!activityOfDailyLivingItemInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem'), params.id])}"
            redirect(action: "list")
        }
        else {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': activityOfDailyLivingItemInstance, 'className': ActivityOfDailyLivingItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem'), params.id])}"
                println("permission fail EDIT")
                redirect(action: "index")
            }

            return [activityOfDailyLivingItemInstance: activityOfDailyLivingItemInstance, 'theAction': 'edit']
        }
    }

    def update = {
        def activityOfDailyLivingItemInstance = ActivityOfDailyLivingItem.get(params.id)

        if (activityOfDailyLivingItemInstance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': activityOfDailyLivingItemInstance, 'className': ActivityOfDailyLivingItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem'), params.id])}"
                println("permission fail UPDATE (EDIT)")
                redirect(action: "index")
            }

            if (params.version) {
                def version = params.version.toLong()
                if (activityOfDailyLivingItemInstance.version > version) {

                    activityOfDailyLivingItemInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem')] as Object[], "Another user has updated this ActivityOfDailyLivingItem while you were editing")
                    render(view: "edit", model: [activityOfDailyLivingItemInstance: activityOfDailyLivingItemInstance, 'theAction': 'edit'])
                    return
                }
            }
            activityOfDailyLivingItemInstance.properties = params
            if (!activityOfDailyLivingItemInstance.hasErrors() && activityOfDailyLivingItemInstance.save(flush: true)) {

                if (PortalConstants.CORE_WRITE) {
                    try {
                        boolean okInterop = PhrsCommonsService.processResourceInterop(
                                ['instanceName': activityOfDailyLivingItemInstance,
                                        'className': ActivityOfDailyLivingItem,
                                        'jsonObject': activityOfDailyLivingItemInstance.encodeAsJSON(),
                                        'classUri': CLASS_URI, 'params': params,
                                        'authenticatedUser': authenticatedUser,
                                        'action': PortalConstants.ACTION_CONTROLLER_SAVE])

                    } catch (Exception e) {
                        log.error(e)  //println("restPersistObject error" + e.stackTrace)
                    }
                }


                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem'), activityOfDailyLivingItemInstance.id])}"
                redirect(action: "show", id: activityOfDailyLivingItemInstance.id)
            }

            render(view: "edit", model: [activityOfDailyLivingItemInstance: activityOfDailyLivingItemInstance, 'theAction': 'edit'])


        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def activityOfDailyLivingItemInstance = ActivityOfDailyLivingItem.get(params.id)
        if (activityOfDailyLivingItemInstance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': activityOfDailyLivingItemInstance, 'className': ActivityOfDailyLivingItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_DELETE])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem'), params.id])}"
                println("permission fail DELETE")
                redirect(action: "index")
            }
            try {
                activityOfDailyLivingItemInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityOfDailyLivingItem.label', default: 'ActivityOfDailyLivingItem'), params.id])}"
            redirect(action: "list")
        }
    }
}
