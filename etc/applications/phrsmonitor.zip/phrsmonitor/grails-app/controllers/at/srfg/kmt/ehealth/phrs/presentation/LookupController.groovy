package at.srfg.kmt.ehealth.phrs.presentation

/**
 * pt
 */
class LookupController {

    def index = { }

    def terminology = {

        //params
        ['id1':'val1',
         'id2':'val2']
    }

    /*
<select onload="${remoteFunction(controller:LookupController ,
action:'terminology',update:[success:'great', failure:'ohno'],
params:[lang:'en'])}">
    <option>first</option>
    <option>second</option>
</select>




<script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" charset="utf-8">
$(function(){
  $("select#ctlJob").change(function(){
    $.getJSON("/select.php",{id: $(this).val(), ajax: 'true'}, function(j){
      var options = '';
      for (var i = 0; i < j.length; i++) {
        options += '<option value="' + j[i].optionValue + '">' + j[i].optionDisplay + '</option>';
      }
      $("select#ctlPerson").html(options);
    })
  })
})
</script>


[ {optionValue:10, optionDisplay: 'Remy'},
{optionValue:11, optionDisplay: 'Arif'},
{optionValue:12, optionDisplay: 'JC'}]
     */
}
