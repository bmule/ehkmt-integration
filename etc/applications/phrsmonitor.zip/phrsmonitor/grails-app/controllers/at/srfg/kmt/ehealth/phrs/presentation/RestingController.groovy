package at.srfg.kmt.ehealth.phrs.presentation

class RestingController {
    static final String VOCAB_SERVER_CONTEXT = "dataexchange_ws/controlled_item_repository"

    def index = {
    print("index rest")

        redirect(action: "test", params: params)
    }

    def test = {
        print("restTest")
         /*
                 def accessVocabServer = {
            withRest(id: "vocabServer", uri: "http://localhost:8080/" + VOCAB_SERVER_CONTEXT + "/") {
                //auth.basic model.username, model.password
            }
        }
        def queryAction = {
            withRest(id: "vocabServer") {
                def response = get(path: "get?q=2.16.840.1.113883.6.96") // � } /
                // * alternatively def response twitter.get(path: "followers.json") *}
            }
        }
          */
        /*
        def accessVocabServer = {
            println("accessVocabServer")
            withRest(id: "vocabServer", uri: "http://localhost:8080/" + VOCAB_SERVER_CONTEXT + "/") {
                //auth.basic model.username, model.password
            }
        }
        def queryAction = {
            withRest(id: "vocabServer") {
                 println("queryAction")
                def response = get(path: "get?q=2.16.840.1.113883.6.96") // � } /
                // * alternatively def response twitter.get(path: "followers.json") *}
                println("response="+response)

                response
            }
        } */

    }
}