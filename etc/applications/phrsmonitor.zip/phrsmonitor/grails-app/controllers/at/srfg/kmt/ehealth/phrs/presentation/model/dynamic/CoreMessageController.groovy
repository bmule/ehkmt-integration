package at.srfg.kmt.ehealth.phrs.presentation.model.dynamic


import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants

import at.srfg.kmt.ehealth.phrs.presentation.utils.PhrsCoreInitialization

class CoreMessageController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
    //matches form model, but we can use from elsewhere
    static final String CLASS_URI = "at.srfg.kmt.ehealth.phrs.presentation.model.dynamic.CoreMessage"

    //default unless changed
    User targetUser = authenticatedUser
    String targetUserUri = targetUser?.healthProfileUid

    Map attrMap = [:]
    def PhrsCommonsService //injected service
    def controllerOptionProperties


    def failAuthorization = {
        redirect(action: "goHome", params: params)
    }
    def goHome = {
        redirect(controller: "mainMenu", action: "index", params: params)
    }

    def index = {
        redirect(action: "list", params: params)
    }

    def importEhr = {
        String filterUserUri = authenticatedUser?.healthProfileUid ? authenticatedUser.healthProfileUid : null

        if (filterUserUri) {
            //flash message...
            redirect(action: "goHome", params: params)
        }
        //iterate over core class uri, get resources,
        // try to find each in repository by uri FOR authenticated user.
        // by Classes, by User
        // call switch statement on class uri... to create class and clean up
        // permission - owners match authenticated user owner or filter user
        // gather each result and put it in a list for the user
        //

        /*
        def results =
      XX.findAll("from Book as b where b.title like :search or b.author like :search", [search:"The Shi%"])

       CoreMessage msg = new CoreMessage()
        msg.sequence = new Integer(1)
        msg.action = PortalConstants.CORE_MESSAGE_ACTION_IMPORT_EHR
        msg.coreResourceUri
        msg.creatorUri
        msg.ownerUri
        msg.statusCode
        msg.localResourceUri
        msg.interopClassUri

         */

        Set coreClassUris = PhrsCoreInitialization.getInstance().getCoreClassUris()
        Set results = new HashSet()

        def processAction = "import"; //"list"
        def requestedAction = params?.processAction ? params.processAction : null
        def requestedClassUri = params?.classUri ? params.classUri : null


        List<CoreMessage> coreMessages = []

        coreClassUris.each {  coreClassUri ->

            def resultsByClass = processCoreImport(coreClassUri, filterUserUri, processAction, coreMessages)
            results.addAll(resultsByClass)

        }
        //iterate over the results and create messages
        def  coreMessageInstanceList
        def messages = results.collect {result ->
            def obj
        }

        String statusCode
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [coreMessageInstanceList: CoreMessage.list(params),
                coreMessageInstanceTotal: CoreMessage.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties]


        render(view: "edit", model: [coreMessageInstanceList: coreMessageInstanceList, 'theAction': 'list_import'])

    }

    /*
    This will go into another library
     */

    def processCoreImport(coreClassUri, ownerUserUri, processAction, coreMessages) {
        def results
        switch (coreClassUri) {
            case PortalConstants.MODEL_ACTIVITY_OF_DAILY_LIVING_CLASS_URI:

                break;
            case PortalConstants.MODEL_BLOOD_PREASURE_CLASS_URI:

                break;
            case PortalConstants.MODEL_BODY_WEIGHT_CLASS_URI:

                break;
            case PortalConstants.MODEL_MEDICATION_CLASS_URI:

                //query core
                //if stuff, query local. For each local check core
           // def newEhrdata=  findNewEhrData( ownerUri,  classUri, clazzSample,  currentObjectList)

                break;
            case PortalConstants.MODEL_ACTIVITY_ITEM_CLASS_URI:

                break;
            case PortalConstants.MODEL_PROBLEMS_CLASS_URI:

                break;
            case PortalConstants.MODEL_RISK_FACTOR_CLASS_URI:

                break;
            case PortalConstants.MODEL_ACTIVITY_LEVEL_CLASS_URI:

                break;

            default:
                break;

        }

        return results
    }

    def listUnconsumedResources = {

        //parms for phr_ownerUri by authenticated user
        //if no params, then redirect to listAll and check permission
        //'instanceName':coreMessageInstance,'className':CoreMessage,

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['viewInstanceName': "coreMessageInstance", 'classInstance': CoreMessage, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
        //hack

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)

        [coreMessageInstanceList: CoreMessage.list(params),
                coreMessageInstanceTotal: CoreMessage.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties]

        //PhrsCommonsService.queryList(
        //   [ 'instanceName':"coreMessageInstance",'className':CoreMessage,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
    }
    def list = {

        //parms for phr_ownerUri by authenticated user
        //if no params, then redirect to listAll and check permission
        //'instanceName':coreMessageInstance,'className':CoreMessage,

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['viewInstanceName': "coreMessageInstance", 'classInstance': CoreMessage, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
        //hack

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)

        [coreMessageInstanceList: CoreMessage.list(params),
                coreMessageInstanceTotal: CoreMessage.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties]

        //PhrsCommonsService.queryList(
        // [ 'instanceName':"coreMessageInstance",'className':CoreMessage,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
    }

    def listAll = {
        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['viewInstanceName': "coreMessageInstance", 'classInstance': CoreMessage, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [
                coreMessageInstanceList: CoreMessage.list(params),
                coreMessageInstanceTotal: CoreMessage.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties
        ]
    }

    def create = {
        def coreMessageInstance = new CoreMessage()
        coreMessageInstance.properties = params

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': coreMessageInstance, 'className': CoreMessage, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_CREATE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'coreMessage.label', default: 'CoreMessage'), params.id])}"
            // println("permission fail CREATE")
            redirect(action: "index")
        }

        //preform afterwards in case of malicious tampering of properties.
        PhrsCommonsService.processResourceInit(
                ['instanceName': coreMessageInstance, 'className': CoreMessage, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        //edit view does both edit and create
        render(view: "edit", model: [coreMessageInstance: coreMessageInstance, 'theAction': 'create'])
    }

    def save = {
        def coreMessageInstance = new CoreMessage(params)

        println("CLASS_URI" + CLASS_URI)
        //beanInput, classUri, paramsMap, theAuthenticatedUser, attrMap
        boolean okSave = PhrsCommonsService.processResourceToPersist(
                ['instanceName': coreMessageInstance, 'className': CoreMessage, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': coreMessageInstance, 'className': CoreMessage, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SAVE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'coreMessage.label', default: 'CoreMessage'), params.id])}"
            println("permission fail SAVE")
            redirect(action: "index")
        }
        //permission check.... that sends a message if no permission
        if (!okSave) {
            println("")
            redirect(action: "index")
        }
        else if (coreMessageInstance.save(flush: true)) {
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'coreMessage.label', default: 'CoreMessage'), coreMessageInstance.id])}"
            redirect(action: "show", id: coreMessageInstance.id)
        }
        else if (coreMessageInstance.errors) {
            coreMessageInstance.errors.each {
                log.error(it)
            }
            //edit view does both edit and create
            render(view: "edit", model: [coreMessageInstance: coreMessageInstance, 'theAction': 'create'])
        }
    }

    def show = {
        def coreMessageInstance = CoreMessage.get(params.id)


        if (!coreMessageInstance) {

            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'coreMessage.label', default: 'CoreMessage'), params.id])}"
            redirect(action: "list")
        }
        else {
            //can pass only resource uri and owner uri, authenticated user id or uri
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': coreMessageInstance, 'className': CoreMessage, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'coreMessage.label', default: 'CoreMessage'), params.id])}"
                println("permission fail")
                redirect(action: "index")
            }
            else [coreMessageInstance: coreMessageInstance, 'theAction': 'show']
        }
    }

    def edit = {
        def coreMessageInstance = CoreMessage.get(params.id)
        if (!coreMessageInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'coreMessage.label', default: 'CoreMessage'), params.id])}"
            redirect(action: "list")
        }
        else {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': coreMessageInstance, 'className': CoreMessage, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'coreMessage.label', default: 'CoreMessage'), params.id])}"
                println("permission fail EDIT")
                redirect(action: "index")
            }
            return [coreMessageInstance: coreMessageInstance, 'theAction': 'edit']
        }
    }

    def update = {
        def coreMessageInstance = CoreMessage.get(params.id)

        if (coreMessageInstance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': coreMessageInstance, 'className': CoreMessage, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'coreMessage.label', default: 'CoreMessage'), params.id])}"
                println("permission fail UPDATE (EDIT)")
                redirect(action: "index")
            }

            if (params.version) {
                def version = params.version.toLong()
                if (coreMessageInstance.version > version) {

                    coreMessageInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'coreMessage.label', default: 'CoreMessage')] as Object[], "Another user has updated this CoreMessage while you were editing")
                    render(view: "edit", model: [coreMessageInstance: coreMessageInstance, 'theAction': 'edit'])
                    return
                }
            }
            coreMessageInstance.properties = params
            if (!coreMessageInstance.hasErrors() && coreMessageInstance.save(flush: true)) {
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'coreMessage.label', default: 'CoreMessage'), coreMessageInstance.id])}"
                redirect(action: "show", id: coreMessageInstance.id)
            }
            else {

                render(view: "edit", model: [coreMessageInstance: coreMessageInstance, 'theAction': 'edit'])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'coreMessage.label', default: 'CoreMessage'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def coreMessageInstance = CoreMessage.get(params.id)
        if (coreMessageInstance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': coreMessageInstance, 'className': CoreMessage, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_DELETE])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'coreMessage.label', default: 'CoreMessage'), params.id])}"
                println("permission fail DELETE")
                redirect(action: "index")
            }
            try {
                coreMessageInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'coreMessage.label', default: 'CoreMessage'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'coreMessage.label', default: 'CoreMessage'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'coreMessage.label', default: 'CoreMessage'), params.id])}"
            redirect(action: "list")
        }
    }
}
