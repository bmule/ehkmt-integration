package at.srfg.kmt.ehealth.phrs.presentation.dashboard.phrs

//import org.apache.shiro.SecurityUtils

//import org.apache.shiro.subject.Subject
//import org.apache.shiro.session.Session


import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants

import at.srfg.kmt.ehealth.phrs.presentation.utils.PhrsCoreInitialization
import net.sf.json.JSONObject
import at.srfg.kmt.ehealth.phrs.presentation.model.riskfactors.Riskfactor
import at.srfg.kmt.ehealth.phrs.presentation.model.patientdata.MedicationSummary
import at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsIssue
import at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsBodyWeightBMW01
import at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsBloodPressureA01
import at.srfg.kmt.ehealth.phrs.presentation.model.observation.ActivityOfDailyLivingItem
import at.srfg.kmt.ehealth.phrs.presentation.model.observation.ActivityLevel
import at.srfg.kmt.ehealth.phrs.presentation.model.observation.ActivityItem

/*
authenticatedUser is injected in to all controllers!
Will be null when user is not authenticated
set cookie, but do not use it to build server side gsp, there is a lag

 */
class MainMenuController {

    /*
user.properties[userFields] = params
user.profile.properties[profileFields] = params
  Subject currentUser = SecurityUtils.getSubject() means nothing unless it is authenticated, then
    */

    /*
    def cookie = g.cookie(name: "SESSIONID")
     */
    def storeAttribute = {  attrs ->
        def action = attrs?.menuAction

        if (session) session.setAttribute("menuMainAction", action)
        /*
        if (action) {
            def c = new Cookie('menuMainAction', action)
            c.maxAge = 3600
            // c.maxAge = someNumberInSeconds  3600 * 2  //days
            response.addCookie(c)
        }
        def theCookie = g.cookie(name: "menuMainAction")
        */
        // println("storeAttribute theCookie=" + theCookie)

        // request.cookies.each { println "storeAttribute Cookie: ${it.name} == ${it.value}" }
    }
    //                        render(controller: 'mainMenu', action: 'error_core_unavailable')//template: '/shared/error_phrscore_initialization')
    /*def error_core_unavailable ={

        render(view:"error_core_unavailable")  // render(view: "edit"
    } */
    def index = {

        redirect(action: "home", params: params)
    }

    def home = {
        storeAttribute([menuAction: PortalConstants.ACTION_MAIN_MENU_HOME])
        /*
        //currentUser = SecurityUtils.getSubject();
        println("HOME authenticatedUser .username is user.id=" + authenticatedUser?.username + " is " + authenticatedUser?.id)
        println("authenticatedUser healthProfileUid =" + authenticatedUser?.healthProfileUid)
        println("YYY0 Index authenticatedUser?.username = " + authenticatedUser?.username + "authenticatedUser.profile.id=" + authenticatedUser.profile.id)
        println("authenticatedUser.id=" + authenticatedUser?.id)

        //sessionShiro = currentUser.getSession();
        session.setAttribute("mainMenu", "home");
        sessionShiro.getAttribute("mainMenu")
        println("YYYY sessionShiro.properties.entrySet()=" + sessionShiro.properties.entrySet())

        println("currentUser.principal?.properties=" + currentUser.principal?.properties?.entrySet())
        println("currentUser.properties.entrySet=" + currentUser?.properties?.entrySet())

        //currentUser.session.attributeKeys
        if (!currentUser.isAuthenticated()) {
            println("shiro test currentUser is NOT authenticated")
        } else {
            println("shiro test currentUser IS authenticated")
        }
        //get the current Subject
        //currentUser.getSession(true)

        if (currentUser.hasRole("administrator")) {
            println("has role admin")

        } else {
            println("not role admin")
        }

        println("/////home authenticatedUser?.username = " + authenticatedUser?.username)
        */
        render(view: "section_home", model: ['controllerMenuMainAction': PortalConstants.ACTION_MAIN_MENU_HOME])
    }

    def section_actionplan = {
        storeAttribute([menuAction: PortalConstants.ACTION_MAIN_MENU_ACTIONPLAN])
        render(view: "section_actionplan", model: ['controllerMenuMainAction': PortalConstants.ACTION_MAIN_MENU_ACTIONPLAN])
    }
    def section_observations = {
        storeAttribute([menuAction: PortalConstants.ACTION_MAIN_MENU_OBSERVATIONS])
        //println("authenticated user = " + authenticatedUser?.username)
        render(view: "section_observations", model: ['controllerMenuMainAction': PortalConstants.ACTION_MAIN_MENU_OBSERVATIONS])
    }
    def section_education = {
        storeAttribute([menuAction: PortalConstants.ACTION_MAIN_MENU_EDUCATION])
        //site:googlesite
        if (params?.site == 'googlesite') {
            //renders with iframe including google site,etc
            render(view: "section_education_iframe_portal_site_google", model: ['controllerMenuMainAction': PortalConstants.ACTION_MAIN_MENU_EDUCATION])
        } else {
            //currently renders local content
            render(view: "section_education", model: ['controllerMenuMainAction': PortalConstants.ACTION_MAIN_MENU_EDUCATION])
        }
    }
    def section_profile = {
        storeAttribute([menuAction: PortalConstants.ACTION_MAIN_MENU_PROFILE])
        render(view: "section_profile", model: ['controllerMenuMainAction': PortalConstants.ACTION_MAIN_MENU_PROFILE])
    }
    def section_admin = {
        storeAttribute([menuAction: PortalConstants.ACTION_MAIN_MENU_ADMIN])
        render(view: "section_admin", model: ['controllerMenuMainAction': PortalConstants.ACTION_MAIN_MENU_ADMIN])
    }
    def logout = {
        //storeAttribute([menuAction: PortalConstants.ACTION_MAIN_MENU_HOME])
        redirect(action: "home", params: params, model: ['controllerMenuMainAction': PortalConstants.ACTION_MAIN_MENU_HOME])
    }
    def section_home = {
        //storeAttribute([menuAction:  PortalConstants.ACTION_MAIN_MENU_HOME])
        redirect(action: "home", params: params, model: ['controllerMenuMainAction': PortalConstants.ACTION_MAIN_MENU_HOME])
    }
    def loadVocab = {
        try {
            PhrsCoreInitialization.getInstance().loadRemoteServerVocabularies()
        } catch (Exception e) {

        }

    }
    def loadClasses = {
        try {
            PhrsCoreInitialization.getInstance().loadRemoteServerCoreClasses()
        } catch (Exception e) {

        }

    }
    def exportj = {
        ["testme"]
    }
    def exportjsons = {

        def resultsMap = [:]
        resultsMap.ActivityItem = ActivityItem.list()
        resultsMap.ActivityLevel = ActivityLevel.list()
        resultsMap.ActivityOfDailyLivingItem = ActivityOfDailyLivingItem.list()
        resultsMap.ObsBloodPressureA01 = ObsBloodPressureA01.list()
        resultsMap.ObsBodyWeightBMW01 = ObsBodyWeightBMW01.list()
        resultsMap.ObsIssue = ObsIssue.list()
        resultsMap.MedicationSummary = MedicationSummary.list()
        resultsMap.Riskfactor = Riskfactor.list()

        def jsonObjectMap = [:]
        def jsonCollectionString

        def jsonLists = resultsMap.each { key, value ->

            def resultList = value //mapItem.value

            def jsonList = []
            //every on a map entry.key, value
            def jsonObjects = resultList.each { item ->
                //add test data indicator if param source found
                if (item?._phrsBeanClassURI == PortalConstants.MODEL_MEDICATION_CLASS_URI) {
                    item._phrsBeanRefersToSourceUri = item._phrsBeanRefersToSourceUri ? params?.source == 'true' : PortalConstants.EHR_SOURCE_INDICATOR_PHRS_GENERATED_TEST
                }
                def json = item.encodeAsJSON()
                jsonList.add(json)

                if (jsonCollectionString) jsonCollectionString = jsonCollectionString + ',' + json
                else jsonCollectionString = json

                //JSONObject json = new JSONObject()
                /*
                def testMap = item?.properties
                def propertyMap = item?.properties ? item.properties : null
                if (propertyMap) {
                  //  json.putAll(propertyMap);

                   // println("json string:" + json.toString(2));

                    //if (json.) {  exists
                        jsonList.add(json.toString())
                    //}
                }*/
            }
            if (jsonList) {
                jsonObjectMap[(key)] = jsonList

            }

            // collect the list
        }
        jsonCollectionString = '[' + jsonCollectionString + ']'

        println(jsonObjectMap)

        render(view: "exportjsons", contentType: "text/json", params: params,
                model: [jsonCollectionString: jsonCollectionString, 'jsonObjectMap': jsonObjectMap])
    }


}
