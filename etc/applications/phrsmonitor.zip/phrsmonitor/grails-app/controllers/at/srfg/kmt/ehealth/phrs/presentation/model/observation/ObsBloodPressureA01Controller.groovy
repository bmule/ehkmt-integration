package at.srfg.kmt.ehealth.phrs.presentation.model.observation


import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants


class ObsBloodPressureA01Controller {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
    //matches form model, but we can use from elsewhere
    static final String CLASS_URI = PortalConstants.MODEL_BLOOD_PREASURE_CLASS_URI //"at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsBloodPressureA01"

    static final String CLASS_URI_INTEROP = PortalConstants.MODEL_BLOOD_PREASURE_CLASS_URI //"1.at.srfg.kmt.ehealth.phrs.presentation.model.observation.ObsBloodPressureA01"

    //default unless changed
    User targetUser = authenticatedUser
    String targetUserUri = targetUser?.healthProfileUid

    Map attrMap = [:]
    def PhrsCommonsService //injected service
    def controllerOptionProperties


    def failAuthorization = {
        redirect(action: "goHome", params: params)
    }
    def goHome = {
        redirect(controller: "mainMenu", action: "index", params: params)
    }

    def index = {
        redirect(action: "list", params: params)
    }

    def importehr = {

        PhrsCommonsService.importEhrByUser(
                ['instanceName': 'obsBloodPressureA01Instance', 'className': ObsBloodPressureA01, 'theAction': 'list', 'classUriInterop': CLASS_URI_INTEROP, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        redirect(action: "list", params: params)
    }
    def showOverviewVitals = {
        def filterUserUri = params?.filterUserUri ? params.filterUserUri : authenticatedUser?.healthProfileUid ? authenticatedUser.healthProfileUid : null

        //def filterUserId = params?.ownerUser?.id ? params.ownerUser.id : authenticatedUser?.id ? authenticatedUser.id : null
        // def paramUserId = params.get("ownerUser.id") ? params.get("ownerUser.id") : null
        //.ownerUser ? params.ownerUser : null
        //def paramsUserId = params?.'ownerUser.id' ? params.'ownerUser.id' : null

        //User filterUser = User.get(paramsUserId)
        //filterUser = filterUser ? filterUser : authenticatedUser

        def latestBw
        def latestBp

        //chck def filterUserUri
        if (filterUserUri) {
            /*try {
                // filterUserUri = filterUser.healthProfileUid
                latestBw = ObsBodyWeightBMW01.findAll((PortalConstants.Model_PROPERTY_OWNER_URI): filterUserUri, [max: 10, sort: PortalConstants.Model_PROPERTY_CREATE_DATE, order: "desc", offset: 20])
                latestBp = ObsBloodPressureA01.findAll((PortalConstants.Model_PROPERTY_OWNER_URI): filterUserUri, [max: 10, sort: PortalConstants.Model_PROPERTY_CREATE_DATE, order: "desc", offset: 20])
            } catch (Exception e) {
                log.error(e)
            }*/
            //def results
            try {
                def queryString = "from ObsBodyWeightBMW01 as m where m._phrsBeanOwnerUri=:owner"
                latestBw = ObsBodyWeightBMW01.findAll(queryString, [owner: filterUserUri])

            } catch (Exception e) {
                log.error(e)
            }
            try {
                def queryString = "from ObsBloodPressureA01 as m where m._phrsBeanOwnerUri=:owner"
                latestBp = ObsBloodPressureA01.findAll(queryString, [owner: filterUserUri])

            } catch (Exception e) {
                log.error(e)
            }

        }
        def obsBodyWeightBMW01Instance = latestBw ? latestBw[0] : new ObsBodyWeightBMW01()
        def obsBloodPressureA01Instance = latestBp ? latestBp[0] : new ObsBloodPressureA01()

        render(view: "showCurrentVitals", model: [
                obsBloodPressureA01Instance: obsBloodPressureA01Instance, obsBodyWeightBMW01Instance: obsBodyWeightBMW01Instance,
                'theAction': 'show'])
    }
    /*
    update from each and
     */

    def updateFromEhr() {

        def ownerUri = authenticatedUser.healthProfileUid
        def localList = ObsBloodPressureA01.findAll((PortalConstants.Model_PROPERTY_OWNER_URI): ownerUri)
        def newList
        try {
            newList = PhrsCommonsService.findNewEhrData(ownerUri, CLASS_URI_INTEROP, ObsBloodPressureA01, localList)
            if (newList) {
                newList.each { obj ->
                    try {
                        if (obj.save(flush: true)) {
                            // ok
                        }
                    } catch (Exception e) {
                        log.error(e)
                    }
                }
            }
        } catch (Exception e) {
            log.error(e)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)

        redirect(action: "list", params: params)

    }

    def list = {
        //provides a means for nurse to look at data.
        def filterUserUri = params?.filterUserUri ? params.filterUserUri : authenticatedUser?.healthProfileUid ? authenticatedUser.healthProfileUid : null

        /* try {
           if (params && filterUserUri) {
               //filter for the list query
               //params._phrsBeanOwnerUri = filterUserUri
           }
       } catch (Exception e) {
           log.error(e)
       } */

        /*
        _phrsBeanOwnerUri
        try {  ONLY for testing with the debugger otherwise it cycles...
            if (params.ehrtask == 'importehr' || PortalConstants.CORE_IMPORT) {
                updateFromEhr()
            }
        } catch (Exception e) {
            log.error(e)
        }*/
        //parms for phr_ownerUri by authenticated user
        //if no params, then redirect to listAll and check permission
        //'instanceName':obsBloodPressureA01Instance,'className':ObsBloodPressureA01,

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': 'obsBloodPressureA01Instance', 'className': ObsBloodPressureA01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        def results
        try {
            def queryString = "from ObsBloodPressureA01 as m where m._phrsBeanOwnerUri=:owner"
            results = ObsBloodPressureA01.findAll(queryString, [owner: filterUserUri])

        } catch (Exception e) {
            log.error(e)
        }

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        //def filterUserId = params?.ownerUser?.id ? params.ownerUser.id : authenticatedUser?.id ? authenticatedUser.id : null
        //search filter

        //params.max = Math.min(params.max ? params.int('max') : 10, 100)

        [obsBloodPressureA01InstanceList: results, //ObsBloodPressureA01.list(params),
                obsBloodPressureA01InstanceTotal: ObsBloodPressureA01.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties]

        //PhrsCommonsService.queryList(
        //  [ 'instanceName':obsBloodPressureA01Instance,'className':ObsBloodPressureA01,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
    }

    def listAll = {
        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': 'obsBloodPressureA01Instance', 'className': ObsBloodPressureA01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [
                obsBloodPressureA01InstanceList: ObsBloodPressureA01.list(params),
                obsBloodPressureA01InstanceTotal: ObsBloodPressureA01.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties
        ]
    }

    def create = {
        def obsBloodPressureA01Instance = new ObsBloodPressureA01()
        obsBloodPressureA01Instance.properties = params

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': obsBloodPressureA01Instance, 'className': ObsBloodPressureA01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_CREATE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01'), params.id])}"
            println("permission fail CREATE")
            redirect(action: "index")
        }

        //preform afterwards in case of malicious tampering of properties.
        PhrsCommonsService.processResourceInit(
                ['instanceName': obsBloodPressureA01Instance, 'className': ObsBloodPressureA01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        //edit view does both edit and create
        render(view: "edit", model: [obsBloodPressureA01Instance: obsBloodPressureA01Instance, 'theAction': 'create'])
    }

    def save = {
        def obsBloodPressureA01Instance = new ObsBloodPressureA01(params)

        if (PortalConstants.JSON_TEST) {
            def json = obsBloodPressureA01Instance.encodeAsJSON()
            println("json = " + json)
        }

        boolean okSave = PhrsCommonsService.processResourceToPersist(
                ['instanceName': obsBloodPressureA01Instance, 'className': ObsBloodPressureA01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': obsBloodPressureA01Instance, 'className': ObsBloodPressureA01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SAVE])

        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01'), params.id])}"

            redirect(action: "index")
        }

        if (!okSave) {
            println("")
            redirect(action: "index")
        } else if (obsBloodPressureA01Instance.save(flush: true)) {

            if (PortalConstants.CORE_WRITE) {
                try {
                    boolean okInterop = PhrsCommonsService.processResourceInterop(
                            ['instanceName': obsBloodPressureA01Instance,
                                    'className': ObsBloodPressureA01,
                                    'jsonObject': obsBloodPressureA01Instance.encodeAsJSON(),
                                    'classUri': CLASS_URI, 'params': params,
                                    'authenticatedUser': authenticatedUser,
                                    'action': PortalConstants.ACTION_CONTROLLER_SAVE])
                } catch (Exception e) {
                    //println("restPersistObject error" + e.stackTrace)
                    log.error(e)
                }
            }

            flash.message = "${message(code: 'default.created.message', args: [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01'), obsBloodPressureA01Instance.id])}"
            redirect(action: "show", id: obsBloodPressureA01Instance.id)

        } else if (obsBloodPressureA01Instance.errors) {
            obsBloodPressureA01Instance.errors.each {
                log.error(it)
            }
            //edit view does both edit and create
            render(view: "edit", model: [obsBloodPressureA01Instance: obsBloodPressureA01Instance, 'theAction': 'create'])
        }
    }

    def show = {
        def obsBloodPressureA01Instance = ObsBloodPressureA01.get(params.id)


        if (!obsBloodPressureA01Instance) {

            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01'), params.id])}"
            redirect(action: "list")
        }
        else {
            //can pass only resource uri and owner uri, authenticated user id or uri
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': obsBloodPressureA01Instance, 'className': ObsBloodPressureA01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01'), params.id])}"
                println("permission fail")
                redirect(action: "index")
            }
            else [obsBloodPressureA01Instance: obsBloodPressureA01Instance, 'theAction': 'show']
        }
    }

    def edit = {
        def obsBloodPressureA01Instance = ObsBloodPressureA01.get(params.id)
        if (!obsBloodPressureA01Instance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01'), params.id])}"
            redirect(action: "list")
        }
        else {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': obsBloodPressureA01Instance, 'className': ObsBloodPressureA01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01'), params.id])}"
                println("permission fail EDIT")
                redirect(action: "index")
            }
            return [obsBloodPressureA01Instance: obsBloodPressureA01Instance, 'theAction': 'edit']
        }
    }

    def update = {
        def obsBloodPressureA01Instance = ObsBloodPressureA01.get(params.id)

        if (obsBloodPressureA01Instance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': obsBloodPressureA01Instance, 'className': ObsBloodPressureA01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01'), params.id])}"
                println("permission fail UPDATE (EDIT)")
                redirect(action: "index")
            }

            if (params.version) {
                def version = params.version.toLong()
                if (obsBloodPressureA01Instance.version > version) {

                    obsBloodPressureA01Instance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01')] as Object[], "Another user has updated this ObsBloodPressureA01 while you were editing")
                    render(view: "edit", model: [obsBloodPressureA01Instance: obsBloodPressureA01Instance, 'theAction': 'edit'])
                    return
                }
            }
            obsBloodPressureA01Instance.properties = params
            if (!obsBloodPressureA01Instance.hasErrors() && obsBloodPressureA01Instance.save(flush: true)) {


                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01'), obsBloodPressureA01Instance.id])}"
                if (PortalConstants.CORE_WRITE) {
                    try {
                        boolean okInterop = PhrsCommonsService.processResourceInterop(
                                ['instanceName': obsBloodPressureA01Instance,
                                        'className': ObsBloodPressureA01,
                                        'jsonObject': obsBloodPressureA01Instance.encodeAsJSON(),
                                        'classUri': CLASS_URI, 'params': params,
                                        'authenticatedUser': authenticatedUser,
                                        'action': PortalConstants.ACTION_CONTROLLER_SAVE])
                    } catch (Exception e) {
                        //println("restPersistObject error" + e.stackTrace)
                        log.error(e)
                    }
                }
                redirect(action: "show", id: obsBloodPressureA01Instance.id)
            } else {
                render(view: "edit", model: [obsBloodPressureA01Instance: obsBloodPressureA01Instance, 'theAction': 'edit'])
            }
        } else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01'), params.id])}"
        }
        redirect(action: "list")
    }


    def delete = {
        def obsBloodPressureA01Instance = ObsBloodPressureA01.get(params.id)
        if (obsBloodPressureA01Instance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': obsBloodPressureA01Instance, 'className': ObsBloodPressureA01, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_DELETE])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01'), params.id])}"
                println("permission fail DELETE")
                redirect(action: "index")
            }
            try {
                obsBloodPressureA01Instance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        } else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'obsBloodPressureA01.label', default: 'ObsBloodPressureA01'), params.id])}"
            redirect(action: "list")
        }
    }
}

