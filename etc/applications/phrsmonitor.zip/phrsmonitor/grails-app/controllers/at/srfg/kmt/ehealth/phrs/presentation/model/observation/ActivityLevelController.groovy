package at.srfg.kmt.ehealth.phrs.presentation.model.observation


import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants

class ActivityLevelController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
    //matches form model, but we can use from elsewhere
    static final String CLASS_URI = PortalConstants.MODEL_ACTIVITY_LEVEL_CLASS_URI //"at.srfg.kmt.ehealth.phrs.presentation.model.observation.ActivityLevel"
    static final String CLASS_URI_INTEROP = PortalConstants.MODEL_ACTIVITY_LEVEL_CLASS_URI //""1.at.srfg.kmt.ehealth.phrs.presentation.model.observation.ActivityLevel"
    //default unless changed
    User targetUser = authenticatedUser
    String targetUserUri = targetUser?.healthProfileUid

    Map attrMap = [:]
    def PhrsCommonsService //injected service
    def controllerOptionProperties


    def failAuthorization = {
        redirect(action: "goHome", params: params)
    }
    def goHome = {
        redirect(controller: "mainMenu", action: "index", params: params)
    }

    def index = {
        redirect(action: "list", params: params)
    }

    def list = {

        def filterUserUri = params?.filterUserUri ? params.filterUserUri : authenticatedUser?.healthProfileUid ? authenticatedUser.healthProfileUid : null


        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': 'activityLevelInstance', 'className': ActivityLevel, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
        //hack

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        //params.max = Math.min(params.max ? params.int('max') : 10, 100)
        def results
        try {
            def queryString = "from ActivityLevel as m where m._phrsBeanOwnerUri=:owner"
            results = ActivityLevel.findAll(queryString, [owner: filterUserUri])

        } catch (Exception e) {
            log.error(e)
        }
        [activityLevelInstanceList: results, // ActivityLevel.list(params),
                activityLevelInstanceTotal: ActivityLevel.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties]

        // PhrsCommonsService.queryList(
        //    [ 'instanceName':null,'className':ActivityLevel,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
    }

    def listAll = {
        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': 'activityLevelInstance', 'className': ActivityLevel, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [
                activityLevelInstanceList: ActivityLevel.list(params),
                activityLevelInstanceTotal: ActivityLevel.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties
        ]
    }

    def create = {
        def activityLevelInstance = new ActivityLevel()
        activityLevelInstance.properties = params

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': activityLevelInstance, 'className': ActivityLevel, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_CREATE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityLevel.label', default: 'ActivityLevel'), params.id])}"
            println("permission fail CREATE")
            redirect(action: "index")
        }

        //preform afterwards in case of malicious tampering of properties.
        PhrsCommonsService.processResourceInit(
                ['instanceName': activityLevelInstance, 'className': ActivityLevel, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        //edit view does both edit and create
        render(view: "edit", model: [activityLevelInstance: activityLevelInstance, 'theAction': 'create'])
    }

    def save = {
        def activityLevelInstance = new ActivityLevel(params)
        if (PortalConstants.JSON_TEST) {
            def json = activityLevelInstance.encodeAsJSON()
            println("json = " + json)
        }

        //beanInput, classUri, paramsMap, theAuthenticatedUser, attrMap
        boolean okSave = PhrsCommonsService.processResourceToPersist(
                ['instanceName': activityLevelInstance, 'className': ActivityLevel, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': activityLevelInstance, 'className': ActivityLevel, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SAVE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityLevel.label', default: 'ActivityLevel'), params.id])}"
            println("permission fail SAVE")
            redirect(action: "index")
        }
        //permission check.... that sends a message if no permission
        if (!okSave) {
            println("")
            redirect(action: "index")
        }
        else if (activityLevelInstance.save(flush: true)) {

            if (PortalConstants.CORE_WRITE) {
                try {
                    boolean okInterop = PhrsCommonsService.processResourceInterop(
                            ['instanceName': activityLevelInstance,
                                    'className': ActivityLevel,
                                    'jsonObject': activityLevelInstance.encodeAsJSON(),
                                    'classUri': CLASS_URI, 'params': params,
                                    'authenticatedUser': authenticatedUser,
                                    'action': PortalConstants.ACTION_CONTROLLER_SAVE])

                } catch (Exception e) {
                    log.error(e)  //println("restPersistObject error" + e.stackTrace)
                }
            }
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'activityLevel.label', default: 'ActivityLevel'), activityLevelInstance.id])}"
            redirect(action: "show", id: activityLevelInstance.id)
        }
        else if (activityLevelInstance.errors) {
            activityLevelInstance.errors.each {
                log.error(it)
            }
            //edit view does both edit and create
            render(view: "edit", model: [activityLevelInstance: activityLevelInstance, 'theAction': 'create'])
        }
    }

    def show = {
        def activityLevelInstance = ActivityLevel.get(params.id)


        if (!activityLevelInstance) {

            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityLevel.label', default: 'ActivityLevel'), params.id])}"
            redirect(action: "list")
        }
        else {
            //can pass only resource uri and owner uri, authenticated user id or uri
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': activityLevelInstance, 'className': ActivityLevel, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityLevel.label', default: 'ActivityLevel'), params.id])}"
                println("permission fail")
                redirect(action: "index")
            }
            else [activityLevelInstance: activityLevelInstance, 'theAction': 'show']
        }
    }

    def edit = {
        def activityLevelInstance = ActivityLevel.get(params.id)
        if (!activityLevelInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityLevel.label', default: 'ActivityLevel'), params.id])}"
            redirect(action: "list")
        }
        else {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': activityLevelInstance, 'className': ActivityLevel, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityLevel.label', default: 'ActivityLevel'), params.id])}"
                println("permission fail EDIT")
                redirect(action: "index")
            }
            return [activityLevelInstance: activityLevelInstance, 'theAction': 'edit']
        }
    }

    def update = {
        def activityLevelInstance = ActivityLevel.get(params.id)

        if (activityLevelInstance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': activityLevelInstance, 'className': ActivityLevel, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityLevel.label', default: 'ActivityLevel'), params.id])}"
                println("permission fail UPDATE (EDIT)")
                redirect(action: "index")
            }

            if (params.version) {
                def version = params.version.toLong()
                if (activityLevelInstance.version > version) {

                    activityLevelInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'activityLevel.label', default: 'ActivityLevel')] as Object[], "Another user has updated this ActivityLevel while you were editing")
                    render(view: "edit", model: [activityLevelInstance: activityLevelInstance, 'theAction': 'edit'])
                    return
                }
            }
            activityLevelInstance.properties = params
            if (!activityLevelInstance.hasErrors() && activityLevelInstance.save(flush: true)) {

                if (PortalConstants.CORE_WRITE) {
                    try {
                        boolean okInterop = PhrsCommonsService.processResourceInterop(
                                ['instanceName': activityLevelInstance,
                                        'className': ActivityLevel,
                                        'jsonObject': activityLevelInstance.encodeAsJSON(),
                                        'classUri': CLASS_URI, 'params': params,
                                        'authenticatedUser': authenticatedUser,
                                        'action': PortalConstants.ACTION_CONTROLLER_SAVE])

                    } catch (Exception e) {
                        log.error(e)  //println("restPersistObject error" + e.stackTrace)
                    }
                }
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'activityLevel.label', default: 'ActivityLevel'), activityLevelInstance.id])}"
                redirect(action: "show", id: activityLevelInstance.id)
            }
            else {

                render(view: "edit", model: [activityLevelInstance: activityLevelInstance, 'theAction': 'edit'])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityLevel.label', default: 'ActivityLevel'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def activityLevelInstance = ActivityLevel.get(params.id)
        if (activityLevelInstance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': activityLevelInstance, 'className': ActivityLevel, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_DELETE])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityLevel.label', default: 'ActivityLevel'), params.id])}"
                println("permission fail DELETE")
                redirect(action: "index")
            }
            try {
                activityLevelInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'activityLevel.label', default: 'ActivityLevel'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'activityLevel.label', default: 'ActivityLevel'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityLevel.label', default: 'ActivityLevel'), params.id])}"
            redirect(action: "list")
        }
    }
}
