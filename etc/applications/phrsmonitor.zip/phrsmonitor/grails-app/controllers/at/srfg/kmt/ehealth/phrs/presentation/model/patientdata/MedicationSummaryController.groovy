package at.srfg.kmt.ehealth.phrs.presentation.model.patientdata


import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants

class MedicationSummaryController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
    //matches form model, but we can use from elsewhere
    static final String CLASS_URI = PortalConstants.MODEL_MEDICATION_CLASS_URI //"at.srfg.kmt.ehealth.phrs.presentation.model.patientdata.MedicationSummary"
    static final String CLASS_URI_INTEROP = PortalConstants.MODEL_MEDICATION_CLASS_URI  //"1.at.srfg.kmt.ehealth.phrs.presentation.model.patientdata.MedicationSummary"
    //default unless changed
    User targetUser = authenticatedUser
    String targetUserUri = targetUser?.healthProfileUid

    Map attrMap = [:]
    def PhrsCommonsService //injected service
    def controllerOptionProperties


    def failAuthorization = {
        redirect(action: "goHome", params: params)
    }
    def goHome = {
        redirect(controller: "mainMenu", action: "index", params: params)
    }

    def index = {
        redirect(action: "list", params: params)
    }
    def importehr = {
        PhrsCommonsService.importEhrByUser(
                ['instanceName': 'medicationSummaryInstance', 'className': MedicationSummary, 'theAction': 'list', 'classUriInterop': CLASS_URI_INTEROP, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        redirect(action: "list", params: params)
    }
    def list = {
        def filterUserUri = params?.filterUserUri ? params.filterUserUri : authenticatedUser?.healthProfileUid ? authenticatedUser.healthProfileUid : null



        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['viewInstanceName': "medicationSummaryInstance", 'classInstance': MedicationSummary, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
        //hack

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }


        def results
        try {
            def queryString = "from MedicationSummary as m where m._phrsBeanOwnerUri=:owner"
            results = MedicationSummary.findAll(queryString, [owner: filterUserUri])

        } catch (Exception e) {
            log.error(e)
        }
        /* does work, but we replaced use the filterUserUri when someone is monitoring mediations
        PhrsCommonsService.queryList(
                ['instanceName': "medicationSummaryInstance", 'className': MedicationSummary, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])


      //original resused
      params.max = Math.min(params.max ? params.int('max') : 10, 100)
        */
        [medicationSummaryInstanceList: results, //MedicationSummary.list(params),
                medicationSummaryInstanceTotal: MedicationSummary.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties]
    }

    def listAll = {
        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['viewInstanceName': "medicationSummaryInstance", 'classInstance': MedicationSummary, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [
                medicationSummaryInstanceList: MedicationSummary.list(params),
                medicationSummaryInstanceTotal: MedicationSummary.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties
        ]
    }

    def create = {
        def medicationSummaryInstance = new MedicationSummary()
        medicationSummaryInstance.properties = params

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': medicationSummaryInstance, 'className': MedicationSummary, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_CREATE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'medicationSummary.label', default: 'MedicationSummary'), params.id])}"
            println("permission fail CREATE")
            redirect(action: "index")
        }

        //preform afterwards in case of malicious tampering of properties.
        PhrsCommonsService.processResourceInit(
                ['instanceName': medicationSummaryInstance, 'className': MedicationSummary, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        //edit view does both edit and create
        render(view: "edit", model: [medicationSummaryInstance: medicationSummaryInstance, 'theAction': 'create'])
    }

    def save = {
        def medicationSummaryInstance = new MedicationSummary(params)
        if (PortalConstants.JSON_TEST) {
            def json = medicationSummaryInstance.encodeAsJSON()
            println("json = " + json)
        }

        //beanInput, classUri, paramsMap, theAuthenticatedUser, attrMap
        boolean okSave = PhrsCommonsService.processResourceToPersist(
                ['instanceName': medicationSummaryInstance, 'className': MedicationSummary, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': medicationSummaryInstance, 'className': MedicationSummary, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SAVE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'medicationSummary.label', default: 'MedicationSummary'), params.id])}"
            println("permission fail SAVE")
            redirect(action: "index")
        }
        //permission check.... that sends a message if no permission
        if (!okSave) {
            println("")
            redirect(action: "index")
        }
        else if (medicationSummaryInstance.save(flush: true)) {
            if (PortalConstants.CORE_WRITE) {
                try {
                    boolean okInterop = PhrsCommonsService.processResourceInterop(
                            ['instanceName': medicationSummaryInstance,
                                    'className': MedicationSummary,
                                    'jsonObject': medicationSummaryInstance.encodeAsJSON(),
                                    'classUri': CLASS_URI, 'params': params,
                                    'authenticatedUser': authenticatedUser,
                                    'action': PortalConstants.ACTION_CONTROLLER_SAVE])

                } catch (Exception e) {
                    log.error(e)  //println("restPersistObject error" + e.stackTrace)
                }
            }
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'medicationSummary.label', default: 'MedicationSummary'), medicationSummaryInstance.id])}"
            redirect(action: "show", id: medicationSummaryInstance.id)
        }
        else if (medicationSummaryInstance.errors) {
            medicationSummaryInstance.errors.each {
                log.error(it)
            }
            //edit view does both edit and create
            render(view: "edit", model: [medicationSummaryInstance: medicationSummaryInstance, 'theAction': 'create'])
        }
    }

    def show = {
        def medicationSummaryInstance = MedicationSummary.get(params.id)


        if (!medicationSummaryInstance) {

            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'medicationSummary.label', default: 'MedicationSummary'), params.id])}"
            redirect(action: "list")
        }
        else {
            //can pass only resource uri and owner uri, authenticated user id or uri
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': medicationSummaryInstance, 'className': MedicationSummary, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'medicationSummary.label', default: 'MedicationSummary'), params.id])}"
                println("permission fail")
                redirect(action: "index")
            }
            else [medicationSummaryInstance: medicationSummaryInstance, 'theAction': 'show']
        }
    }

    def edit = {
        def medicationSummaryInstance = MedicationSummary.get(params.id)
        if (!medicationSummaryInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'medicationSummary.label', default: 'MedicationSummary'), params.id])}"
            redirect(action: "list")
        }
        else {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': medicationSummaryInstance, 'className': MedicationSummary, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'medicationSummary.label', default: 'MedicationSummary'), params.id])}"
                println("permission fail EDIT")
                redirect(action: "index")
            }
            return [medicationSummaryInstance: medicationSummaryInstance, 'theAction': 'edit']
        }
    }

    def update = {
        def medicationSummaryInstance = MedicationSummary.get(params.id)

        if (medicationSummaryInstance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': medicationSummaryInstance, 'className': MedicationSummary, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'medicationSummary.label', default: 'MedicationSummary'), params.id])}"
                println("permission fail UPDATE (EDIT)")
                redirect(action: "index")
            }

            if (params.version) {
                def version = params.version.toLong()
                if (medicationSummaryInstance.version > version) {

                    medicationSummaryInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'medicationSummary.label', default: 'MedicationSummary')] as Object[], "Another user has updated this MedicationSummary while you were editing")
                    render(view: "edit", model: [medicationSummaryInstance: medicationSummaryInstance, 'theAction': 'edit'])
                    return
                }
            }
            medicationSummaryInstance.properties = params
            if (!medicationSummaryInstance.hasErrors() && medicationSummaryInstance.save(flush: true)) {
                if (PortalConstants.CORE_WRITE) {
                    try {
                        boolean okInterop = PhrsCommonsService.processResourceInterop(
                                ['instanceName': medicationSummaryInstance,
                                        'className': MedicationSummary,
                                        'jsonObject': medicationSummaryInstance.encodeAsJSON(),
                                        'classUri': CLASS_URI, 'params': params,
                                        'authenticatedUser': authenticatedUser,
                                        'action': PortalConstants.ACTION_CONTROLLER_SAVE])

                    } catch (Exception e) {
                        log.error(e)  //println("restPersistObject error" + e.stackTrace)
                    }
                }
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'medicationSummary.label', default: 'MedicationSummary'), medicationSummaryInstance.id])}"
                redirect(action: "show", id: medicationSummaryInstance.id)
            }
            else {

                render(view: "edit", model: [medicationSummaryInstance: medicationSummaryInstance, 'theAction': 'edit'])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'medicationSummary.label', default: 'MedicationSummary'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def medicationSummaryInstance = MedicationSummary.get(params.id)
        if (medicationSummaryInstance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': medicationSummaryInstance, 'className': MedicationSummary, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_DELETE])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'medicationSummary.label', default: 'MedicationSummary'), params.id])}"
                println("permission fail DELETE")
                redirect(action: "index")
            }
            try {
                medicationSummaryInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'medicationSummary.label', default: 'MedicationSummary'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'medicationSummary.label', default: 'MedicationSummary'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'medicationSummary.label', default: 'MedicationSummary'), params.id])}"
            redirect(action: "list")
        }
    }
}
