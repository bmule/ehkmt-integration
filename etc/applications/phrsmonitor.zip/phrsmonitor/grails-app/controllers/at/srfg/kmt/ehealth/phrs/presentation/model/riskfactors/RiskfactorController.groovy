package at.srfg.kmt.ehealth.phrs.presentation.model.riskfactors


import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants

import at.srfg.kmt.ehealth.phrs.presentation.utils.KnLookupSupportService
//import at.srfg.kmt.ehealth.phrs.presentation.utils.RestServices

import at.srfg.kmt.ehealth.phrs.presentation.utils.ViewLabelValue
import at.srfg.kmt.ehealth.phrs.presentation.model.patientdata.MedicationSummary



class RiskfactorController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
    //matches form model, but we can use from elsewhere
    static final String CLASS_URI = PortalConstants.MODEL_RISK_FACTOR_CLASS_URI // "at.srfg.kmt.ehealth.phrs.presentation.model.riskfactors.Riskfactor"
    static final String CLASS_URI_INTEROP = PortalConstants.MODEL_RISK_FACTOR_CLASS_URI // "1.at.srfg.kmt.ehealth.phrs.presentation.model.riskfactors.Riskfactor"
    //default unless changed
    User targetUser = authenticatedUser
    String targetUserUri = targetUser?.healthProfileUid

    Map attrMap = [:]
    def PhrsCommonsService //injected service
    def controllerOptionProperties


    def failAuthorization = {
        redirect(action: "goHome", params: params)
    }
    def goHome = {
        redirect(controller: "mainMenu", action: "index", params: params)
    }

    def index = {
        redirect(action: "list", params: params)
    }
    def importehr = {
        PhrsCommonsService.importEhrByUser(
                ['instanceName': 'riskfactorInstance', 'className': Riskfactor, 'theAction': 'list', 'classUriInterop': CLASS_URI_INTEROP, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        redirect(action: "list", params: params)
    }
    def list = {

        def filterUserUri = params?.filterUserUri ? params.filterUserUri : authenticatedUser?.healthProfileUid ? authenticatedUser.healthProfileUid : null
        //TODO add filterUserUri to Service in all controllers or use filter
        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': 'riskfactorInstance', 'className': Riskfactor, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
        //TODO permissions

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        def results
        try {
            def queryString = "from Riskfactor as m where m._phrsBeanOwnerUri=:owner"
            results = Riskfactor.findAll(queryString, [owner: filterUserUri])

        } catch (Exception e) {
            log.error(e)
        }

        //if (!results) results = Riskfactor.findAllByOwnerUser(authenticatedUser)
        def filterIds = results.collect { res -> res?.riskFactorCode}
        String language = 'en'
        def labelValueList = KnLookupSupportService.lookupUITerminologyList(['tag': PortalConstants.TERM_RISK_FACTOR_OF_TYPE_OVERVIEW_PHRS, 'lang': language])


        def createNewOptions = PhrsCommonsService.filterLabelValueListByIdList(['filterIds': filterIds, 'labelValueList': labelValueList])

        if (!createNewOptions) createNewOptions = []// println("createNewOptions= "+createNewOptions)

        //params.max = Math.min(params.max ? params.int('max') : 10, 100)


        [riskfactorInstanceList: results, //Riskfactor.list(params),
                riskfactorInstanceTotal: Riskfactor.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties, 'selectboxCreateNew': createNewOptions]

        //PhrsCommonsService.queryList(
        //   [ 'instanceName':null,'className':Riskfactor,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
    }

    def listAll = {
        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': 'riskfactorInstance', 'className': Riskfactor, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [
                riskfactorInstanceList: Riskfactor.list(params),
                riskfactorInstanceTotal: Riskfactor.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties
        ]
    }

    def create = {
        def riskfactorInstance = new Riskfactor()
        riskfactorInstance.properties = params

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': riskfactorInstance, 'className': Riskfactor, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_CREATE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'riskfactor.label', default: 'Riskfactor'), params.id])}"

            redirect(action: "index")
        }

        //preform afterwards in case of malicious tampering of properties.
        PhrsCommonsService.processResourceInit(
                ['instanceName': riskfactorInstance, 'className': Riskfactor, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        //edit view does both edit and create
        render(view: "edit", model: [riskfactorInstance: riskfactorInstance, 'theAction': 'create'])
    }

    def save = {

        def riskfactorInstance = new Riskfactor(params)

        //def p=params //ide debugger
        if (PortalConstants.JSON_TEST) {
            def json = riskfactorInstance.encodeAsJSON()
            println("json = " + json)

        }

        //beanInput, classUri, paramsMap, theAuthenticatedUser, attrMap
        boolean okSave = PhrsCommonsService.processResourceToPersist(
                ['instanceName': riskfactorInstance, 'className': Riskfactor, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': riskfactorInstance, 'className': Riskfactor, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SAVE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'riskfactor.label', default: 'Riskfactor'), params.id])}"

            redirect(action: "index")
        }
        //permission check.... that sends a message if no permission
        if (!okSave) {
            println("")
            redirect(action: "index")
        }

        if (riskfactorInstance.save(flush: true)) {
            if (PortalConstants.CORE_WRITE) {
                try {
                    boolean okInterop = PhrsCommonsService.processResourceInterop(
                            ['instanceName': riskfactorInstance,
                                    'className': Riskfactor,
                                    'jsonObject': riskfactorInstance.encodeAsJSON(),
                                    'classUri': CLASS_URI, 'params': params,
                                    'authenticatedUser': authenticatedUser,
                                    'action': PortalConstants.ACTION_CONTROLLER_SAVE])

                } catch (Exception e) {
                    log.error(e)  //println("restPersistObject error" + e.stackTrace)
                }
            }
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'riskfactor.label', default: 'Riskfactor'), riskfactorInstance.id])}"
            redirect(action: "show", id: riskfactorInstance.id)
        }
        else if (riskfactorInstance.errors) {
            riskfactorInstance.errors.each {
                log.error(it)
            }
            //edit view does both edit and create
            render(view: "edit", model: [riskfactorInstance: riskfactorInstance, 'theAction': 'create'])
        }
    }

    def show = {
        def riskfactorInstance = Riskfactor.get(params.id)
        //User filterUser = authenticatedUser

        def filterUserUri = params?.filterUserUri ? params.filterUserUri : authenticatedUser.healthProfileUid ? authenticatedUser.healthProfileUid : null


        if (!riskfactorInstance) {

            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'riskfactor.label', default: 'Riskfactor'), params.id])}"
            redirect(action: "list")
        }
        else {
            //can pass only resource uri and owner uri, authenticated user id or uri
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': riskfactorInstance, 'className': Riskfactor, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'riskfactor.label', default: 'Riskfactor'), params.id])}"
                println("permission fail")
                redirect(action: "index")
            }

            //User authorizedUserId = authenticatedUser?.id ? authenticatedUser.id : null

            // User filterUser = authenticatedUser
            /*
            PortalConstants.MODEL_MEDICATION_CLASS_URI =
            "at.srfg.kmt.ehealth.phrs.datamodel.impl.Medication";
            eq('_phrsBeanClassURI', 'at.srfg.kmt.ehealth.phrs.datamodel.impl.Medication')
                               eq('medicationCode','xx')
                    eq('medicationReasonPrimaryKeywordCode': riskfactorInstance.riskFactorCode)
             */
            /*  try {
                def results1 = MedicationSummary.withCriteria {
                  eq('_phrsBeanClassURI', PortalConstants.MODEL_MEDICATION_CLASS_URI)

                }
            } catch (Exception e) {
                log.error(e)
                println("MedicationSummary withCriteria  " + e)
            }

                            eq("medicationReasonPrimaryKeywordCode": riskfactorInstance.riskFactorCode)
                            eq("_phrsBeanOwnerUri", filterUserUri)
             */
            //separated for future use


            def riskMedications
            // def med2
            if (filterUserUri) {
                /*
                def theCriteria = MedicationSummary.createCriteria()
                try {
                med2 = theCriteria.list {
                    and {
                        eq('_phrsBeanOwnerUri', filterUserUri)
                        eq('medicationReasonPrimaryKeywordCode': riskfactorInstance.riskFactorCode)
                    }

                }
                    //order("_phrsBeanCreateDate", "desc")
                } catch (Exception e) {
                    log.error(e)
                } */

                try {
                    def queryString = "from MedicationSummary as m where m.medicationReasonPrimaryKeywordCode=:riskcode and  m._phrsBeanOwnerUri=:owner"
                    riskMedications = MedicationSummary.findAll(queryString, [riskcode: riskfactorInstance.riskFactorCode, owner: filterUserUri])

                    //[riskcode: riskfactorInstance.riskFactorCode, owner:filterUserUri]  '${riskfactorInstance.riskFactorCode}', owner:'${filterUserUri}'])
                } catch (Exception e) {
                    log.error(e)
                }
                /*
                '_phrsBeanClassURI': PortalConstants.MODEL_MEDICATION_CLASS_URI,



                def theCriteria = MedicationSummary.createCriteria()


                med2 = theCriteria.list {
                    and {
                        eq('_phrsBeanClassURI', PortalConstants.MODEL_MEDICATION_CLASS_URI)
                        eq('medicationReasonPrimaryKeywordCode': riskfactorInstance.riskFactorCode)
                    }
                    //            maxResults(10)
                    order("_phrsBeanCreateDate", "desc")
                }

                    riskMedications = MedicationSummary.findAll(
                            (PortalConstants.Model_PROPERTY_OWNER_URI): filterUserUri,
                            medicationReasonPrimaryKeywordCode: riskfactorInstance.riskFactorCode,
                            [ sort: PortalConstants.Model_PROPERTY_CREATE_DATE, order: "desc", offset: 20])
                }*/

                //println("riskMedications " + riskMedications)
            }

            if (!riskMedications) riskMedications = []

            return [riskfactorInstance: riskfactorInstance, 'theAction': 'show', 'medicationSummaryInstanceList': riskMedications]
        }
    }

    def edit = {
        def riskfactorInstance = Riskfactor.get(params.id)
        if (!riskfactorInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'riskfactor.label', default: 'Riskfactor'), params.id])}"
            redirect(action: "list")
        }
        else {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': riskfactorInstance, 'className': Riskfactor, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'riskfactor.label', default: 'Riskfactor'), params.id])}"
                println("permission fail EDIT")
                redirect(action: "index")
            }
            return [riskfactorInstance: riskfactorInstance, 'theAction': 'edit']
        }
    }

    def update = {
        def riskfactorInstance = Riskfactor.get(params.id)

        if (riskfactorInstance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': riskfactorInstance, 'className': Riskfactor, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'riskfactor.label', default: 'Riskfactor'), params.id])}"
                println("permission fail UPDATE (EDIT)")
                redirect(action: "index")
            }

            if (params.version) {
                def version = params.version.toLong()
                if (riskfactorInstance.version > version) {

                    riskfactorInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'riskfactor.label', default: 'Riskfactor')] as Object[], "Another user has updated this Riskfactor while you were editing")
                    render(view: "edit", model: [riskfactorInstance: riskfactorInstance, 'theAction': 'edit'])
                    return
                }
            }
            riskfactorInstance.properties = params
            if (!riskfactorInstance.hasErrors() && riskfactorInstance.save(flush: true)) {

                if (PortalConstants.CORE_WRITE) {
                    try {
                        boolean okInterop = PhrsCommonsService.processResourceInterop(
                                ['instanceName': riskfactorInstance,
                                        'className': Riskfactor,
                                        'jsonObject': riskfactorInstance.encodeAsJSON(),
                                        'classUri': CLASS_URI, 'params': params,
                                        'authenticatedUser': authenticatedUser,
                                        'action': PortalConstants.ACTION_CONTROLLER_SAVE])

                    } catch (Exception e) {
                        log.error(e)  //println("restPersistObject error" + e.stackTrace)
                    }
                }
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'riskfactor.label', default: 'Riskfactor'), riskfactorInstance.id])}"
                redirect(action: "show", id: riskfactorInstance.id)
            }
            else {

                render(view: "edit", model: [riskfactorInstance: riskfactorInstance, 'theAction': 'edit'])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'riskfactor.label', default: 'Riskfactor'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def riskfactorInstance = Riskfactor.get(params.id)
        if (riskfactorInstance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': riskfactorInstance, 'className': Riskfactor, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_DELETE])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'riskfactor.label', default: 'Riskfactor'), params.id])}"
                println("permission fail DELETE")
                redirect(action: "index")
            }
            try {
                riskfactorInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'riskfactor.label', default: 'Riskfactor'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'riskfactor.label', default: 'Riskfactor'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'riskfactor.label', default: 'Riskfactor'), params.id])}"
            redirect(action: "list")
        }
    }
}
