package at.srfg.kmt.ehealth.phrs.presentation.model.observation


import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants

class ActivityItemController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
    //matches form model, but we can use from elsewhere
    static final String CLASS_URI = PortalConstants.MODEL_ACTIVITY_ITEM_CLASS_URI //"at.srfg.kmt.ehealth.phrs.presentation.model.observation.ActivityItem"
    static final String CLASS_URI_INTEROP = PortalConstants.MODEL_ACTIVITY_ITEM_CLASS_URI //"1.at.srfg.kmt.ehealth.phrs.presentation.model.observation.ActivityItem"
    //default unless changed
    User targetUser = authenticatedUser
    String targetUserUri = targetUser?.healthProfileUid

    Map attrMap = [:]
    def PhrsCommonsService //injected service
    def controllerOptionProperties


    def failAuthorization = {
        redirect(action: "goHome", params: params)
    }
    def goHome = {
        redirect(controller: "mainMenu", action: "index", params: params)
    }

    def index = {
        redirect(action: "list", params: params)
    }
    def importehr = {
        PhrsCommonsService.importEhrByUser(
                ['instanceName': 'activityItemInstance', 'className': ActivityItem, 'theAction': 'list', 'classUriInterop': CLASS_URI_INTEROP, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        redirect(action: "list", params: params)
    }
    def list = {

        def filterUserUri = params?.filterUserUri ? params.filterUserUri : authenticatedUser?.healthProfileUid ? authenticatedUser.healthProfileUid : null



        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': 'activityItemInstance', 'className': ActivityItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
        //hack

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        //params.max = Math.min(params.max ? params.int('max') : 10, 100)
        def results
        try {
            def queryString = "from ActivityItem as m where m._phrsBeanOwnerUri=:owner"
            results = ActivityItem.findAll(queryString, [owner: filterUserUri])

        } catch (Exception e) {
            log.error(e)
        }

        [activityItemInstanceList: results, //ActivityItem.list(params),
                activityItemInstanceTotal: ActivityItem.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties]

        //PhrsCommonsService.queryList(
        //   [ 'instanceName':null,'className':ActivityItem,'classUri':CLASS_URI,'params':params,'authenticatedUser':authenticatedUser,'action':PortalConstants.ACTION_CONTROLLER_SHOW])
    }

    def listAll = {
        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': 'activityItemInstance', 'className': ActivityItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])

        if (!okPermission) {
            redirect(action: "failAuthorization", params: params)
        }

        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [
                activityItemInstanceList: ActivityItem.list(params),
                activityItemInstanceTotal: ActivityItem.count(),
                'theAction': 'list',
                'visualizationAttributes': PhrsCommonsService.visualizationAttributes(['classUri': CLASS_URI]),
                'controllerOptionProperties': controllerOptionProperties
        ]
    }

    def create = {
        def activityItemInstance = new ActivityItem()
        activityItemInstance.properties = params

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': activityItemInstance, 'className': ActivityItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_CREATE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityItem.label', default: 'ActivityItem'), params.id])}"
            println("permission fail CREATE")
            redirect(action: "index")
        }

        //preform afterwards in case of malicious tampering of properties.
        PhrsCommonsService.processResourceInit(
                ['instanceName': activityItemInstance, 'className': ActivityItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        //edit view does both edit and create
        render(view: "edit", model: [activityItemInstance: activityItemInstance, 'theAction': 'create'])
    }

    def save = {
        def activityItemInstance = new ActivityItem(params)

        if (PortalConstants.JSON_TEST) {
            def json = activityItemInstance.encodeAsJSON()
            println("json = " + json)
        }

        //beanInput, classUri, paramsMap, theAuthenticatedUser, attrMap
        boolean okSave = PhrsCommonsService.processResourceToPersist(
                ['instanceName': activityItemInstance, 'className': ActivityItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'attrMap': attrMap])

        boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                ['instanceName': activityItemInstance, 'className': ActivityItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SAVE])
        if (!okPermission) {
            //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityItem.label', default: 'ActivityItem'), params.id])}"
            println("permission fail SAVE")
            redirect(action: "index")
        }
        //permission check.... that sends a message if no permission
        if (!okSave) {
            println("")
            redirect(action: "index")
        }
        else if (activityItemInstance.save(flush: true)) {
            if (PortalConstants.CORE_WRITE) {
                try {
                    boolean okInterop = PhrsCommonsService.processResourceInterop(
                            ['instanceName': activityItemInstance,
                                    'className': ActivityItem,
                                    'jsonObject': activityItemInstance.encodeAsJSON(),
                                    'classUri': CLASS_URI, 'params': params,
                                    'authenticatedUser': authenticatedUser,
                                    'action': PortalConstants.ACTION_CONTROLLER_SAVE])

                } catch (Exception e) {
                    log.error(e)  //println("restPersistObject error" + e.stackTrace)
                }
            }
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'activityItem.label', default: 'ActivityItem'), activityItemInstance.id])}"
            redirect(action: "show", id: activityItemInstance.id)
        }
        else if (activityItemInstance.errors) {
            activityItemInstance.errors.each {
                log.error(it)
            }
            //edit view does both edit and create
            render(view: "edit", model: [activityItemInstance: activityItemInstance, 'theAction': 'create'])
        }
    }

    def show = {
        def activityItemInstance = ActivityItem.get(params.id)


        if (!activityItemInstance) {

            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityItem.label', default: 'ActivityItem'), params.id])}"
            redirect(action: "list")
        }
        else {
            //can pass only resource uri and owner uri, authenticated user id or uri
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': activityItemInstance, 'className': ActivityItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_SHOW])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityItem.label', default: 'ActivityItem'), params.id])}"
                println("permission fail")
                redirect(action: "index")
            }
            else [activityItemInstance: activityItemInstance, 'theAction': 'show']
        }
    }

    def edit = {
        def activityItemInstance = ActivityItem.get(params.id)
        if (!activityItemInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityItem.label', default: 'ActivityItem'), params.id])}"
            redirect(action: "list")
        }
        else {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': activityItemInstance, 'className': ActivityItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityItem.label', default: 'ActivityItem'), params.id])}"
                println("permission fail EDIT")
                redirect(action: "index")
            }
            return [activityItemInstance: activityItemInstance, 'theAction': 'edit']
        }
    }

    def update = {
        def activityItemInstance = ActivityItem.get(params.id)

        if (activityItemInstance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': activityItemInstance, 'className': ActivityItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_EDIT])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityItem.label', default: 'ActivityItem'), params.id])}"
                println("permission fail UPDATE (EDIT)")
                redirect(action: "index")
            }

            if (params.version) {
                def version = params.version.toLong()
                if (activityItemInstance.version > version) {

                    activityItemInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'activityItem.label', default: 'ActivityItem')] as Object[], "Another user has updated this ActivityItem while you were editing")
                    render(view: "edit", model: [activityItemInstance: activityItemInstance, 'theAction': 'edit'])
                    return
                }
            }
            activityItemInstance.properties = params
            if (!activityItemInstance.hasErrors() && activityItemInstance.save(flush: true)) {

                if (PortalConstants.CORE_WRITE) {
                    try {
                        boolean okInterop = PhrsCommonsService.processResourceInterop(
                                ['instanceName': activityItemInstance,
                                        'className': ActivityItem,
                                        'jsonObject': activityItemInstance.encodeAsJSON(),
                                        'classUri': CLASS_URI, 'params': params,
                                        'authenticatedUser': authenticatedUser,
                                        'action': PortalConstants.ACTION_CONTROLLER_SAVE])

                    } catch (Exception e) {
                        log.error(e)  //println("restPersistObject error" + e.stackTrace)
                    }
                }
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'activityItem.label', default: 'ActivityItem'), activityItemInstance.id])}"
                redirect(action: "show", id: activityItemInstance.id)
            }
            else {

                render(view: "edit", model: [activityItemInstance: activityItemInstance, 'theAction': 'edit'])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityItem.label', default: 'ActivityItem'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def activityItemInstance = ActivityItem.get(params.id)
        if (activityItemInstance) {
            boolean okPermission = PhrsCommonsService.processResourceAuthorization(
                    ['instanceName': activityItemInstance, 'className': ActivityItem, 'classUri': CLASS_URI, 'params': params, 'authenticatedUser': authenticatedUser, 'action': PortalConstants.ACTION_CONTROLLER_DELETE])
            if (!okPermission) {
                //flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityItem.label', default: 'ActivityItem'), params.id])}"
                println("permission fail DELETE")
                redirect(action: "index")
            }
            try {
                activityItemInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'activityItem.label', default: 'ActivityItem'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'activityItem.label', default: 'ActivityItem'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'activityItem.label', default: 'ActivityItem'), params.id])}"
            redirect(action: "list")
        }
    }
}
