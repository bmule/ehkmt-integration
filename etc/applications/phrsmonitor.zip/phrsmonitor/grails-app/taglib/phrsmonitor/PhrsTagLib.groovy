package phrsmonitor

import org.apache.commons.beanutils.DynaBean

import org.apache.commons.beanutils.DynaProperty
import at.srfg.kmt.ehealth.phrs.presentation.utils.KnLookupSupportService
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants

/**
 * Experimental Tag library for processing some dynamic beans
 TODO review and revise - smaller units for use in alternative groovy base systems
 */
class PhrsTagLib {

    //namespace for tag phrs:processDbean
    static namespace = 'phrs' //Does not work with constant, must write string phrs : DefaultPhrBeanPropertiesFactory.NS
    static boolean TEST_OUTPUT_VISIBLE = true

    //def out

    //future have lookup for type and property to get inspector results
    //see map inspector code, read xml with slurper

    private Map getSelectBoxProperties(String type) {
        ['propSB1': 'lookup type', 'propSB2': 'xxx']
    }

    private Map getCheckBoxProperties(String type) {
        ['propCB1': 'lookup type', 'propCB2': 'xxx']
    }

    private Map getRadioBoxProperties(String type) {
        ['propRB1': 'lookup type', 'propRB2': 'xxx']
    }

    private Map getTextProperties(String type) {
        ['propTx1': 'lookup type', 'propTx2': 'xxx']
    }

    //TODO message code to property name

    def testme = { attrs, body ->
        def someProp = attrs.key1

        //println("test ...reachable code someProp=" + someProp)
        out << "output to browser...reachable code someProp=" + someProp
    }

    String testLookuplabel(String termCode, String label) {

        def attrs = [term: termCode, label: label]
        def out = testLookup(attrs)
        return out
    }

    String testLookuplabel(String termCode) {
        def attrs = [term: termCode]
        def out = testLookup(attrs)
        return out
    }
    /**
     * For unit tests, cannot pass body
     * No body attribute
     */
    def testLookup = { attrs ->
        def defaultLabel = attrs?.label ? attrs.label : null
        //def property = attrs?.property ? attrs.property : null
        def termCode = attrs?.term ? attrs.term : null
        /* <g:if test="${riskfactorInstance?.treatmentStatementPrimary}">
            <g:set var="termLabel" value="${KnLookupSupportService.lookupTerminologyLabelValue(['term':riskfactorInstance.treatmentStatementPrimary,'defaultLabel':'..'])}"/>
            ${termLabel}
           </g:if> */
        def label = null
        if (termCode) {
            def labelValue = KnLookupSupportService.lookupTerminologyLabelValue(['term': termCode, 'defaultLabel': '..'])
            label = labelValue?.value ? labelValue.value : null
        }

        label = label ? label : defaultLabel ? defaultLabel : ""

        return label
    }
    /**
     * lookuplabel
     <phrs:lookuplabel term="${XXX_term_code}" lang="" label="" />
     * requires: term
     * optional label  default label if lookup fails
     * returns label from vocabulary lookup
     *
     * TODO alternative:
     * property
     * validate true
     */

    def lookuplabel = { attrs, body ->
        def defaultLabel = attrs?.label ? attrs.label : null
        //def property = attrs?.property ? attrs.property : null
        //def validate = attrs?.validate ? attrs.validate : false
        def termCode = attrs?.term ? attrs.term : null
        def lang = attrs?.lang ? attrs.lang : 'en'

        //def ok= validate && !property ? false : true
        def label = null
        if (termCode) {
            def labelValue = KnLookupSupportService.lookupTerminologyLabelValue(['term': termCode, 'defaultLabel': '..'])
            label = labelValue?.value ? labelValue.value : null
        }

        label = label ? label : defaultLabel ? defaultLabel : ""

        out << label
    }
    /**
     *  source= _phrsBeanRefersToSourceUri    creatorProperty=_phrsBeanCreatorUri
     *
     <phrs:showehr  sourceProperty="${XXX}" />  optional param id="${xx.id}" but we take it from resource
     <phrs:showehr  sourceProperty="${XXX._phrsBeanRefersToSourceUri}"   creatorProperty="${XXX._phrsBeanCreatorUri}" />

     */

    /*
    EHR_SOURCE_INDICATOR = "ehr";
    EHR_SOURCE_INDICATOR_PROPERTY_SOURCE = "_phrsBeanRefersToSourceUri";
    EHR_SOURCE_INDICATOR_PROPERTY_CREATOR = "_phrsBeanCreatorUri";
     */
    def showehr = { attrs, body ->
        def theId
        def label = ""
        try {
            theId = attrs?.id ? attrs.id : null
            def theResourceId = attrs?.resource?.id ? attrs.resource.id : null
            theId = theResourceId ? theResourceId : theId

        } catch (Exception e) {
            println("showehr " + e)
        }
        try {
            if (theId) {

                def ehrProp1 = attrs?.resource?._phrsBeanRefersToSourceUri ? attrs.resource._phrsBeanRefersToSourceUri : attrs?.sourceProperty ? attrs.sourceProperty : null
                def ehrProp2 = attrs?.resource?._phrsBeanCreatorUri ? attrs.resource._phrsBeanCreatorUri : attrs?.creatorProperty ? attrs.creatorProperty : null


                def ok = ehrProp1 && ehrProp1.startsWith(PortalConstants.EHR_SOURCE_INDICATOR_PROPERTY_SOURCE) ? true :
                    ehrProp2 && ehrProp2.startsWith(PortalConstants.EHR_SOURCE_INDICATOR_PROPERTY_CREATOR) ? true : false

                label = "" //"""<span title=\"User defined data\">${theId}</span>"
                if (ok) {
                    label = "<span title=\"Received from a Electronic Health System\" color=\"red\">EHR </span></br/>" //${theId}
                }
            } else {
                theId = ""
            }
        } catch (Exception e) {
            println("showehr " + e)
        }
        out << label
    }
    /*
    def processDynamicBean = { attrs, body ->

        processDbean(attrs, body)


    }*/

    def processDbean = { attrs, body ->
        //println("processDbean 1")
        DynaBean dbean = attrs.dbean    //have object dbean, not json

        String type = null //dbean.get(PhrPropertyUtil.buildName(DefaultPhrBeanPropertiesFactory.NS, PhrBeanConstants.TYPES));

        Map checkProps = getSelectBoxProperties()
        Map radioProps = getSelectBoxProperties()
        Map selectProps = getSelectBoxProperties()

        //println("processDbean 2")
        DynaProperty[] dynaProperties = dbean.getDynaClass().getDynaProperties();

        //println("processDbean 3")

        for (DynaProperty dynaProperty: dynaProperties) {

            //must loop through instances!! INNER loop though Dynabean based on this property
//g.render(template:"someTemplate", name:"peter")

            String name = dynaProperty.getName()
            String lowerCaseName = name.toLowerCase()
            //println("name=" + name + " lower=" + lowerCaseName)
            //println("CHECK ME NS =" + DefaultPhrBeanPropertiesFactory.NS)


            String enricherWidgetType = getEnricherForPresentationWidgetType(name, dbean)

            //determine if field repeats eg.  a collection (set, list, map)

            //widget type should handle collections and repeat the field e.g. checkbox group
            switch (enricherWidgetType) {
            //check control type, select checkbox
                case enricherWidgetType.contains("select"):
                    println("select"); break
            //group or single select? depends on fields and enricher...
            //formWidgetSelectionGroupA01
            //out << render(template: "/shared/formWidgetSelectionGroupA01", model: [theTypes: 'default', theFormProperty: name, thePropertyValue: dbean.get(name), theLabelCode: name, flagDatePicker: false, precision: 'day'])
                case enricherWidgetType.contains("radiogroup"):
                    println("radiogroup"); break
                case enricherWidgetType.contains("radio"):
                    println("radio"); break

                default:  //no matches above, now look at java type
                    println("default reached, call next strategy")
                    //use another strategy and do any field repeating where necessary for collections
                    boolean foundWidget = defaultEnrichmentStrategy(dynaProperty)

            }


        }


    }

    boolean defaultCollectionPropertyProcess(String name) {

    }
    /**
     * Check field naming e.g. all phrs__ fields are hidden
     *
     * @param fieldName
     * @return
     */
    boolean defaultEnrichmentByFieldNamingClues(DynaProperty dynaProperty) {
        if (dynaProperty != null && dynaProperty?.getName() != null) {
            return defaultEnrichmentByFieldNamingClues(dynaProperty.getName())
        }

        return false
    }

    int getRepeatedFieldCount(String property, DynaBean bean) {
        int count = 1

        if (property.contains("_phrsBeanClassURI")) {

            try {
                Set set = (Set) bean.get("_phrsBeanClassURI")
                count = (set) ? set?.size() : 1


            } catch (Exception e) {
                println("casting exception on " + property)
            }

        }


        if (property) {

        }

        return count;

    }

    boolean defaultEnrichmentByFieldNamingClues(String fieldName, DynaBean dbean) {

        if (fieldName == null) return false

        String name = fieldName

        String lowerCaseName = name.toLowerCase()

        boolean fieldOutputed = false
        int fieldRepeater = getRepeatedFieldCount(name, dbean)

        for (fieldCount in 0..fieldRepeater) {

            //hidden fields
            if (lowerCaseName.startsWith(
                    DefaultPhrBeanPropertiesFactory.NS + "_")   //just one "_" is needed in case it changes back from "__" to "_"
                    || lowerCaseName.endsWith("id")
                    || lowerCaseName.endsWith("uri")
                    || lowerCaseName.contains("login")
                    || lowerCaseName.contains("userid")
            ) {
                //render hidden; check type, if List then iterate over list
                //formWidgetHiddenFieldA01
                //out << render (template="formWidgetHiddenFieldA01", model=[ theFormProperty:name, thePropertyValue:dbean.get(name) ] )
                //formWidgetHiddenFieldA01
                if (TEST_OUTPUT_VISIBLE) {
                    out << render(template: "/shared/formWidgetTextFieldA01", model: [theFormProperty: name, thePropertyValue: dbean.get(name)])
                } else {
                    out << render(template: "/shared/formWidgetTextFieldA01", model: [theFormProperty: name, thePropertyValue: dbean.get(name)])

                }


                fieldOutputed = true
            }

            if (lowerCaseName.contains("date")) {
                out << render(template: "/shared/formWidgetDateA01", model: [theFormProperty: name, thePropertyValue: dbean.get(name),
                        'flagDatePicker': false, 'precision': 'day'])

                return true
            }

            if (lowerCaseName.contains("comment")
                    || lowerCaseName.contains("description")
                    || lowerCaseName.contains("abstract")
                    || lowerCaseName.contains("serialized")
                    || lowerCaseName.contains("data")    //test
            ) {
                //formWidgetTextAreaA01
                //out << render(template: "/shared/formWidgetTextAreaA01", model: [theFormProperty: name, thePropertyValue: dbean.get(name)])

                fieldOutputed = true
            }

            //first test for phr__ and make hidden, check property inspector later for more. ignore date check for hidden stuff.

            //check for "Date" in property name and make date
            //check for boolean and make either checkbox or radio.
            //
            //check which property requires a selectbox lookup

            //Issue for instances... eg property is repeated because it is a list, option group

        }

        return fieldOutputed

    }

    boolean defaultEnrichmentStrategy(DynaProperty dynaProperty) {

        switch (dynaProperty.getType()) {

            case java.util.Date.class:
                println("Date")
                out << render(template: "/shared/formWidgetDateA01", model: [theFormProperty: name, thePropertyValue: dbean.get(name), 'flagDatePicker': false, 'precision': 'day']); break
            case java.lang.Boolean:
                println("Boolean")
        //  checkbox or radio; break; break;; break
            case (java.util.Integer.class || java.util.Float.class): //
                println("Integer or Float"); break
            default:
                println("default as String")
        //out << render(template:"/shared/formWidgetTextFieldA01",model: [theFormProperty: name, thePropertyValue: dbean.get(name), theLabelCode: name]);
        }
        return true

    }

    String getEnricherForPresentationWidgetType(String propertyName, DynaBean dynabean) {

        return "default"
    }

    String getEnricherSemanticAnnotation(String propertyName, DynaBean dynaBean) {

        return "default"
    }
    /*
 def tinyThumbnail = { attrs ->
     def userId = attrs.userId
     out << "<img src='"
     out << g.createLink(action: "tiny", controller: "image", id: userId)
     out << "' alt='${userId}'"
 }   */

    /*


   static namespace = 'zing'

       def include = { attrs ->
           def jsPath = "${resource(dir:'zingchart', file:'zingchart-1.1.min.js')}"
           def ret = "<script type=\"text/javascript\" src=\"${jsPath}\"></script>"
           out << ret
       }

       def chart = { attrs ->
           def type = attrs.type
           def libURL = "${resource(dir:'zingchart', file:'zingchart.swf')}"
           def width = attrs.width ? attrs.width.toInteger() : 300
           def height = attrs.height ? attrs.height.toInteger() : 200
           def container = attrs.container ?: 'myChart'
           def xLabels = attrs.xLabels ?: null
           def yLabels = attrs.yLabels ?: null
           def data = attrs.data ?: [:]
           def duration = attrs.duration ? attrs.duration.toFloat() : 1.1F
           def effect = attrs.effect ? attrs.effect.toInteger() : 1

           zingchart.Chart chart = new zingchart.Chart(type, libURL.toString(), width, height, container, duration, effect)
           if (xLabels) {
               chart.setHorizontalLabels(xLabels)
           }
       if (yLabels) {
           chart.setVerticalLabels(yLabels)
       }
           data.each { k, v ->
               chart.addDataSet(v, k)
           }
           out << chart.toHTML()
       }
    */
}
