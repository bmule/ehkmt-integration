package phrsmonitor

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties
import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User

class TestStuff {

    String name
    Date hideDate = new Date()
    Date observationDate
    Date observationDateDefault = new Date()
    User ownerUser
    static belongsTo = {ownerUser:User}

    static constraints = {

        hideDate(nullable:true, display:false)
        observationDate(nullable:true)
        observationDateDefault(nullable:false)
        name(blank:false,minSize: 2)
    }
}
