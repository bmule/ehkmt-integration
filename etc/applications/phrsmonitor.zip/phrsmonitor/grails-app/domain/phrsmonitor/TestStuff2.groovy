package phrsmonitor

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties

class TestStuff2 extends CommonFormProperties{
    String name2
    Boolean isActiveStatus = Boolean.TRUE

    Map test

    static constraints = {
        name2(nullable:true)
        isActiveStatus(nullable:true)
        test(nullable:true)
    }
}
