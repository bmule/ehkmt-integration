package at.srfg.kmt.ehealth.phrs.presentation.model.riskfactors

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties

/**
 * A riskfactor
 */
class Riskfactor extends CommonFormProperties {
    String riskFactorType  //grouping of risk factor codes
    String riskFactorCode //codes like cholesterol, hypertension, etc
    Boolean isActiveStatus = Boolean.TRUE

    String riskFactorDuration //how long smoke, how long, diabetes, how lo


    Boolean hasContributingFactors = Boolean.FALSE
    Set<String> contributingFactorCodes = new HashSet<String>()

    Map<String,String> riskFactorAttributes = new HashMap<String, String>()


    Boolean isTreated = Boolean.TRUE   //is treated? yes, then what are treatment codes? Smoking is not treated in this case

    Set<String> treatmentStatmentCodes = new HashSet<String>()
    String treatmentStatementPrimary


   // Map<String, String> otherRiskData = new HashMap<String, String>()

    Date observationDateStart = new Date()
    Date observationDateEnd

    String comment

    //static belongsTo = [riskfactorSummary:RiskfactorSummary]
    //no ...static hasMany = [riskfactors:RiskfactorSummary]
    static hasMany = [contributingFactorCodes: String, treatmentStatmentCodes: String]


    static constraints = {
        riskFactorType(nullable:true)

        riskFactorCode(nullable: false,blank:false)
       //riskFactorType(inList: ['Diabetes', 'Cholesterol', 'Hypertension', 'IncreasedWeight', 'Smoking'])
        isActiveStatus(nullable: true)//only for smoking,assume true for any existing
        hasContributingFactors(nullable: true)
        riskFactorDuration(nullable: true)

        riskFactorDuration(nullable:true)
        //contributing history e.g. smoking materials, etc
        contributingFactorCodes(nullable: true)
        riskFactorAttributes(nullable:true)

        //can set for smoking...or others
        isTreated(nullable:true)
        treatmentStatmentCodes(nullable: true)
        treatmentStatementPrimary(nullable:true,blank:true)
        //treatmentStatmentCodes(nullable: true,inList:['medication','diet','exercise','none'])

       // otherRiskData(nullable: true)

        observationDateStart(nullable: true)
        observationDateEnd(nullable: true)

        //data()
        comment(nullable:true,maxSize: 10000)
    }
}
