package at.srfg.kmt.ehealth.phrs.presentation.model.observation

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties

class ObsBloodPressureA01 extends CommonFormProperties {

    Integer bpSystolic
    Integer bpDiastolic
    Integer bpHeartRate
    Date observationDate = new Date()

    String comment

    static constraints = {
        bpSystolic(min:40, max:400)
        bpDiastolic(min:40, max:400)
        bpHeartRate(nullable: true)
        observationDate(nullable: false)
        comment(nullable:true,maxSize: 10000) //not string

    }
     // mmHg
    String toString() {

        "${bpSystolic}/${bpDiastolic}"
    }
}
