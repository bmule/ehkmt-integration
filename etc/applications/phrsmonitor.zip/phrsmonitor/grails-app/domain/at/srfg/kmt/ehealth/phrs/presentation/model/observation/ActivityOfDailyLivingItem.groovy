package at.srfg.kmt.ehealth.phrs.presentation.model.observation

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties

/**
 * 1. Physical activities
 * 2. General Activities
 * etc
 *
 */
class ActivityOfDailyLivingItem extends CommonFormProperties {

    //String activityCategory //physical activity, general activities
    String activityCategory
    String activityCode
    //String activityValue

    //Long valueBitFlag = 0
    String valueActivity //radio button, one choice

    // we can deprecated these two if replaced by valueActivity. The single or combination could mean a particular snomed code?

    Boolean isActivityUnassisted =Boolean.TRUE //checkbox
    Boolean isActivityAssisted =Boolean.FALSE
    //other possibilities besides the common assisted, unassisted
    Map<String,String> activityFeature = new HashMap<String,String>()

    //by default, no durationCode, but possible.
    String activityDurationCode
    String score

    static constraints = {
        activityCategory(nullable:true,display:false)
        //activityCategory() //physical activity, general activities
        activityCode(blank:false,nullable:false)
        //activityCode(blank:false,inList:[
        //        'Bathing','Carry shopping bags','Climbing Stairs','Driving','Gardening','House work','Use Activity Name'])

        isActivityUnassisted(nullable:true)
        isActivityAssisted(nullable:true)

        activityDurationCode(nullable:true,blank:true)
        activityFeature(nullable:true)

        valueActivity(display:true,nullable:true) //widget:'radio'
        score(nullable:true)

    }
}
