package at.srfg.kmt.ehealth.phrs.presentation.model.patienteducation

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties

class PatientEducationDashboard {

    Map<String, String> contentReferences = new HashMap<String, String>()
    Map<String, String> rssFeeds = new HashMap<String, String>()


    static constraints = {
        contentReferences(nullable:true)
        rssFeeds(nullable:true)
    }
}
