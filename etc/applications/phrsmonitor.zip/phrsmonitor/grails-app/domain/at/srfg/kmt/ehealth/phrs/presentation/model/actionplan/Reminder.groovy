package at.srfg.kmt.ehealth.phrs.presentation.model.actionplan

class Reminder {

  //ReminderType reminderType
  String reminderType
  Integer duration

  static belongsTo = [event:Event]

  static constraints = {
         reminderType(inList: ['sms','email'])
  }

  String toString() {

    "${reminderType} : ${duration}"
  }
}
