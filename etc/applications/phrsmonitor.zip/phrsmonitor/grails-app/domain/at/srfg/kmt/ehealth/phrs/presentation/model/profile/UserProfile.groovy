package at.srfg.kmt.ehealth.phrs.presentation.model.profile

class UserProfile extends grails.plugins.nimble.core.ProfileBase {

    // ProfileBase belongsTo UserBase
    /*
    String firstName
    String lastName
    String addressLine1
    String addressLine2
    String zipCode
    String city
    String country

    String telephoneMobile
    String telephoneLand

    static constraints = {
        firstName()
        lastName(nullable: true)
        addressLine1(nullable: true)
        addressLine2(nullable: true)
        zipCode(nullable: true)
        city(nullable: true)
        country(nullable: true)

        telephoneMobile(nullable: true)
        telephoneLand(nullable: true)
    }
    */
    /*
   <g:countrySelect name="user.country" value="${country}"
           noSelection="['':'-Choose your age-']"/>

           valueMessagePrefix="countryname"
           ISO3166_3 country code
           internationalized versions of the country names, you must define these in your message bundles and use the
           <g:message>
 // create country select with internationalized labels
 // expected properties in messages.properties:
 // countryname.gbr=My United Kingdom
 // countryname.usa=Home of the brave
 // countryname.deu=Germany

    */
}
