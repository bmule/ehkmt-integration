package at.srfg.kmt.ehealth.phrs.presentation.model.profile

//import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties
import at.srfg.kmt.ehealth.phrs.presentation.model.profile.systems.HealthcareSystem

// extends CommonFormProperties
class HealthProfileIndividual {

    //this UUID can be reassigned to the application login "User" , it might be mapped to a portal's User UUID
    //User ownerUser
    String healthProfileUid   //set from User profile id or vice versa
    Set<String> rolesHealthCare
    //ContactInfo contactInfo
    Boolean isActiveProfile = Boolean.TRUE

    Float bodyHeight
    /*
    //ProfileObservations profileObservations





    Boolean isFacetPatientData = Boolean.TRUE
    Boolean isFacetCaregiverFacet = Boolean.FALSE
    Boolean isFacetHealthActor = Boolean.FALSE


    Set<String> portalUserUUIDs

    //has role


    Set<HealthProfileIndividual> healthCaregivers
    Set<HealthProfileIndividual> healthcareFriends
    Set<HealthProfileIndividual> healthcareActors


    //TODO Principals systems...
    Set<HealthcareSystem> healthcareSystem
    Set<String> patientIdentifiers
     */
    //User ownerUser
    static belongsTo = [ownerUser:User]
    /*
    static hasMany = {

        followsHealthCaregivers: HealthProfileIndividual

        //followsHealthcareFriends might be derived from the portal
        followsHealthcareFriends: HealthProfileIndividual
        followsHealthcareActors: HealthProfileIndividual

        portalUserUUIDs: String
        rolesHealthCare: String

        healthcareSystem: HealthcareSystem
        patientIdentifiers:String
        //ownerUser(display:false)
    }
     */
    //static hasMany
    static constraints = {
        ownerUser(nullable: false, display: false)
        /*
        healthCaregivers(nullable: true)
        healthcareFriends(nullable: true)
        healthcareActors(nullable: true)

        healthcareSystem(nullable: true)
        patientIdentifiers(nullable:true)
        portalUserUUIDs(nullable: true)
        */
        rolesHealthCare(nullable:true)
         // inList: ['patient', 'caregiver_family', 'healthcare_physician', 'healthcare_pnurse'])

        //contactInfo(nullable: true)
        isActiveProfile(display: false)
        bodyHeight(nullable:true)
        /*


        isFacetPatientData(display: false)
        isFacetCaregiverFacet(display: false)
        isFacetHealthActor(display: false)
        */
    }
}
