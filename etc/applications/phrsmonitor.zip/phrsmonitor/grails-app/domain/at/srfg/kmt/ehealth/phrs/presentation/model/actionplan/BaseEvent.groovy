package at.srfg.kmt.ehealth.phrs.presentation.model.actionplan

class BaseEvent {
    String name

    static hasMany = [reminders: Reminder]

    static constraints = {
    }


}
