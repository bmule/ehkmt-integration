package at.srfg.kmt.ehealth.phrs.presentation.model.actionplan

import at.srfg.kmt.ehealth.phrs.presentation.model.actionplan.ActionPlanAction
import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties

class ActionPlanOverview extends CommonFormProperties {
    static navigation = true

    String pho__ObservationDate      //start date and end date of plan
    String pho__ObservationDateEnd
    List<ActionPlanAction> tasks = new ArrayList<ActionPlanAction>()

    List observationCategoriesAssignedPlan //these are then assigned to 0 or more actions in the plan
    //String dbeanActionPlan



    static hasMany = [tasks: ActionPlanAction, observationCategoriesAssignedPlan:String]




    static constraints = {
        pho__ObservationDate(blank:false,nullable:false)
        pho__ObservationDateEnd(blank:true,nullable:true)
        tasks(nullable:true)
        observationCategoriesAssignedPlan(nullable:true)

        //dbeanJson (maxSize: 5000)

        //phr__Types(display:false,maxSize: 2000)
    }
}
