package at.srfg.kmt.ehealth.phrs.presentation.model.observation

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties
/**
 * 1. Physical activities
 * 2. General Activities
 * etc
 *
 */

class ActivityItem extends CommonFormProperties {

    //physical activity, general activities
    String activityCategory
    String activityCode
    String activityName   //if no code, then user inserts own

    String moodIndicator
    String assessmentIndicator

    Boolean isActiveStatus = Boolean.TRUE  //true curently do activity, false, no longer do activity.

    Map<String,String> activityFeature = new HashMap<String,String>()
    Date observationDateStart
    Date observationDateEnd        //required when status is false

    String activityFrequencyCode

    String activityDurationCode
    String activityShortComment

    String comment
     //Map<String, String> activityAttributes
         //String activityFreeText
    //String activityValue
    static constraints = {
        activityCategory(nullable: true, display: false)
        //activityCategory() //physical activity, general activities
        /*
                      'phrs:uncodedActivity':'Activity not in list',
                      'phrs:activity_biking':'Biking',
                      'phrs:activity_walking':'Walking',
                      'phrs:activity_jogging':'Jogging',
                      'phrs:activity_nordicwalking':'Nordic_Walking']
        */

        activityCode(blank: false,nullable:false) //Biking,walking,etc

        activityName(nullable: true)

        isActiveStatus(nullable: true)


        //activityAttributes()

        //activityFrequencyCode(blank:false,inList:['Every Day','A few times during the week','Every Month','Several times per month'])
        //activityDurationCode(nullable:true,inList:['15 min','45 min','1 hr','2 hr','3 hr','4 hr','5 hr','6 hr','7-12 hr','more than 12 hours'])

        observationDateStart(nullable: false)
        observationDateEnd(nullable: true)
        moodIndicator(nullable:true)
        assessmentIndicator(nullable:true)
        comment(nullable: true, maxSize: 10000)
        activityShortComment(nullable: true,maxSize: 500)
        activityFeature(nullable: true)

    }
}
