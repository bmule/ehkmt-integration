package at.srfg.kmt.ehealth.phrs.presentation.model.observation

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties
import at.srfg.kmt.ehealth.phrs.presentation.utils.HealthyRules


class ObsBodyWeightBMW01 extends CommonFormProperties {

    Float bodyweight
    String msystem = "metric"
    Date observationDate = new Date()

    Float bodyBMI //calculated via javascript function, not stored??

    Float height

    String comment


    static constraints = {

        bodyweight(nullable: false, scale: 2)       //min:10f
        height(nullable: false, scale: 2)            //min:10f
        bodyBMI(editable: false,nullable:true)
        observationDate(nullable: false)

        comment(nullable:true,maxSize: 10000) //not string
        msystem(editable: false, display: false)
    }
   // static transients = ['bodyBMI']
    //static transients = ['transient_height', 'phr__bodyBMI']
    //transient_height(editable: false)
    //phr__bodyBMI(editable: false)

    String toString() {
         double bmi = HealthyRules.computeBMI(bodyweight,height)
        "/weight/${bodyweight}/height/${height} /BMI/${bmi}"
    }
}
