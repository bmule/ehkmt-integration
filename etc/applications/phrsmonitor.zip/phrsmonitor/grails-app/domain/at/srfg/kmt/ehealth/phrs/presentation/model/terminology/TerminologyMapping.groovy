package at.srfg.kmt.ehealth.phrs.presentation.model.terminology

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties

//TODO create bootstrap data for initial mappings from forms
/*
terminology  see phr__Types       snomed code xxx system xxx
property   phr__Types
form
*/
class TerminologyMapping extends CommonFormProperties {

    String typeTerminology // ?? property

    //String localPhrsNamespace  //property from external form, property from  phrs form ,etc
    String localPhrsCodeWithNamespace

    String codingSystem

    String codingNamespace
    String code

    //need? How to simply choose local vs standard namespaces
    Boolean isStandardItem =Boolean.FALSE //update if particular namespaces are used.
    //Boolean isLocalItem

    String uriDescriptor

    //namespace:code:type --> type; --> part of pcc code provision1,->part of pcc code prov2
    Set partOfGroup //pcc:3726-1 pcc:pcc_code:medlist, pcc urn:hl7:type_medicationtemplate:1.3.4.5.66.

    Set partOfLocalGroups //pcc:3726-1 pcc:medlist, pcc

    Set hasSynonym

    Set hasNarrow

    Set hasBroader

    //List catmon

    static hasMany = [catmon: TerminologyMapping]


    static constraints = {

        typeTerminology()

        localPhrsCodeWithNamespace(nullable: false, blank: false)
        typeTerminology(inList: ['property', 'controlled Vocabulary Item'])
        codingSystem()
        // we should put this to a service
        /*
              phr__type(inList: [{ ->
                            new KnLookupSupportService().lookupProblemType()
                          }])
         */
        codingNamespace(nullable: false, blank: false, inList: ['phrsform', 'snomed', 'loinc', 'extform', 'pcc-careprovision-code'])


        code(nullable: false, blank: false,)
    }
}
