package at.srfg.kmt.ehealth.phrs.presentation.model.patientdata

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties

/**
 * holds current stuff , replaced by Dynabean for general thing plus specific e.g. observation
 * currentType....EHR or PHR source
 *
 *
 */
class MedicationSummary extends CommonFormProperties {

    //first copy of data can be the EHR data, after future updates, it is the PHR
    //CommonFormProperties has a refersToSource references the source, this info describes it
    //String healthSystemSourceType
    //String healthSystemUUID

    String medicationNameText
    String medicationCode //if available, includes namespace = codeSystem

    String medicationStatus     //user controlled status
    String medicationActivity  //don't show to user? for EHR status: active, completed, etc. mapped to True or false or vice versa - switched by medicationStatus true or false?

    Date observationDateStart
    Date observationDateEnd

    //radio button of option groups that require quantity and Unit pills(0,5) or mg
    String medicationQuantity  //normally a number 0.5,1; but could be anything
    String medicationQuantityUnit  // pills, milligrams

    // String medicationFrequency
    String medicationFrequencyQuantity
    String medicationFrequencyInterval
    String medicationFrequencyTimeOfDay

    String prescribedByPersonName
    //not required
    String prescribedByPersonId
    //not required
    String prescribedByPersonRole   //role

    //--> reasons relate Riskfactors
    String medicationReasonPrimaryKeywordCode //primary reason, code must match the Riskfactor! Issue, some reasons do not have riskfactor
    Set<String> medicationReasonKeywordCodes //additional codes
    String medicationReasonComment
    String comment

    String medicationRoute   //oral, injection ??patch? ... UI has only tablets or milligrams...need to associate mg and either tablet or injection

    static hasMany = [medicationReasonKeywordCodes: String]
    static constraints = {
        //healthSystemUUID(display:false,editable:false)
        //healthSystemSourceType(inList: ['PHR','EHR','EXTERNAL-PHR','PHR-APPLICATION'])

        medicationNameText(blank: false, nullable: false) //copy any text here from EHR data
        medicationCode(nullable: true, editable: false)

        medicationStatus(nullable:false,blank:false)
        medicationActivity(nullable:true)
        observationDateStart(nullable: false)
        observationDateEnd(nullable:true)//depends on status

        //radio button of option groups that require quantity and Unit pills(0,5) or mg

        medicationQuantity(nullable:false,blank:false)
        medicationQuantityUnit(nullable:false,blank:false)

        medicationFrequencyQuantity(nullable:false,blank:false)
        medicationFrequencyInterval(blank: false,nullable:false )  //['hourly', 'daily', 'weekly', 'monthly', 'yearly'] but could changed to 1_time_per_day
        medicationFrequencyTimeOfDay(blank: false, nullable:false) // ['not specified', 'morning', 'noon', 'afternoon', 'evening', 'bedtime'])

        prescribedByPersonName(nullable:false,blank:false)
        prescribedByPersonId(nullable: true, display: false)
        prescribedByPersonRole(blank: true, nullable:true) // not used ['General Practitioner', 'Specialist', 'unknown', 'not specified'])   //role

        medicationReasonPrimaryKeywordCode(nullable: false, blank: false)
        medicationReasonKeywordCodes(nullable: true)

        medicationReasonComment(nullable: true, maxSize: 10000)
        comment(nullable: true, maxSize: 10000)

        medicationRoute(nullable:true)
    }
    /*
        medicationStatus
PortalConstants.TERM_DRUG_CONSUMPTION_STATUS_CODE
        ['active', 'completed', 'discontinued']


PortalConstants.TERM_DOSAGE_UNITS
        medicationQuantityUnit
        ['tablet', 'milligrams','other']

        medicationFrequency
        ['hourly', '']

PortalConstants.TERM_DRUG_FREQUENCY_INTERVAL_1
        medicationFrequencyInterval
        ['hourly', 'daily', 'weekly', 'monthly', 'yearly','other']

PortalConstants.TERM_DRUG_FREQUENCY_TIME_OF_DAY_1
        medicationFrequencyTimeOfDay
        ['not specified', 'morning', 'noon', 'afternoon', 'evening', 'bedtime']

PortalConstants.TERM_DRUG_PRESCRIBED_BY_ROLE
        prescribedByPersonRole
         ['General Practitioner', 'Specialist', 'unknown', 'other']



     */
}
