package at.srfg.kmt.ehealth.phrs.presentation.model.profile.systems

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties

class HealthcareSystem extends CommonFormProperties{

    String healthSystemType
    String healthSystemUUID =  UUID.randomUUID().toString()



    static constraints = {

          healthSystemType(blank:false,inList: ['EHR_SYSTEM','PHR_SYSTEM','CARE_MANAGER_SYSTEM','PHR_APPLICATION','COMPONENT_PORTAL'])
    }
}
