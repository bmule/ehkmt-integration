package at.srfg.kmt.ehealth.phrs.presentation.model.actionplan

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties

/**
 * HealthProfileIndividual: bmulreni
 * Observations are associated with task
 *
 */
class ActionPlanAction extends CommonFormProperties{
    String actionTitle
    String actionCategory

    Date observationDateStart      //start date and end date of plan
    Date observationDateEnd

    //See quartz??  or
    String scheduleJson
    //String scheduleFormat //

    List observationTypesAssignedToTask
    //String dbeanJson      see common form properties


    static constraints = {
        //phr__Types(display:false,maxSize: 2000)
    }






}
