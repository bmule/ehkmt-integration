package at.srfg.kmt.ehealth.phrs.presentation.model.actionplan

class Event extends BaseEvent {

    static constraints = {
    }
}
