package at.srfg.kmt.ehealth.phrs.presentation.model.profile

class User extends grails.plugins.nimble.core.UserBase {

    // ProfileBase belongsTo UserBase

    //if user is removed, do not remove healthProfile.  No belongsTo
    HealthProfileIndividual healthProfileIndividual

    //set this once to match the healthProfile. Can be switched
    //TODO fixme must be sure this is the saved Uid
    String healthProfileUid  = "phrs_uid_" + UUID.randomUUID().toString()//= heealthProfileIndividual uid

    Boolean activated = Boolean.TRUE

    Boolean replaced = Boolean.FALSE

    ContactInfo contactInfo

    static constraints = {
        healthProfileUid(nullable:false)
        activated(display:false)
        replaced(replaced:false)
        //created after first time user saved....
        healthProfileIndividual(nullable: true)
        contactInfo(nullable:true)
    }


}
