package at.srfg.kmt.ehealth.phrs.presentation.model
/**
 *
 * @deprecated
 */
class FormRegistry extends CommonFormProperties {

    static navigation = true


    String navigationRestUri
    String navigationCategories

    Boolean hasDynamicPropertyClass = Boolean.FALSE
    String dynamicPropertyClassUri

    Boolean usePresentationTemplate = Boolean.FALSE
    String presentationTemplateUri

    Boolean usePresentationEnricher = Boolean.FALSE
    String presentationEnricherUri

    Boolean useSemanticEnricher = Boolean.FALSE
    String semanticEnricherUri

    String comment
    String propertyOrder

    String dynamicPropertyClassSerialized

    String validationUri

    //DynaBean dynaBean// = (dynaModel?.getModel() != null) ? DynaBeanJsonUtil.fromJSONString(dynaModel.getModel()) : new Dynamodel()

    // static transients = ['dynaBean', 'dynaModel']


    static constraints = {

        navigationRestUri(blank:false)
        navigationCategories(blank:false)

        hasDynamicPropertyClass()
        dynamicPropertyClassUri(nullable: true)

        usePresentationTemplate()
        presentationTemplateUri(nullable: true)

        usePresentationEnricher()
        presentationEnricherUri(nullable: true)

        useSemanticEnricher()
        semanticEnricherUri(nullable: true)

        comment(maxSize: 5000) //not string

        propertyOrder(maxSize: 4000)

        dynamicPropertyClassSerialized(nullable: true)

        validationUri(nullable: true)
    }

}
