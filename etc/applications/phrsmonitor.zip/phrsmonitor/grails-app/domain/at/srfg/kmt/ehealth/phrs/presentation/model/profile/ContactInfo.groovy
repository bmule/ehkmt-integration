package at.srfg.kmt.ehealth.phrs.presentation.model.profile

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties

class ContactInfo extends CommonFormProperties{


    String firstName
    String lastName
    String addressLine1
    String addressLine2
    String zipCode
    String city
    String country

    String telephoneMobile
    String telephoneLand


    //see common form properties or ownerUser! static belongsTo = [ ownerUser: User]
    //static belongsTo = [healthProfile: HealthProfileIndividual, ownerUser: User]

    static constraints = {
        firstName(blank:false,nullable:false)
        lastName(nullable:false,blank:false)
        addressLine1(nullable:true)
        addressLine2(nullable:true)
        zipCode(nullable:true)
        city(nullable:true)
        country(nullable:true)

        telephoneMobile(nullable:true)
        telephoneLand(nullable:true)
    }
}
