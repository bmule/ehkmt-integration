package at.srfg.kmt.ehealth.phrs.presentation.model.observation

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties

class ObsIssue extends CommonFormProperties {

    /*
    Problems class uri  Symptom, Problem, finding,
     */

    String issueTypeCode  //SMOMED symptom or other set elsewhere
    String issueCode

    Boolean isActiveStatus = Boolean.TRUE


    Date observationDateStart = new Date()
    Date observationDateEnd //=new Date()

    String comment
   /*
    def getSchemaId(){
         String temp = "form.ObservationIssue."+issueTypeCode
        temp.replace(":",".")

    }
    */
    static constraints = {

        issueTypeCode(nullable: false, display: false)

        issueCode(nullable: true, blank: false)
 /*
         issueCode(nullable: true, blank: false,inList: ['Chest Pain', 'Diarrhea','Extra bruising or bleeding','Extra pillow to sleep at night',
        'Fatigue','Fever',
                'Palpitations','Rashes','Shortness of Breath','Swelling in feet or ankles',
                'Temporary loss of speech','Temporary Weekness', 'Vomitting','Weight Gain',
                'Other Symptoms'])
  */
        isActiveStatus(nullable: false,blank:false)

        observationDateStart(nullable:false)
        observationDateEnd(nullable:true)

        comment(nullable:true,maxSize: 10000)


    }
}
