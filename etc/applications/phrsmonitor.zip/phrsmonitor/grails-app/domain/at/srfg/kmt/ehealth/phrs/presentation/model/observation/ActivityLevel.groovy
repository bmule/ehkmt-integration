package at.srfg.kmt.ehealth.phrs.presentation.model.observation

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties

class ActivityLevel extends CommonFormProperties{

    Integer activityLevelIndicator = new Integer(0)
    Integer activityMoodIndicator  = new Integer(0)
    String comment

    Date observationDate = new Date()

    static constraints = {
       activityLevelIndicator(nullable:false)
       activityMoodIndicator(nullable:true)
       comment(nullable:true,maxSize: 10000)
       observationDate(nullable:true,display:false)
    }
}
