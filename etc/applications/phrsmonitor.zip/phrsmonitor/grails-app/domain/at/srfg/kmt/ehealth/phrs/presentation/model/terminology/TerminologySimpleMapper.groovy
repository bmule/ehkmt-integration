package at.srfg.kmt.ehealth.phrs.presentation.model.terminology

import at.srfg.kmt.ehealth.phrs.presentation.model.CommonFormProperties

/**
 * Main overview table that references a type of data to a history gathered from the EHR..where we can get the latest for this
 * observations,
 */
class TerminologySimpleMapper extends CommonFormProperties {

    /**
     * Can search EHR data for this
     */

    String phrsCodeNamespace
    String phrsCode


    Boolean hasStandardCoding = Boolean.FALSE

    String controlledCodingNameSpace //use coding system
    String controlledCodingSystem
    String controlledCode
    String preferredLabel

    Map<String,String> relations= new HashMap<String,String>()

    static constraints = {

        phrsCodeNamespace()
        phrsCode()
        hasStandardCoding()
        controlledCodingNameSpace()

        preferredLabel(nullable:false)
        relations(nullable:true)

        controlledCode(nullable: true)

    }
}
