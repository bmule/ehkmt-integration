package at.srfg.kmt.ehealth.phrs.presentation.model
//import org.grails.taggable.*

import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User
/**
 * These properties
 * implements Taggable
 */
class CommonFormProperties {

    //reference to an EHR source. Use a namespace to indicate source type e.g. ehr: There might be a multipart id ...
    //issue: can reassign this uri to match core ?
    String _phrsBeanRefersToSourceUri        //prefix=ehr
    String _phrsBeanUri = "phrs_uuid_" + UUID.randomUUID().toString()

    String _phrsBeanClassURI
    String _phrsBeanOwnerUri
    String _phrsBeanCreatorUri    //for EHR data prefix=ehr
    Date _phrsBeanCreateDate = new Date()
    Boolean _phrsBeanIsDeleted = Boolean.FALSE

    //TODO not in forms
    Boolean _phrsBeanCanRead =Boolean.TRUE
    //TODO not in forms
    Boolean _phrsBeanCanWrite =Boolean.TRUE
    //TODO not in forms
    String _phrsBeanName
    //TODO not in forms
    Boolean _phrsBeanCanUse = Boolean.TRUE

    // Date timestamp = new Date()
    User ownerUser

    static constraints = {
        ownerUser(display: false)
        //display related: no display, no editing
        _phrsBeanRefersToSourceUri(nullable: true, display: false)

        _phrsBeanUri(display: false)

        // a list of types separated by blank or ;
        _phrsBeanClassURI(display: false, nullable: true)

        _phrsBeanOwnerUri(display: false)
        _phrsBeanCreatorUri(display: false)

        _phrsBeanCreateDate(display: false)
        _phrsBeanIsDeleted(display: false)
        //timestamp(display: false)
        _phrsBeanName(nullable: true, display: false)
        _phrsBeanCanRead(nullable: true, display: false)
        _phrsBeanCanWrite(nullable: true, display: false)
        _phrsBeanCanUse(nullable: true, display: false)
    }

    static belongsTo = [ownerUser: User]


}
