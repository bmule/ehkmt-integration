package at.srfg.kmt.ehealth.phrs.presentation.model.dynamic

class CoreMessage {

    /*
   PortalConstants.CORE_MESSAGE_ACTION_IMPORT_EHR
   PortalConstants.CORE_MESSAGE_ACTION_EXPORT_CORE


   PortalConstants.CORE_MESSAGE_STATUS_FAIL_REDO

   PortalConstants.CORE_MESSAGE_STATUS_SUCCESS_HOLD
   PortalConstants.CORE_MESSAGE_STATUS_SUCCESS_CONSUMED
    */

    String messageUri = UUID.randomUUID().toString()
    Integer sequence
    String action
    Date createDate
    String creatorUri
    String ownerUri
    String localResourceUri
    String interopClassUri

    String coreResourceUri

    String statusCode
    /*
    PortalConstants.CORE_MESSAGE_STATUS_FAIL_REDO
    PortalConstants.CORE_MESSAGE_STATUS_SUCCESS
     */
    Boolean isCompleted

    static constraints = {

        action(nullable: false)

        createDate(nullable: true) //keep null because of beforeInsert
        creatorUri(nullable: false)

        ownerUri(nullable: false)

        localResourceUri(nullable: false)
        interopClassUri(nullable: false)

        coreResourceUri(nullable: false)


        statusCode(nullable: false)
        isCompleted(nullable: true)

        messageUri(nullable: false)
        sequence(nullable: true)
    }

    def beforeInsert = {
        createDate = new Date()
    }
}
