package at.srfg.kmt.ehealth.phrs.presentation.services

import at.srfg.kmt.ehealth.phrs.presentation.utils.PresentationUtils
import at.srfg.kmt.ehealth.phrs.presentation.model.profile.User

import at.srfg.kmt.ehealth.phrs.presentation.utils.InteropServerClient
import at.srfg.kmt.ehealth.phrs.presentation.utils.PortalConstants


class PhrsCommonsService {

    PresentationUtils presentationUtils = new PresentationUtils()

    //def authenticatedUser //injected  does not work on service, pass from controller.

    //test date issue - need date structure
    def prepareParamsValidation = { attrs ->
        def params = attrs?.params ? attrs.params : null
        def classUri = attrs?.classUri ? attrs.classUri : null
        //println("prepareParamsValidation before params entry set="+params?.entrySet())
        if (params) {

            //println("params size=" + params.size())
            params.remove("createDate")
            params.remove("hideDate")
            //params.remove("ownerUser")
            //println("params size=" + params.size())
            //println("after params set=" + params?.entrySet())
        }

        return params

    }
    def test = { attrs, authenticatedUser, msg ->
        println("")
        println("PhrsInteropService Authenticated processBean msg=" + msg + "attrs entries=" + attrs.each {print(it + ", ")})
        println("")
        println("PhrsInteropService Authenticated processBean authenticatedUser=" + authenticatedUser)
        println("PhrsInteropService Authenticated processBean authenticatedUser=" + authenticatedUser?.id)
        return true
    }

    def processTest2(Map attrs, User user) {
        println("processTest2 user=" + user)
        println("processTest2 user.id=" + user?.id)

        test(attrs, user, "...call closure from service method")
        println("back to processTest2")

    }

    def processTest3 = {attrMap, user ->
        println("processTest3 user=" + user)
        println("processTest3 user.id=" + user?.id)
    }

    def processTest() {
        def attrs = ['one', 'two']
        def msg = 'hello'
        //test (attrs,msg)

    }

    def processBean = { attrs ->
        boolean flag = test(attrs, 'test')
        return flag

    }

    def processBeanAuthorization = { attrs ->
        //can find resource uri or class uri  on dynabean or pojo commonFormProperties
        return true
    }

    def processResourceAuthorization = { attrs ->
        //might get resource uri or class uri
        return true
    }

    def visualizationAttributes = { attrs ->
        presentationUtils.visualizationAttributes(attrs)

    }

    def processResourceInit = { attrs ->


        presentationUtils.processResourceInit(attrs)

        return true
    }
    def processResourceToPersist = { attrs ->

        presentationUtils.processResourceToPersist(attrs)

        return true
    }
    def processResourceInterop = { attrs ->

        presentationUtils.processResourceInterop(attrs)

        return true
    }

    /* @deprecated
    test
     */
    def processBeanInput = { attrs ->

        presentationUtils.processResourceToPersist(attrs)

        return true
    }

    /*
    def processBeanInput = { beanInput, classUri, paramsMap, theAuthenticatedUser, attrMap ->
        print("processBeanInput start")

        presentationUtils.processBeanInput(beanInput, classUri,paramsMap, theAuthenticatedUser, attrMap)
         print("processBeanInput end")
        return true vocabOptions
    }
     */
    def processController = { attrs ->
        presentationUtils.processController(attrs)
        return true
    }

    def queryList = {  attrs ->

        presentationUtils.queryList(attrs)
    }

    def importEhrByUser = {  attrs ->
        // def ownerUri = attrs.ownerUri
        // def classUri = attrs.classUri
        // def clazzSample =attrs.className
        // def currentObjectList

        def test = 1

        //presentationUtils.importEhrByUser(attrs)

        /*['instanceName': 'activityItemInstance',
         'className': ActivityItem,
         'theAction': 'list',
         'classUriInterop': CLASS_URI_INTEROP,
         'classUri': CLASS_URI,
         'params': params,
         'authenticatedUser': authenticatedUser,
         'action': PortalConstants.ACTION_CONTROLLER_SHOW])
        */


    }

    def filterLabelValueListByIdList = {  attrs ->
        presentationUtils.filterLabelValueListByIdList(attrs)
    }
    def dynamicBeanCreate = { attrs ->
        //create pojo or create dynamicBean
        //additional actions

    }
    /*
    def ownerUri = authenticatedUser.healthProfileUid
    updateFromEhr([
          ownerUri:ownerUri, classUri:CLASS_URI_INTEROP,
          XXX.findAll( (PortalConstants.Model_PROPERTY_OWNER_URI):ownerUri )])
    */
    /*
    def updateFromEhr(Map attrs){

        def ownerUri = attrs.ownerUri
        def classUri = attrs.classUri
        def clazzSample = attrs.className
        def currentObjectList= attrs.localList

        def ownerUri = authenticatedUser.healthProfileUid
        def localList= XXX.findAll( (PortalConstants.Model_PROPERTY_OWNER_URI):ownerUri )
        List newList = PhrsCommonsService.findNewEhrData( ownerUri,  classUri, clazzSample,  localList)
        newList.each { obj ->
              try{
                    obj.save()
                 }catch(Exception e)
                 {log.error(e)}
        }

    } */
    /**
     * Used to retrieve core data
     * @param ownerUri
     * @param classUri
     * @param clazzSample
     * @return
     */
    Set findEhrData(String ownerUri, String classUri, clazzSample) {
        Set resultDomainObjectList
        try {
            Map map = [classUri: classUri, ownerUri: ownerUri]
            def jsonArray = InteropServerClient.restGetAllByClass(map)
            resultDomainObjectList = PresentationUtils.transformToDomainObjectsUsingClassSample(jsonArray, clazzSample)


        } catch (Exception e) {
            log.error(e)
        }

        //def jsonArray = InteropServerClient.restGetAllByClass(["classUri": classUri])
        return resultDomainObjectList
    }
    /**
     * Used to retrieve core data
     * @param ownerUri
     * @param classUri
     * @param clazzSample
     * @param currentObjectList
     * @return
     */
    Set filterNewEhrData(String ownerUri, String classUri, clazzSample, List currentObjectList, ehrList) {
        def hits
        def testMatches
        def newEhrFound
        try {

            //domain object has this method
            //List localList =  clazzSample.findAll((PortalConstants.Model_PROPERTY_OWNER_URI):ownerUri) //'_phrsBeanCreateDate':filterUserUri,
            if (ehrList && currentObjectList) {


                newEhrFound = ehrList.collect { obj ->
                    def resourceUri = obj?._phrsBeanUri ? obj._phrsBeanUri : null

                    def found = currentObjectList.findAll{  local ->
                        local._phrsBeanUri != resourceUri
                    }
                    //test
                    testMatches = currentObjectList.findAll {  local ->
                        local._phrsBeanUri == resourceUri
                    }

                    if (found) {
                        hits.addAll(found)
                        return found
                    }

                }
            }
        } catch (Exception e) {
            log.error(e)
        }
        if(PortalConstants.EHR_SIMULATION_CREATE_TEST_DATA_FROM_MATCH){
           hits = simulateNewEhrDataFromExistingSource(testMatches)
        }
        return hits
    }
    def simulateNewEhrDataFromExistingSource(matches){

    }
    Set findNewEhrData(String ownerUri, String classUri, clazzSample, List currentObjectList) {
        def hits
        try {
            def ehrList = findEhrData(ownerUri, classUri, clazzSample)
            if (ehrList) {
                hits = filterNewEhrData(ownerUri, classUri, clazzSample, currentObjectList, ehrList)
            }

        } catch (Exception e) {
            log.error(e)
        }
        return hits
    }
    /*

    find by uri of auth user rr params._phrsBeanOwnerUri


    example
          params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [
                obsBodyWeightBMW01InstanceList: ObsBodyWeightBMW01.list(params),
                obsBodyWeightBMW01InstanceTotal: ObsBodyWeightBMW01.count(),
                'theAction':'list',
                'visualizationAttributes':PhrsCommonsService.visualizationAttributes(CLASS_URI),
                'controllerOptionProperties':controllerOptionProperties
        ]
   def results = {
    def users = User.findAllByUserIdLike(params.userId)
    return [ users: users, term : params.userId ]
    }

   String _phrsBeanRefersToSourceUri        //normally this uri and same as interop URI, but can be different ?

    String _phrsBeanUri = "phrs_uuid_" + UUID.randomUUID().toString()
    String phrs_displayName

    //should be the classUri!
    String _phrsBeanClassURI = ""

    String _phrsBeanOwnerUri
    String _phrsBeanCreatorUri
     */
}
