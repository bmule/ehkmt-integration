package phrsmonitor

class TestService {

    static transactional = true

    def serviceMethod() {

    }

    /*
 package com.grailsinaction
 class SecurityFilters {
 //B Injects
 def authenticateService	//required service
def filters = { profileChanges(controller: "profile", action: "edit,update") {
before = {
def currUserId = authenticateService.userDomain().userId
if (currUserId != params.userId) {
	//Compares
redirect(controller: "login", action: "denied")
// C user IDs return false
} return true
}
    */
}
